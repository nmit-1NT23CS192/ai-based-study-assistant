const express = require('express');
const cors    = require('cors');
const dotenv  = require('dotenv');
const morgan  = require('morgan');

dotenv.config();

const app  = express();
const PORT = process.env.PORT || 5000;
const isProd = process.env.NODE_ENV === 'production';

// ── CORS ────────────────────────────────────────────────────────────────────
// Build an allowed-origins list from CLIENT_URL + local dev fallbacks.
// Trailing slashes are stripped so mismatches (a common mistake) don't block.
const rawClientUrl = process.env.CLIENT_URL || '';
const allowedOrigins = [
  rawClientUrl.replace(/\/$/, ''),          // production Vercel URL
  'http://localhost:5173',                  // Vite dev default
  'http://localhost:5174',                  // Vite fallback port
].filter(Boolean);

// Log so the Render build log confirms what's allowed (helps debugging)
console.log('[CORS] allowed origins:', allowedOrigins);

app.use(cors({
  origin(origin, callback) {
    // Allow requests with no origin (Render health checks, curl, Postman, etc.)
    if (!origin) return callback(null, true);
    const normalized = origin.replace(/\/$/, '');
    if (allowedOrigins.includes(normalized)) return callback(null, true);
    // In development, allow any localhost port
    if (!isProd && normalized.startsWith('http://localhost')) return callback(null, true);
    callback(new Error(`CORS: origin "${origin}" not in allowed list`));
  },
  credentials: true,
}));

// ── Body parsing ────────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── HTTP request logging ────────────────────────────────────────────────────
// 'combined' (Apache format) in production → parseable by log aggregators
// 'dev' in development → coloured, concise
app.use(morgan(isProd ? 'combined' : 'dev'));

// ── Routes ─────────────────────────────────────────────────────────────────
app.use('/api/auth',       require('./routes/auth.routes'));
app.use('/api/chat',       require('./routes/chat.routes'));
app.use('/api/flashcards', require('./routes/flashcard.routes'));
app.use('/api/reviewers',  require('./routes/reviewer.routes'));
app.use('/api/materials',  require('./routes/material.routes'));
app.use('/api/debugger',   require('./routes/debugger.routes'));
app.use('/api/notes',      require('./routes/notes.routes'));
app.use('/api/bookmarks',  require('./routes/bookmarks.routes'));
app.use('/api/admin',      require('./routes/admin.routes'));
app.use('/api/analytics',  require('./routes/analytics.routes'));

// Health check — used by Render to confirm the server is alive
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ── 404 handler ────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
});

// ── Global error handler ───────────────────────────────────────────────────
// Must have 4 parameters so Express recognises it as an error handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production'
      ? 'Internal server error'
      : err.message,
  });
});

// ── Start ──────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
});
