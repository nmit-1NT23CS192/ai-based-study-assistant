-- AlterTable
ALTER TABLE "study_materials" ADD COLUMN     "cloudinaryPublicId" TEXT,
ADD COLUMN     "fileSize" INTEGER,
ADD COLUMN     "pageCount" INTEGER;
