import { useState } from 'react';
import { X, Printer, BookOpen, Loader2, Check, FileText } from 'lucide-react';
import ReviewerContent from '../reviewer/ReviewerContent';
import reviewerService from '../../services/reviewer.service';

const SUMMARY_TYPE_LABELS = {
  brief:       'Brief Summary',
  detailed:    'Detailed Summary',
  key_points:  'Key Points',
  study_guide: 'Study Guide',
};

/**
 * Displays a generated summary and offers Print + Save as Reviewer actions.
 *
 * Reuses ReviewerContent for markdown rendering — the output format is
 * identical to reviewers (both are Markdown from the same Gemini model).
 *
 * The "Save as Reviewer" button calls the reviewer API directly from
 * the frontend, integrating the two features without backend coupling.
 */
export default function SummaryViewer({ result, onClose }) {
  const { summary, summaryType, materialTitle } = result;
  const [saving,  setSaving]  = useState(false);
  const [saved,   setSaved]   = useState(false);
  const [saveErr, setSaveErr] = useState('');

  function handlePrint() {
    window.print();
  }

  async function handleSaveAsReviewer() {
    const title   = `Summary: ${materialTitle}`;
    const subject = 'General'; // User can rename in the Reviewers tab
    setSaving(true);
    setSaveErr('');
    try {
      await reviewerService.save(title, subject, summary);
      setSaved(true);
    } catch (err) {
      setSaveErr(err.response?.data?.error || 'Failed to save. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  const typeLabel = SUMMARY_TYPE_LABELS[summaryType] ?? summaryType;

  return (
    <div className="flex flex-col h-full">

      {/* ── Toolbar ──────────────────────────────────────────────────── */}
      <div className="no-print flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <FileText size={15} className="text-indigo-500 shrink-0" />
          <div className="min-w-0">
            <p className="text-xs font-semibold text-gray-900 dark:text-white truncate">
              {materialTitle}
            </p>
            <p className="text-xs text-gray-400">{typeLabel}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Save as Reviewer */}
          {saved ? (
            <span className="flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
              <Check size={13} /> Saved!
            </span>
          ) : (
            <button
              onClick={handleSaveAsReviewer}
              disabled={saving}
              title="Save this summary as a Reviewer"
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 disabled:opacity-50 transition-colors"
            >
              {saving
                ? <><Loader2 size={12} className="animate-spin" /> Saving…</>
                : <><BookOpen size={12} /> Save as Reviewer</>
              }
            </button>
          )}

          {/* Print */}
          <button
            onClick={handlePrint}
            title="Print or save as PDF"
            className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
          >
            <Printer size={12} /> Print
          </button>

          {/* Close */}
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            aria-label="Close summary"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Save error */}
      {saveErr && (
        <p className="no-print text-xs text-red-600 dark:text-red-400 px-4 pt-2">{saveErr}</p>
      )}

      {/* ── Content ──────────────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto p-5">
        <ReviewerContent content={summary} />
      </div>
    </div>
  );
}
