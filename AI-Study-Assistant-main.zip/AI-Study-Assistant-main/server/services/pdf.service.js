const { generateText } = require('./gemini.service');

// ── Summary type instructions ──────────────────────────────────────────────
// Same pattern as reviewer types: explicit structural targets per type.

const SUMMARY_TYPE_INSTRUCTIONS = {
  brief: `
Write a brief executive summary in 150–250 words.
Structure:
## Overview
[2–3 sentences: what is this document about and its main conclusion]

## Key Takeaways
[3–5 bullet points: the most critical points]
`.trim(),

  detailed: `
Write a thorough comprehensive summary covering all major sections.
Structure:
## Document Overview
## Main Topics (one ## section per major topic in the document)
## Key Arguments and Evidence
## Conclusions
## Further Reading (if applicable)
`.trim(),

  key_points: `
Extract the most important information as a structured reference.
Structure:
## Main Topic
## Key Concepts (bulleted definitions for every important term)
## Important Facts & Figures (numbered, specific data points)
## Core Arguments or Steps
## Summary (one paragraph)
`.trim(),

  study_guide: `
Create a comprehensive student study guide.
Structure:
## Topic Overview
## Key Terms & Definitions (glossary style, **term**: definition)
## Core Concepts (explained simply, with examples)
## Important Points to Remember (numbered list)
## Practice Questions (5 questions with answers)
## Quick Review Checklist (checkable bullet points)
`.trim(),
};

const SUMMARIZER_SYSTEM_PROMPT = `
You are an expert academic assistant helping college students understand study materials.
Create summaries that are accurate, well-structured, and easy to understand.
Always use proper Markdown formatting with headers, lists, and bold key terms.
Do not fabricate information — only summarise what is in the provided text.
`.trim();

// ── extractTextFromPDF ─────────────────────────────────────────────────────
/**
 * Extracts raw text content from a PDF buffer.
 *
 * pdf-parse v1.1.1 uses pdfjs-dist under the hood — it reads the PDF's
 * internal text objects. This works well for text-based PDFs but NOT for
 * scanned image PDFs (those would need OCR, which is out of scope here).
 *
 * Imported inside the function to avoid the pdf-parse v1.x quirk where
 * importing at module load time in a test environment tries to read a
 * test PDF file from disk (causing ENOENT errors in CI).
 *
 * @param {Buffer} fileBuffer
 * @returns {{ text: string, pageCount: number }}
 */
async function extractTextFromPDF(fileBuffer) {
  // Lazy require — avoids the pdf-parse test-file side-effect on module load
  const pdfParse = require('pdf-parse');
  const data = await pdfParse(fileBuffer);

  const cleaned = cleanText(data.text);
  return { text: cleaned, pageCount: data.numpages };
}

// ── cleanText ──────────────────────────────────────────────────────────────
// PDFs often have form feeds (\f), excessive blank lines, and run-together
// words where line breaks aren't preserved. This normalises the raw output.

function cleanText(raw) {
  return raw
    .replace(/\f/g, '\n')            // Form feed (page break) → newline
    .replace(/[ \t]+/g, ' ')         // Multiple spaces/tabs → single space
    .replace(/\n{3,}/g, '\n\n')      // 3+ newlines → 2 (preserve paragraphs)
    .trim();
}

// ── truncateTextForAI ──────────────────────────────────────────────────────
/**
 * Limits extracted text so the combined prompt stays within the token budget.
 *
 * Strategy: take the first 75% of the limit from the start and the last 25%
 * from the end. This captures both the introduction (usually defines scope)
 * and the conclusion (usually summarises findings) — the two most information-
 * dense sections of most academic documents.
 *
 * @param {string} text
 * @param {number} maxChars  Default 8000 ≈ 2000 tokens (safe for free tier)
 */
function truncateTextForAI(text, maxChars = 8000) {
  if (text.length <= maxChars) return text;

  const headLength = Math.floor(maxChars * 0.75);
  const tailLength = maxChars - headLength;

  const head = text.slice(0, headLength);
  const tail = text.slice(-tailLength);

  return `${head}\n\n[... content truncated for length ...]\n\n${tail}`;
}

// ── generateSummaryWithAI ──────────────────────────────────────────────────
/**
 * Calls Gemini to summarise the extracted text.
 *
 * The spec prompt is used verbatim with per-type structural instructions
 * appended, following the same approach as reviewerService.
 *
 * @param {string} extractedText - Already truncated to maxChars
 * @param {string} summaryType   - 'brief' | 'detailed' | 'key_points' | 'study_guide'
 * @returns {{ summary: string, tokensUsed: number }}
 */
async function generateSummaryWithAI(extractedText, summaryType) {
  const validTypes = Object.keys(SUMMARY_TYPE_INSTRUCTIONS);
  const type = validTypes.includes(summaryType) ? summaryType : 'brief';
  const typeInstructions = SUMMARY_TYPE_INSTRUCTIONS[type];

  const prompt = `You are an academic assistant. Summarize the following study material for a college student.

Summary type: ${type}
Format using Markdown with headers, bullet points, and clear sections.
Be concise but thorough. Highlight the most important concepts.

${typeInstructions}

Material content:
---
${extractedText}
---`;

  const { text, tokensUsed } = await generateText(prompt, SUMMARIZER_SYSTEM_PROMPT);

  if (!text?.trim()) throw new Error('AI returned an empty summary. Please try again.');

  return { summary: text, tokensUsed };
}

module.exports = { extractTextFromPDF, truncateTextForAI, generateSummaryWithAI };
