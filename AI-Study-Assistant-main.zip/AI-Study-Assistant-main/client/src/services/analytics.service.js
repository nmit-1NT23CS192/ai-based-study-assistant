import api from './api';

const analyticsService = {
  async getMyAnalytics() {
    const res = await api.get('/analytics');
    return res.data;
  },
};

export default analyticsService;
