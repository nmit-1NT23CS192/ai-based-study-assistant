const prisma               = require('../utils/prismaClient');
const { generateText }     = require('./gemini.service');

// ── System prompt ──────────────────────────────────────────────────────────
// Short and authoritative — the user prompt carries all topic/format details.

const REVIEWER_SYSTEM_PROMPT = `
You are an expert academic tutor creating study materials for BSIT and college students.
Always produce well-structured Markdown with clear headers, bold key terms, and examples.
Write in clear, student-friendly language. Never skip the summary section.
`.trim();

// ── Reviewer type instructions ─────────────────────────────────────────────
// Appended to the base prompt so each type produces distinctly shaped output.
// Keeping them separate makes A/B testing or tweaking one type trivial.

const TYPE_INSTRUCTIONS = {
  comprehensive: `
Include ALL of the following sections:
1. ## Introduction — what is this topic and why does it matter?
2. ## Core Concepts — 4–8 key ideas with clear explanations
3. ## Detailed Explanation — step-by-step breakdown
4. ## Examples — at least 2 concrete, practical examples (with code if relevant)
5. ## Common Misconceptions — 2–3 things students often get wrong
6. ## Quick Reference — a table or bullet list for fast revision
7. ## Summary — 3–5 sentence recap of the whole topic
`.trim(),

  summary: `
Format as a concise summary only. Include:
1. ## Overview — 2–3 sentences defining the topic
2. ## Top 10 Key Points — numbered list, one sentence each
3. ## Essential Terms — 5–8 bold terms with one-line definitions
4. ## Summary — one paragraph wrapping it up
Keep the entire reviewer under 600 words. Prioritise clarity over completeness.
`.trim(),

  key_concepts: `
Format as a concept glossary / reference sheet. Include:
1. ## Key Concepts — each term as a sub-header (###), with:
   - **Definition**: one clear sentence
   - **In practice**: how/when it's used
   - **Example** (optional): a brief illustration
2. ## Concept Relationships — a short section showing how the terms connect
3. ## Summary — one paragraph
Aim for 6–15 concepts depending on the topic's breadth.
`.trim(),

  q_and_a: `
Format as a practice Q&A sheet. Include:
1. ## Practice Questions — 10–15 questions progressing from basic to advanced:
   - **Q1:** [question]
   **Answer:** [detailed answer]
2. ## Summary — one paragraph
Mix factual, conceptual, and application questions.
`.trim(),
};

// ── Prompt builder ─────────────────────────────────────────────────────────
/**
 * Builds the full user-turn prompt for a reviewer generation request.
 *
 * Design decisions:
 *   1. Topic is quoted so the model treats it as a noun phrase, not instructions.
 *   2. Subject scopes the vocabulary and difficulty level.
 *   3. Reviewer type appended as explicit formatting instructions — more reliable
 *      than asking the model to infer format from a single keyword.
 *   4. Student notes (if provided) are appended last so they ground the output
 *      in the student's own context rather than general internet knowledge.
 */
function buildPrompt(topic, subject, reviewerType, inputText) {
  const typeGuide = TYPE_INSTRUCTIONS[reviewerType] ?? TYPE_INSTRUCTIONS.comprehensive;

  let prompt = `You are an expert academic tutor for college students. Create a study reviewer about "${topic}" for ${subject}.

Format the reviewer using Markdown with:
- Clear section headers (##)
- Key concepts explained simply
- Important definitions in **bold**
- Examples where helpful
- A quick summary at the end

Type: ${reviewerType}
${typeGuide}`;

  if (inputText?.trim()) {
    prompt += `\n\n---\nBase the reviewer on these student notes:\n\n${inputText.trim()}\n---`;
  }

  prompt += '\n\nWrite in clear, student-friendly language.';
  return prompt;
}

// ── generateReviewerWithAI ─────────────────────────────────────────────────

/**
 * Calls Gemini and returns raw Markdown text.
 * Does NOT write to the database — the controller handles persistence.
 *
 * @returns {{ content: string, tokensUsed: number }}
 */
async function generateReviewerWithAI(topic, subject, reviewerType, inputText) {
  const validTypes = Object.keys(TYPE_INSTRUCTIONS);
  const type = validTypes.includes(reviewerType) ? reviewerType : 'comprehensive';

  const prompt = buildPrompt(topic, subject, type, inputText);
  const { text, tokensUsed } = await generateText(prompt, REVIEWER_SYSTEM_PROMPT);

  if (!text?.trim()) throw new Error('AI returned an empty reviewer. Please try again.');

  return { content: text, tokensUsed };
}

// ── saveReviewer ───────────────────────────────────────────────────────────

async function saveReviewer(userId, title, subject, content) {
  return prisma.reviewer.create({
    data: { userId, title: title.trim(), subject: subject.trim(), content },
  });
}

// ── getUserReviewers ───────────────────────────────────────────────────────

async function getUserReviewers(userId) {
  return prisma.reviewer.findMany({
    where:   { userId },
    orderBy: { updatedAt: 'desc' },
    select:  { id: true, title: true, subject: true, content: true, createdAt: true, updatedAt: true },
  });
}

// ── getReviewer ────────────────────────────────────────────────────────────

async function getReviewer(reviewerId, userId) {
  const reviewer = await prisma.reviewer.findUnique({ where: { id: reviewerId } });
  if (!reviewer || reviewer.userId !== userId) return null;
  return reviewer;
}

// ── deleteReviewer ─────────────────────────────────────────────────────────

async function deleteReviewer(reviewerId, userId) {
  const reviewer = await prisma.reviewer.findUnique({ where: { id: reviewerId } });
  if (!reviewer)               throw new Error('REVIEWER_NOT_FOUND');
  if (reviewer.userId !== userId) throw new Error('REVIEWER_NOT_OWNED');
  await prisma.reviewer.delete({ where: { id: reviewerId } });
}

module.exports = {
  generateReviewerWithAI,
  saveReviewer,
  getUserReviewers,
  getReviewer,
  deleteReviewer,
};
