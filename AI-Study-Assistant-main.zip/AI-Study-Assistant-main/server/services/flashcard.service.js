const prisma  = require('../utils/prismaClient');
const { generateJSON } = require('./gemini.service');

// ── System prompt ──────────────────────────────────────────────────────────
// Kept terse because the user prompt already carries all context.
// The system role establishes the output contract.

const FLASHCARD_SYSTEM_PROMPT = `
You are an expert educational content creator specialising in BSIT and college-level subjects.
Your only output is a JSON array of flashcard objects.
Rules:
- Each card must have exactly two keys: "question" and "answer".
- Questions test specific, discrete knowledge (not vague understanding).
- Answers are concise: 1–3 sentences or a short code snippet.
- Never add explanations, markdown, or any text outside the JSON array.
`.trim();

// ── JSON parser ────────────────────────────────────────────────────────────
// Even with responseMimeType:'application/json', defensive parsing handles
// edge cases where the model includes a wrapping object instead of a bare array.

function parseCards(rawText) {
  const parsed = JSON.parse(rawText); // throws SyntaxError on invalid JSON

  // Model sometimes wraps array: { "flashcards": [...] }
  const arr = Array.isArray(parsed)
    ? parsed
    : parsed.flashcards ?? parsed.cards ?? Object.values(parsed)[0];

  if (!Array.isArray(arr)) throw new Error('Response is not an array');

  return arr
    .filter(item => item?.question && item?.answer)
    .map(item => ({
      question: String(item.question).trim(),
      answer:   String(item.answer).trim(),
    }));
}

// ── generateFlashcardsWithAI ───────────────────────────────────────────────

/**
 * Calls Gemini with a structured prompt and returns a parsed flashcard array.
 * Does NOT write to the database — the controller decides whether to save.
 *
 * Prompt design decisions:
 *  - Explicit count enforces the model to produce exactly N items
 *  - "for a [subject] student" scopes difficulty and vocabulary
 *  - Example format in the prompt anchors the exact key names
 *  - responseMimeType in generateJSON guarantees valid JSON output
 *
 * @param {string} topic   - e.g. "recursion", "binary search trees"
 * @param {string} subject - e.g. "Data Structures", "Web Development"
 * @param {number} count   - 5–20
 * @returns {{ cards: Array<{question,answer}>, tokensUsed: number }}
 */
async function generateFlashcardsWithAI(topic, subject, count) {
  const prompt = [
    `Generate ${count} flashcards about "${topic}" for a ${subject} student.`,
    'Return ONLY a JSON array with no markdown, no explanation, just the array.',
    'Each object must have "question" and "answer" keys.',
    'Example format: [{"question":"What is X?","answer":"X is ..."}]',
  ].join(' ');

  const { text, tokensUsed } = await generateJSON(prompt, FLASHCARD_SYSTEM_PROMPT);

  const cards = parseCards(text);

  if (cards.length === 0) {
    throw new Error('AI returned no valid flashcards. Please try a different topic.');
  }

  return { cards, tokensUsed };
}

// ── createFlashcardSet ─────────────────────────────────────────────────────

/**
 * Persists a complete set + all cards in a single transaction.
 * Either both the set and every card are created, or nothing is — no
 * orphaned sets with zero cards can exist.
 */
async function createFlashcardSet(userId, title, subject, flashcards) {
  return prisma.$transaction(async (tx) => {
    const set = await tx.flashcardSet.create({
      data: { userId, title: title.trim(), subject: subject.trim() },
    });

    await tx.flashcard.createMany({
      data: flashcards.map(card => ({
        setId:    set.id,
        question: card.question.trim(),
        answer:   card.answer.trim(),
      })),
    });

    // Re-fetch with cards so the caller gets the full shape immediately
    return tx.flashcardSet.findUnique({
      where:   { id: set.id },
      include: { flashcards: { orderBy: { createdAt: 'asc' } } },
    });
  });
}

// ── getUserFlashcardSets ───────────────────────────────────────────────────

async function getUserFlashcardSets(userId) {
  return prisma.flashcardSet.findMany({
    where:   { userId },
    orderBy: { updatedAt: 'desc' },
    include: { _count: { select: { flashcards: true } } },
  });
}

// ── getFlashcardSet ────────────────────────────────────────────────────────

async function getFlashcardSet(setId, userId) {
  const set = await prisma.flashcardSet.findUnique({
    where:   { id: setId },
    include: { flashcards: { orderBy: { createdAt: 'asc' } } },
  });

  if (!set || set.userId !== userId) return null;
  return set;
}

// ── deleteFlashcardSet ─────────────────────────────────────────────────────

async function deleteFlashcardSet(setId, userId) {
  const set = await prisma.flashcardSet.findUnique({ where: { id: setId } });
  if (!set)               throw new Error('SET_NOT_FOUND');
  if (set.userId !== userId) throw new Error('SET_NOT_OWNED');

  // Cascade delete removes flashcards (defined in schema)
  await prisma.flashcardSet.delete({ where: { id: setId } });
}

// ── addFlashcard ───────────────────────────────────────────────────────────

async function addFlashcard(setId, question, answer) {
  return prisma.flashcard.create({
    data: { setId, question: question.trim(), answer: answer.trim() },
  });
}

// ── deleteFlashcard ────────────────────────────────────────────────────────

async function deleteFlashcard(flashcardId, setId, userId) {
  // Ownership check: verify the set belongs to this user
  const set = await prisma.flashcardSet.findUnique({
    where:  { id: setId },
    select: { userId: true },
  });

  if (!set || set.userId !== userId) throw new Error('SET_NOT_FOUND');

  // Prisma compound where ensures the card actually belongs to the set
  await prisma.flashcard.delete({
    where: { id: flashcardId, setId },
  });
}

module.exports = {
  generateFlashcardsWithAI,
  createFlashcardSet,
  getUserFlashcardSets,
  getFlashcardSet,
  deleteFlashcardSet,
  addFlashcard,
  deleteFlashcard,
};
