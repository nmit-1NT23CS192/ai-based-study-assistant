import { Component } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

/**
 * Catches JavaScript errors in the component tree and renders a fallback UI.
 * React 19 still requires class components for error boundaries — hooks
 * cannot catch render-phase errors.
 *
 * Usage: wrap any subtree that might throw
 *   <ErrorBoundary>
 *     <SomeFeaturePage />
 *   </ErrorBoundary>
 */
export default class ErrorBoundary extends Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    // In production this would ship to an error tracking service (Sentry, etc.)
    console.error('[ErrorBoundary] Uncaught error:', error, info.componentStack);
  }

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-8 text-center">
        <div className="w-16 h-16 rounded-2xl bg-red-100 dark:bg-red-950 flex items-center justify-center mb-5">
          <AlertTriangle size={28} className="text-red-600 dark:text-red-400" />
        </div>

        <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
          Something went wrong
        </h2>
        <p className="text-sm text-gray-500 dark:text-gray-400 max-w-sm mb-6">
          An unexpected error occurred. Refreshing the page usually fixes it.
        </p>

        <button
          onClick={() => window.location.reload()}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium transition-colors"
        >
          <RefreshCw size={15} />
          Refresh Page
        </button>

        {/* Show error detail in development only */}
        {import.meta.env.DEV && this.state.error && (
          <pre className="mt-6 text-xs text-left text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40 rounded-xl p-4 max-w-lg w-full overflow-auto border border-red-200 dark:border-red-800">
            {this.state.error.toString()}
          </pre>
        )}
      </div>
    );
  }
}
