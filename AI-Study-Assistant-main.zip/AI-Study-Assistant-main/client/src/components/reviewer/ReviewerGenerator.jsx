import { useState } from 'react';
import { BookOpen, Sparkles, Save, Loader2, AlertCircle, ChevronDown } from 'lucide-react';
import toast from 'react-hot-toast';
import reviewerService from '../../services/reviewer.service';
import ReviewerContent from './ReviewerContent';
import { cn } from '../../utils/cn';

const SUBJECTS = [
  'Programming', 'Data Structures', 'Algorithms', 'Web Development',
  'Database Systems', 'Computer Networks', 'Operating Systems',
  'Discrete Mathematics', 'Calculus', 'Linear Algebra', 'Statistics',
  'Physics', 'Software Engineering', 'IT Fundamentals', 'General Computer Science',
];

const REVIEWER_TYPES = [
  {
    value:       'comprehensive',
    label:       'Comprehensive',
    description: 'Full review with all sections, examples, and misconceptions',
  },
  {
    value:       'summary',
    label:       'Quick Summary',
    description: 'Concise key points under 600 words — great for last-minute review',
  },
  {
    value:       'key_concepts',
    label:       'Key Concepts',
    description: 'Glossary-style reference with definitions and relationships',
  },
  {
    value:       'q_and_a',
    label:       'Q & A',
    description: '10–15 practice questions with detailed answers',
  },
];

export default function ReviewerGenerator({ onSaved }) {
  // ── Form state ─────────────────────────────────────────────────────────
  const [topic,        setTopic]        = useState('');
  const [subject,      setSubject]      = useState(SUBJECTS[0]);
  const [reviewerType, setReviewerType] = useState('comprehensive');
  const [inputText,    setInputText]    = useState('');
  const [showNotes,    setShowNotes]    = useState(false);

  // ── Generation state ───────────────────────────────────────────────────
  const [preview,    setPreview]    = useState('');
  const [generating, setGenerating] = useState(false);
  const [genError,   setGenError]   = useState('');

  // ── Save state ─────────────────────────────────────────────────────────
  const [saveTitle, setSaveTitle] = useState('');
  const [saving,    setSaving]    = useState(false);
  const [saveError, setSaveError] = useState('');

  // ── Generate ───────────────────────────────────────────────────────────
  async function handleGenerate(e) {
    e.preventDefault();
    if (!topic.trim()) return;

    setGenerating(true);
    setGenError('');
    setPreview('');
    setSaveTitle('');

    try {
      const data = await reviewerService.generate(
        topic.trim(), subject, reviewerType, inputText,
      );
      setPreview(data.content);
      setSaveTitle(topic.trim().slice(0, 100));
    } catch (err) {
      setGenError(
        err.response?.data?.error ||
        err.response?.data?.errors?.[0]?.msg ||
        'Failed to generate reviewer. Please try again.',
      );
    } finally {
      setGenerating(false);
    }
  }

  // ── Save ───────────────────────────────────────────────────────────────
  async function handleSave() {
    if (!saveTitle.trim() || !preview) return;
    setSaving(true);
    setSaveError('');
    try {
      const saved = await reviewerService.save(saveTitle.trim(), subject, preview);
      setPreview('');
      setSaveTitle('');
      setTopic('');
      setInputText('');
      toast.success(`"${saved.title}" saved to My Reviewers!`);
      onSaved?.(saved);
    } catch (err) {
      const msg = err.response?.data?.error || 'Failed to save reviewer. Please try again.';
      setSaveError(msg);
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  }

  const selectedType = REVIEWER_TYPES.find(t => t.value === reviewerType);

  return (
    <div className="space-y-6">

      {/* ── Form ──────────────────────────────────────────────────────── */}
      <form
        onSubmit={handleGenerate}
        className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 space-y-5"
      >
        <div className="flex items-center gap-2 mb-1">
          <BookOpen size={18} className="text-sky-500" />
          <h2 className="text-base font-semibold text-gray-900 dark:text-white">
            Generate Study Reviewer
          </h2>
        </div>

        {/* Topic */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
            Topic <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={topic}
            onChange={e => setTopic(e.target.value)}
            placeholder="e.g. Binary search trees, React hooks, Newton's laws…"
            maxLength={200}
            required
            className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent text-sm transition-shadow"
          />
        </div>

        {/* Subject + Type row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Subject
            </label>
            <select
              value={subject}
              onChange={e => setSubject(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500 text-sm"
            >
              {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Reviewer Type
            </label>
            <select
              value={reviewerType}
              onChange={e => setReviewerType(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500 text-sm"
            >
              {REVIEWER_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>
        </div>

        {/* Type description chip */}
        {selectedType && (
          <p className="text-xs text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-800 rounded-lg px-3 py-2">
            <span className="font-medium text-gray-700 dark:text-gray-300">{selectedType.label}:</span>{' '}
            {selectedType.description}
          </p>
        )}

        {/* Optional notes collapsible */}
        <div>
          <button
            type="button"
            onClick={() => setShowNotes(v => !v)}
            className="flex items-center gap-1.5 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
          >
            <ChevronDown
              size={15}
              className={cn('transition-transform', showNotes && 'rotate-180')}
            />
            {showNotes ? 'Hide' : 'Add'} your own notes (optional)
          </button>

          {showNotes && (
            <div className="mt-3">
              <textarea
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                placeholder="Paste your class notes, textbook excerpts, or any material you want the reviewer to be based on…"
                maxLength={5000}
                rows={6}
                className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-sky-500 text-sm resize-y transition-shadow"
              />
              <div className="flex justify-between mt-1">
                <p className="text-xs text-gray-400">
                  The AI will base the reviewer on your notes instead of general knowledge.
                </p>
                <span className="text-xs text-gray-400 tabular-nums">
                  {inputText.length}/5000
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Error */}
        {genError && (
          <div className="flex items-start gap-2 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 text-red-700 dark:text-red-400 rounded-xl px-4 py-3 text-sm">
            <AlertCircle size={15} className="shrink-0 mt-0.5" />
            <span>{genError}</span>
          </div>
        )}

        {/* Generate button */}
        <button
          type="submit"
          disabled={generating || !topic.trim()}
          className={cn(
            'flex items-center justify-center gap-2 w-full py-3 rounded-xl font-medium text-sm transition-colors',
            generating || !topic.trim()
              ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed'
              : 'bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white cursor-pointer',
          )}
        >
          {generating ? (
            <><Loader2 size={16} className="animate-spin" /> Generating reviewer…</>
          ) : (
            <><Sparkles size={16} /> Generate {selectedType?.label} Reviewer</>
          )}
        </button>
      </form>

      {/* ── Preview ───────────────────────────────────────────────────── */}
      {preview && (
        <div className="space-y-5">
          {/* Rendered markdown preview */}
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-5 pb-4 border-b border-gray-100 dark:border-gray-800">
              <BookOpen size={16} className="text-sky-500" />
              <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">Preview</span>
            </div>
            <ReviewerContent content={preview} />
          </div>

          {/* Save block */}
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Save this reviewer</h3>
            <input
              type="text"
              value={saveTitle}
              onChange={e => setSaveTitle(e.target.value)}
              placeholder="Reviewer title (e.g. Data Structures Midterm Review)"
              maxLength={150}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-sky-500 text-sm transition-shadow"
            />

            {saveError && (
              <div className="flex items-start gap-2 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 text-red-700 dark:text-red-400 rounded-xl px-4 py-3 text-sm">
                <AlertCircle size={15} className="shrink-0 mt-0.5" />
                <span>{saveError}</span>
              </div>
            )}

            <button
              onClick={handleSave}
              disabled={saving || !saveTitle.trim()}
              className={cn(
                'flex items-center justify-center gap-2 w-full py-2.5 rounded-xl font-medium text-sm transition-colors',
                saving || !saveTitle.trim()
                  ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer',
              )}
            >
              {saving
                ? <><Loader2 size={15} className="animate-spin" /> Saving…</>
                : <><Save size={15} /> Save Reviewer</>
              }
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
