import { useState } from 'react';
import { BookOpen, Trash2, Eye, Pencil, Check, X, Calendar, FileText } from 'lucide-react';
import { formatDate } from '../../utils/formatDate';
import { cn } from '../../utils/cn';

function wordCount(text) {
  return text?.trim().split(/\s+/).filter(w => w.length > 0).length ?? 0;
}

const SUBJECT_COLORS = {
  programming:        'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300',
  'data structures':  'bg-violet-100 dark:bg-violet-950 text-violet-700 dark:text-violet-300',
  mathematics:        'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300',
  physics:            'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300',
};

function subjectColor(subject) {
  return SUBJECT_COLORS[subject?.toLowerCase()] ??
    'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400';
}

export default function ReviewerCard({ reviewer, onView, onDelete, onRenameTitle }) {
  const [confirming,  setConfirming]  = useState(false);
  const [deleting,    setDeleting]    = useState(false);
  const [editingTitle, setEditingTitle] = useState(false);
  const [draftTitle,   setDraftTitle]   = useState(reviewer.title);

  const words = wordCount(reviewer.content);

  async function handleDelete() {
    setDeleting(true);
    try   { await onDelete(reviewer.id); }
    finally { setDeleting(false); setConfirming(false); }
  }

  async function handleSaveTitle() {
    if (!draftTitle.trim()) return;
    await onRenameTitle?.(reviewer.id, draftTitle.trim());
    setEditingTitle(false);
  }

  return (
    <div className="group bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5 flex flex-col gap-4 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-md transition-all">

      {/* Icon row */}
      <div className="flex items-start justify-between">
        <div className="w-10 h-10 rounded-xl bg-sky-100 dark:bg-sky-950 flex items-center justify-center shrink-0">
          <BookOpen size={20} className="text-sky-600 dark:text-sky-400" />
        </div>
        <span className={cn('text-xs font-medium px-2.5 py-1 rounded-full', subjectColor(reviewer.subject))}>
          {reviewer.subject}
        </span>
      </div>

      {/* Title (view or edit mode) */}
      <div className="flex-1">
        {editingTitle ? (
          <div className="flex gap-1.5">
            <input
              value={draftTitle}
              onChange={e => setDraftTitle(e.target.value)}
              maxLength={150}
              className="flex-1 text-sm font-semibold bg-gray-50 dark:bg-gray-800 border border-indigo-400 dark:border-indigo-600 rounded-lg px-2.5 py-1.5 text-gray-900 dark:text-white focus:outline-none"
              autoFocus
              onKeyDown={e => {
                if (e.key === 'Enter') handleSaveTitle();
                if (e.key === 'Escape') { setDraftTitle(reviewer.title); setEditingTitle(false); }
              }}
            />
            <button onClick={handleSaveTitle} className="p-1.5 text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors">
              <Check size={14} />
            </button>
            <button onClick={() => { setDraftTitle(reviewer.title); setEditingTitle(false); }} className="p-1.5 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors">
              <X size={14} />
            </button>
          </div>
        ) : (
          <div className="flex items-start gap-1.5">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white leading-snug line-clamp-2 flex-1">
              {reviewer.title}
            </h3>
            <button
              onClick={() => setEditingTitle(true)}
              className="opacity-0 group-hover:opacity-100 shrink-0 p-1 text-gray-400 hover:text-indigo-500 transition-all"
              aria-label="Rename reviewer"
            >
              <Pencil size={12} />
            </button>
          </div>
        )}

        <div className="flex items-center gap-3 mt-2 text-xs text-gray-400 dark:text-gray-500">
          <span className="flex items-center gap-1">
            <Calendar size={11} />
            {formatDate(reviewer.createdAt)}
          </span>
          <span className="flex items-center gap-1">
            <FileText size={11} />
            {words.toLocaleString()} words
          </span>
        </div>
      </div>

      {/* Actions */}
      {confirming ? (
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500 dark:text-gray-400">Delete this reviewer?</span>
          <div className="flex gap-2">
            <button onClick={() => setConfirming(false)} className="text-xs px-2.5 py-1 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
              Cancel
            </button>
            <button onClick={handleDelete} disabled={deleting} className="text-xs px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white disabled:opacity-50 transition-colors">
              {deleting ? 'Deleting…' : 'Delete'}
            </button>
          </div>
        </div>
      ) : (
        <div className="flex gap-2">
          <button
            onClick={() => onView(reviewer.id)}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white text-sm font-medium transition-colors"
          >
            <Eye size={14} />
            View
          </button>
          <button
            onClick={() => setConfirming(true)}
            className={cn(
              'p-2 rounded-xl border border-gray-200 dark:border-gray-700',
              'text-gray-400 hover:text-red-500 dark:hover:text-red-400',
              'hover:border-red-200 dark:hover:border-red-800',
              'hover:bg-red-50 dark:hover:bg-red-950/40 transition-all',
            )}
            aria-label="Delete reviewer"
          >
            <Trash2 size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
