import { useRef, useState } from 'react';
import { Upload, FileText, X, CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import materialService from '../../services/material.service';
import { cn } from '../../utils/cn';

const MAX_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB
const ALLOWED_TYPES  = new Set(['application/pdf', 'image/jpeg', 'image/png', 'image/webp']);
const ALLOWED_LABEL  = 'PDF, JPG, PNG, or WebP';

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  if (bytes < 1024)         return `${bytes} B`;
  if (bytes < 1024 ** 2)   return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

// ── UploadState ────────────────────────────────────────────────────────────
// Separate component to clearly show the progress / result after upload.

function UploadState({ state, progress, fileName, error, onReset }) {
  if (state === 'idle') return null;

  return (
    <div className="mt-4 space-y-2">
      {state === 'uploading' && (
        <div>
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mb-1.5">
            <span className="truncate max-w-[60%]">{fileName}</span>
            <span>{progress < 100 ? `${progress}%` : 'Processing…'}</span>
          </div>
          <div className="h-1.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className={cn(
                'h-full rounded-full transition-all duration-300',
                progress < 100 ? 'bg-indigo-500' : 'bg-amber-500 animate-pulse',
              )}
              style={{ width: `${Math.max(progress, 5)}%` }}
            />
          </div>
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
            {progress < 100 ? 'Uploading file…' : 'Extracting text and saving…'}
          </p>
        </div>
      )}

      {state === 'success' && (
        <div className="flex items-start gap-2 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-emerald-700 dark:text-emerald-400 rounded-xl px-4 py-3 text-sm">
          <CheckCircle size={15} className="shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-medium">Uploaded!</span> {fileName} is ready to summarise.
          </div>
          <button onClick={onReset} className="shrink-0 opacity-60 hover:opacity-100">
            <X size={14} />
          </button>
        </div>
      )}

      {state === 'error' && (
        <div className="flex items-start gap-2 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 text-red-700 dark:text-red-400 rounded-xl px-4 py-3 text-sm">
          <AlertCircle size={15} className="shrink-0 mt-0.5" />
          <div className="flex-1">{error}</div>
          <button onClick={onReset} className="shrink-0 opacity-60 hover:opacity-100">
            <X size={14} />
          </button>
        </div>
      )}
    </div>
  );
}

// ── FileUploader ───────────────────────────────────────────────────────────

export default function FileUploader({ onUploaded }) {
  const inputRef = useRef(null);

  const [dragging,  setDragging]  = useState(false);
  const [uploadState, setUploadState] = useState('idle'); // 'idle' | 'uploading' | 'success' | 'error'
  const [progress,  setProgress]  = useState(0);
  const [fileName,  setFileName]  = useState('');
  const [error,     setError]     = useState('');
  const [title,     setTitle]     = useState('');

  function validateFile(file) {
    if (!ALLOWED_TYPES.has(file.type)) {
      return `"${file.name}" is not a supported format. Please upload a ${ALLOWED_LABEL}.`;
    }
    if (file.size > MAX_SIZE_BYTES) {
      return `"${file.name}" is ${formatBytes(file.size)}. Files must be 10 MB or smaller.`;
    }
    return null;
  }

  async function handleFile(file) {
    const validationError = validateFile(file);
    if (validationError) {
      setError(validationError);
      setUploadState('error');
      return;
    }

    setFileName(file.name);
    setProgress(0);
    setUploadState('uploading');

    try {
      const result = await materialService.upload(file, title || file.name, (pct) => {
        setProgress(pct);
      });
      setUploadState('success');
      setTitle('');
      onUploaded?.(result.material);
    } catch (err) {
      const msg =
        err.response?.data?.error ||
        (err.response?.status === 413 ? 'File must be 10 MB or smaller.' : 'Upload failed. Please try again.');
      setError(msg);
      setUploadState('error');
    }
  }

  // ── Drag handlers ─────────────────────────────────────────────────────────
  function onDragOver(e) {
    e.preventDefault();
    setDragging(true);
  }

  function onDragLeave(e) {
    // Only clear when leaving the drop zone, not child elements
    if (!e.currentTarget.contains(e.relatedTarget)) setDragging(false);
  }

  function onDrop(e) {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }

  function onInputChange(e) {
    const file = e.target.files[0];
    if (file) handleFile(file);
    e.target.value = ''; // reset so same file can be re-selected
  }

  function resetState() {
    setUploadState('idle');
    setProgress(0);
    setFileName('');
    setError('');
  }

  const isUploading = uploadState === 'uploading';

  return (
    <div>
      {/* Optional title input */}
      <div className="mb-3">
        <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1.5">
          Title (optional — defaults to file name)
        </label>
        <input
          type="text"
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="e.g. Chapter 3 - Sorting Algorithms"
          maxLength={200}
          disabled={isUploading}
          className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm disabled:opacity-50 transition-shadow"
        />
      </div>

      {/* Drop zone */}
      <div
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
        onClick={() => !isUploading && inputRef.current?.click()}
        className={cn(
          'relative border-2 border-dashed rounded-2xl p-8 text-center transition-all',
          'cursor-pointer select-none',
          dragging
            ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/30'
            : 'border-gray-300 dark:border-gray-700 hover:border-indigo-400 dark:hover:border-indigo-600 hover:bg-gray-50 dark:hover:bg-gray-800/50',
          isUploading && 'pointer-events-none opacity-60',
        )}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,image/jpeg,image/png,image/webp"
          onChange={onInputChange}
          className="hidden"
          disabled={isUploading}
        />

        {isUploading ? (
          <Loader2 size={32} className="mx-auto text-indigo-500 animate-spin mb-3" />
        ) : (
          <div className={cn(
            'w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4 transition-colors',
            dragging
              ? 'bg-indigo-100 dark:bg-indigo-900'
              : 'bg-gray-100 dark:bg-gray-800',
          )}>
            {dragging
              ? <FileText size={26} className="text-indigo-600 dark:text-indigo-400" />
              : <Upload size={26} className="text-gray-400 dark:text-gray-500" />
            }
          </div>
        )}

        <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          {dragging
            ? 'Drop your file here'
            : isUploading
            ? 'Uploading…'
            : 'Drag & drop a file, or click to browse'
          }
        </p>
        <p className="text-xs text-gray-400 dark:text-gray-500">
          {ALLOWED_LABEL} · Max 10 MB
        </p>
      </div>

      <UploadState
        state={uploadState}
        progress={progress}
        fileName={fileName}
        error={error}
        onReset={resetState}
      />
    </div>
  );
}
