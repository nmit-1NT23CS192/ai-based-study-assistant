const prisma = require('../utils/prismaClient');

const FEATURES = ['chat', 'flashcard', 'reviewer', 'summarizer', 'debugger'];
const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// ── getUserAnalytics ────────────────────────────────────────────────────────
/**
 * Returns the authenticated user's personal study analytics.
 * All queries are scoped to req.user.userId — students only see their own data.
 *
 * Returns:
 *   weeklyChart    — per-day, per-feature AI call counts for the last 7 days
 *   featureBreakdown — total calls per feature (last 30 days) for the pie chart
 *   contentCounts  — items the user has created across all features
 *   mostActiveDay  — date + call count of their busiest study day (last 30 days)
 *   weeklyTotal    — total AI calls in the last 7 days
 *   tokensThisWeek — total tokens consumed in the last 7 days
 */
async function getUserAnalytics(req, res) {
  const userId        = req.user.userId;
  const now           = new Date();
  const sevenDaysAgo  = new Date(now - 7  * 24 * 60 * 60 * 1000);
  const thirtyDaysAgo = new Date(now - 30 * 24 * 60 * 60 * 1000);

  try {
    // ── All queries in parallel ────────────────────────────────────────────
    const [
      weeklyLogs,
      monthlyLogs,
      flashcardSetCount,
      reviewerCount,
      noteCount,
      materialCount,
      chatSessionCount,
    ] = await Promise.all([
      // Raw logs for the 7-day bar chart
      prisma.aiUsageLog.findMany({
        where:   { userId, createdAt: { gte: sevenDaysAgo } },
        select:  { feature: true, tokensUsed: true, createdAt: true },
        orderBy: { createdAt: 'asc' },
      }),
      // Raw logs for 30-day feature breakdown + most-active day
      prisma.aiUsageLog.findMany({
        where:   { userId, createdAt: { gte: thirtyDaysAgo } },
        select:  { feature: true, createdAt: true },
      }),
      prisma.flashcardSet.count({ where: { userId } }),
      prisma.reviewer.count({ where: { userId } }),
      prisma.note.count({ where: { userId } }),
      prisma.studyMaterial.count({ where: { userId } }),
      prisma.chatSession.count({ where: { userId } }),
    ]);

    // ── Build 7-day chart data ──────────────────────────────────────────────
    // Generate all 7 days (oldest first) so the chart always has a full week
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(now);
      d.setDate(d.getDate() - (6 - i));
      return d.toISOString().split('T')[0];
    });

    const weeklyMap = {};
    let weeklyTotal  = 0;
    let tokensThisWeek = 0;
    for (const log of weeklyLogs) {
      const date = log.createdAt.toISOString().split('T')[0];
      if (!weeklyMap[date]) weeklyMap[date] = {};
      weeklyMap[date][log.feature] = (weeklyMap[date][log.feature] ?? 0) + 1;
      weeklyTotal++;
      tokensThisWeek += log.tokensUsed ?? 0;
    }

    const weeklyChart = days.map(date => {
      const dayData = weeklyMap[date] ?? {};
      const dayLabel = new Date(date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short' });
      const row = { date, day: dayLabel };
      for (const f of FEATURES) row[f] = dayData[f] ?? 0;
      return row;
    });

    // ── Feature breakdown (30-day pie chart) ───────────────────────────────
    const featureMap = {};
    for (const log of monthlyLogs) {
      featureMap[log.feature] = (featureMap[log.feature] ?? 0) + 1;
    }
    const featureBreakdown = featureMap;

    // ── Most active study day (last 30 days) ───────────────────────────────
    const dayCountMap = {};
    for (const log of monthlyLogs) {
      const date = log.createdAt.toISOString().split('T')[0];
      dayCountMap[date] = (dayCountMap[date] ?? 0) + 1;
    }
    const sortedDays = Object.entries(dayCountMap).sort((a, b) => b[1] - a[1]);
    const mostActiveDay = sortedDays.length > 0
      ? {
          date:    sortedDays[0][0],
          count:   sortedDays[0][1],
          dayName: DAY_NAMES[new Date(sortedDays[0][0] + 'T12:00:00').getDay()],
        }
      : null;

    // ── Most used feature ──────────────────────────────────────────────────
    const topFeatureEntry = Object.entries(featureMap).sort((a, b) => b[1] - a[1])[0];
    const topFeature = topFeatureEntry
      ? { key: topFeatureEntry[0], count: topFeatureEntry[1] }
      : null;

    return res.status(200).json({
      weeklyChart,
      featureBreakdown,
      contentCounts: {
        flashcardSets: flashcardSetCount,
        reviewers:     reviewerCount,
        notes:         noteCount,
        materials:     materialCount,
        chatSessions:  chatSessionCount,
      },
      mostActiveDay,
      topFeature,
      weeklyTotal,
      tokensThisWeek,
      monthlyTotal: monthlyLogs.length,
    });

  } catch (err) {
    console.error('[analytics.getUserAnalytics]', err);
    return res.status(500).json({ error: 'Failed to fetch analytics.' });
  }
}

module.exports = { getUserAnalytics };
