const { body, validationResult } = require('express-validator');

// ── Core helper ────────────────────────────────────────────────────────────

/**
 * Terminal step in any validation chain.
 * Returns 422 Unprocessable Entity with an array of field errors.
 * express-validator's array format: [{ type, msg, path, location }]
 */
function validateRequest(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  next();
}

// ── Auth validation chains ─────────────────────────────────────────────────
// Each export is an array of middleware — include validateRequest at the end
// so route definitions stay clean (no need to add it separately).

const registerValidation = [
  body('name')
    .trim()
    .notEmpty().withMessage('Name is required')
    .isLength({ min: 2, max: 50 }).withMessage('Name must be 2–50 characters'),

  body('email')
    .trim()
    .notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Please provide a valid email address')
    // normalizeEmail lowercases and strips dots/aliases so
    // "User@Gmail.com" and "user@gmail.com" resolve to the same address.
    .normalizeEmail(),

  body('password')
    .notEmpty().withMessage('Password is required')
    .isLength({ min: 6 }).withMessage('Password must be at least 6 characters')
    .matches(/\d/).withMessage('Password must contain at least one number'),

  validateRequest,
];

const loginValidation = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Please provide a valid email address')
    .normalizeEmail(),

  body('password')
    .notEmpty().withMessage('Password is required'),

  validateRequest,
];

module.exports = { validateRequest, registerValidation, loginValidation };
