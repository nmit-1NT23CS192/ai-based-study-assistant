import { useState } from 'react';
import { Layers, BookOpen, Trash2, Play, Calendar } from 'lucide-react';
import { formatDate } from '../../utils/formatDate';
import { cn } from '../../utils/cn';

export default function FlashcardSetCard({ set, onStudy, onDelete }) {
  const [confirming, setConfirming] = useState(false);
  const [deleting,   setDeleting]   = useState(false);

  const cardCount = set._count?.flashcards ?? set.flashcards?.length ?? 0;

  async function handleDelete() {
    setDeleting(true);
    try {
      await onDelete(set.id);
    } finally {
      setDeleting(false);
      setConfirming(false);
    }
  }

  return (
    <div className="group bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5 flex flex-col gap-4 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-md transition-all">

      {/* Icon + subject badge */}
      <div className="flex items-start justify-between">
        <div className="w-10 h-10 rounded-xl bg-violet-100 dark:bg-violet-950 flex items-center justify-center">
          <Layers size={20} className="text-violet-600 dark:text-violet-400" />
        </div>
        <span className="text-xs font-medium px-2 py-1 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400">
          {set.subject}
        </span>
      </div>

      {/* Title */}
      <div className="flex-1">
        <h3 className="font-semibold text-gray-900 dark:text-white leading-snug line-clamp-2">
          {set.title}
        </h3>
        <div className="flex items-center gap-3 mt-2 text-xs text-gray-400 dark:text-gray-500">
          <span className="flex items-center gap-1">
            <BookOpen size={12} />
            {cardCount} {cardCount === 1 ? 'card' : 'cards'}
          </span>
          <span className="flex items-center gap-1">
            <Calendar size={12} />
            {formatDate(set.createdAt)}
          </span>
        </div>
      </div>

      {/* Actions */}
      {confirming ? (
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500 dark:text-gray-400">Delete this set?</span>
          <div className="flex gap-2">
            <button
              onClick={() => setConfirming(false)}
              className="text-xs px-2.5 py-1 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleDelete}
              disabled={deleting}
              className="text-xs px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white disabled:opacity-50 transition-colors"
            >
              {deleting ? 'Deleting…' : 'Delete'}
            </button>
          </div>
        </div>
      ) : (
        <div className="flex gap-2">
          <button
            onClick={() => onStudy(set.id)}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-medium transition-colors"
          >
            <Play size={14} />
            Study
          </button>
          <button
            onClick={() => setConfirming(true)}
            className={cn(
              'p-2 rounded-xl border border-gray-200 dark:border-gray-700',
              'text-gray-400 hover:text-red-500 dark:hover:text-red-400',
              'hover:border-red-200 dark:hover:border-red-800',
              'hover:bg-red-50 dark:hover:bg-red-950/40 transition-all',
            )}
            aria-label="Delete set"
          >
            <Trash2 size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
