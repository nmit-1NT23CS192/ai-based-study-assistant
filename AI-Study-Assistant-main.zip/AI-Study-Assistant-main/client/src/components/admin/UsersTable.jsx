import { useState } from 'react';
import { Search, ChevronUp, ChevronDown, ShieldCheck, ShieldOff, Loader2 } from 'lucide-react';
import { formatDate } from '../../utils/formatDate';
import { cn }          from '../../utils/cn';

// ── Sort helpers ───────────────────────────────────────────────────────────

function SortIcon({ field, sortField, sortDir }) {
  if (sortField !== field) return <ChevronUp size={12} className="text-gray-300 dark:text-gray-600" />;
  return sortDir === 'asc'
    ? <ChevronUp   size={12} className="text-indigo-500" />
    : <ChevronDown size={12} className="text-indigo-500" />;
}

function sortUsers(users, field, dir) {
  return [...users].sort((a, b) => {
    let va = a[field] ?? 0;
    let vb = b[field] ?? 0;
    if (field === 'aiCalls') { va = a._count?.aiUsageLogs ?? 0; vb = b._count?.aiUsageLogs ?? 0; }
    if (typeof va === 'string') va = va.toLowerCase();
    if (typeof vb === 'string') vb = vb.toLowerCase();
    if (va < vb) return dir === 'asc' ? -1 :  1;
    if (va > vb) return dir === 'asc' ?  1 : -1;
    return 0;
  });
}

// ── BanButton ──────────────────────────────────────────────────────────────

function BanButton({ user, onToggle }) {
  const [loading, setLoading] = useState(false);

  async function handleClick() {
    setLoading(true);
    try   { await onToggle(user.id); }
    finally { setLoading(false); }
  }

  if (user.role === 'ADMIN') return null; // Cannot ban admins

  return (
    <button
      onClick={handleClick}
      disabled={loading}
      title={user.isActive ? 'Ban user' : 'Unban user'}
      className={cn(
        'flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg font-medium transition-colors disabled:opacity-50',
        user.isActive
          ? 'border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40'
          : 'border border-emerald-200 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40',
      )}
    >
      {loading
        ? <Loader2 size={11} className="animate-spin" />
        : user.isActive
        ? <ShieldOff size={11} />
        : <ShieldCheck size={11} />
      }
      {user.isActive ? 'Ban' : 'Unban'}
    </button>
  );
}

// ── UsersTable ─────────────────────────────────────────────────────────────

const COLUMNS = [
  { key: 'name',     label: 'Name'      },
  { key: 'email',    label: 'Email'     },
  { key: 'role',     label: 'Role'      },
  { key: 'createdAt', label: 'Joined'   },
  { key: 'aiCalls',  label: 'AI Calls'  },
  { key: 'isActive', label: 'Status'    },
];

export default function UsersTable({
  users,
  total,
  page,
  totalPages,
  onPageChange,
  onToggleStatus,
  searchValue,
  onSearchChange,
  loading,
}) {
  const [sortField, setSortField] = useState('createdAt');
  const [sortDir,   setSortDir]   = useState('desc');

  function handleSort(field) {
    if (field === sortField) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  }

  const sorted = sortUsers(users, sortField, sortDir);

  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="relative max-w-xs">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
        <input
          type="text"
          value={searchValue}
          onChange={e => onSearchChange(e.target.value)}
          placeholder="Search by name or email…"
          className="w-full pl-8 pr-3 py-2 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-800">
        <table className="min-w-full">
          <thead className="bg-gray-50 dark:bg-gray-800/60">
            <tr>
              {COLUMNS.map(col => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key)}
                  className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:text-gray-800 dark:hover:text-gray-200 select-none"
                >
                  <div className="flex items-center gap-1">
                    {col.label}
                    <SortIcon field={col.key} sortField={sortField} sortDir={sortDir} />
                  </div>
                </th>
              ))}
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Action
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center">
                  <Loader2 size={24} className="animate-spin mx-auto text-indigo-500" />
                </td>
              </tr>
            ) : sorted.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center text-sm text-gray-400">
                  No users found.
                </td>
              </tr>
            ) : sorted.map(user => (
              <tr key={user.id} className="bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-indigo-600 flex items-center justify-center text-xs text-white font-semibold shrink-0">
                      {user.name[0]?.toUpperCase()}
                    </div>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{user.name}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500 dark:text-gray-400">{user.email}</td>
                <td className="px-4 py-3">
                  <span className={cn(
                    'inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium',
                    user.role === 'ADMIN'
                      ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400',
                  )}>
                    {user.role}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500 dark:text-gray-400">
                  {formatDate(user.createdAt)}
                </td>
                <td className="px-4 py-3 text-sm font-mono text-gray-700 dark:text-gray-300">
                  {(user._count?.aiUsageLogs ?? 0).toLocaleString()}
                </td>
                <td className="px-4 py-3">
                  <span className={cn(
                    'inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium',
                    user.isActive
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                      : 'bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400',
                  )}>
                    {user.isActive ? 'Active' : 'Banned'}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <BanButton user={user} onToggle={onToggleStatus} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500 dark:text-gray-400">
            {total} users · Page {page} of {totalPages}
          </span>
          <div className="flex gap-1">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
              <button
                key={p}
                onClick={() => onPageChange(p)}
                className={cn(
                  'w-8 h-8 rounded-lg text-xs font-medium transition-colors',
                  p === page
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800',
                )}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
