import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from './LoadingSpinner';

/**
 * Route guard that requires both authentication AND the ADMIN role.
 * Non-admin users are redirected to /dashboard rather than /login
 * so they know they're authenticated but lack permission.
 *
 * Supports both patterns:
 *   <AdminRoute><AdminPage /></AdminRoute>   — wrapper
 *   <Route element={<AdminRoute />}>…       — layout route
 */
export default function AdminRoute({ children }) {
  const { user, loading } = useAuth();

  if (loading) return <LoadingSpinner fullScreen size={32} />;
  if (!user)              return <Navigate to="/login"     replace />;
  if (user.role !== 'ADMIN') return <Navigate to="/dashboard" replace />;

  return children ?? <Outlet />;
}
