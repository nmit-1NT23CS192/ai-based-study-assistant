import { useCallback, useEffect, useState } from 'react';
import { Users, Zap, FileText, Activity, ShieldAlert, BarChart2 } from 'lucide-react';
import adminService from '../services/admin.service';
import UsersTable   from '../components/admin/UsersTable';
import UsageChart   from '../components/admin/UsageChart';
import LoadingSpinner from '../components/LoadingSpinner';
import { cn }       from '../utils/cn';

// ── Stat card ──────────────────────────────────────────────────────────────

function StatCard({ label, value, icon: Icon, color }) {
  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center', color.bg)}>
          <Icon size={20} className={color.icon} />
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 dark:text-white tabular-nums">
        {value?.toLocaleString() ?? '—'}
      </p>
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{label}</p>
    </div>
  );
}

const STAT_CARDS = [
  { key: 'totalUsers',    label: 'Total Users',       icon: Users,    color: { bg: 'bg-indigo-100 dark:bg-indigo-950', icon: 'text-indigo-600 dark:text-indigo-400' } },
  { key: 'totalAICalls',  label: 'Total AI Calls',    icon: Zap,      color: { bg: 'bg-violet-100 dark:bg-violet-950', icon: 'text-violet-600 dark:text-violet-400' } },
  { key: 'totalMaterials', label: 'Study Materials',  icon: FileText, color: { bg: 'bg-red-100 dark:bg-red-950',       icon: 'text-red-600 dark:text-red-400' } },
  { key: 'activeToday',   label: 'AI Calls Today',    icon: Activity, color: { bg: 'bg-emerald-100 dark:bg-emerald-950', icon: 'text-emerald-600 dark:text-emerald-400' } },
];

const TABS = [
  { id: 'users', label: 'Users',     icon: Users     },
  { id: 'usage', label: 'AI Usage',  icon: BarChart2 },
];

// ── AdminPage ──────────────────────────────────────────────────────────────

export default function AdminPage() {
  const [tab,         setTab]         = useState('users');
  const [dashStats,   setDashStats]   = useState(null);
  const [usageStats,  setUsageStats]  = useState([]);
  const [users,       setUsers]       = useState([]);
  const [userMeta,    setUserMeta]    = useState({ total: 0, page: 1, totalPages: 1 });
  const [search,      setSearch]      = useState('');
  const [page,        setPage]        = useState(1);
  const [loadingDash, setLoadingDash] = useState(true);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [loadingUsage, setLoadingUsage] = useState(true);

  // ── Fetch dashboard stats on mount ─────────────────────────────────────
  useEffect(() => {
    adminService.getDashboardStats()
      .then(setDashStats)
      .catch(() => {})
      .finally(() => setLoadingDash(false));
  }, []);

  // ── Fetch usage stats when "AI Usage" tab is opened ────────────────────
  useEffect(() => {
    if (tab !== 'usage') return;
    setLoadingUsage(true);
    adminService.getAIUsageStats()
      .then(setUsageStats)
      .catch(() => {})
      .finally(() => setLoadingUsage(false));
  }, [tab]);

  // ── Fetch users (re-fetches on page or search change) ──────────────────
  const loadUsers = useCallback(async (pg, q) => {
    setLoadingUsers(true);
    try {
      const data = await adminService.getUsers({ page: pg, search: q });
      setUsers(data.users);
      setUserMeta({ total: data.total, page: data.page, totalPages: data.totalPages });
    } catch { /* silently fail */ } finally {
      setLoadingUsers(false);
    }
  }, []);

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => { setPage(1); loadUsers(1, search); }, 400);
    return () => clearTimeout(t);
  }, [search, loadUsers]);

  useEffect(() => { loadUsers(page, search); }, [page, loadUsers, search]);

  // ── Toggle user status optimistically ──────────────────────────────────
  async function handleToggleStatus(userId) {
    const updated = await adminService.toggleUserStatus(userId);
    setUsers(prev => prev.map(u => u.id === updated.id ? { ...u, isActive: updated.isActive } : u));
    // Refresh dashboard count
    adminService.getDashboardStats().then(setDashStats).catch(() => {});
  }

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-100 dark:bg-red-950 flex items-center justify-center">
            <ShieldAlert size={20} className="text-red-600 dark:text-red-400" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Admin Panel</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Manage users and monitor AI usage
            </p>
          </div>
        </div>

        {/* Stats grid */}
        {loadingDash ? (
          <div className="flex items-center justify-center py-10">
            <LoadingSpinner size={24} />
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {STAT_CARDS.map(({ key, label, icon, color }) => (
              <StatCard
                key={key}
                label={label}
                value={dashStats?.[key]}
                icon={icon}
                color={color}
              />
            ))}
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-gray-100 dark:bg-gray-800/60 rounded-xl w-fit">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={cn(
                'flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all',
                tab === id
                  ? 'bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200',
              )}
            >
              <Icon size={15} />
              {label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        {tab === 'users' && (
          <UsersTable
            users={users}
            total={userMeta.total}
            page={userMeta.page}
            totalPages={userMeta.totalPages}
            loading={loadingUsers}
            searchValue={search}
            onSearchChange={setSearch}
            onPageChange={setPage}
            onToggleStatus={handleToggleStatus}
          />
        )}

        {tab === 'usage' && (
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
            <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-4">
              AI Calls — Last 30 Days
            </h2>
            {loadingUsage ? (
              <div className="flex items-center justify-center h-48">
                <LoadingSpinner size={24} />
              </div>
            ) : (
              <UsageChart stats={usageStats} />
            )}
          </div>
        )}
      </div>
    </div>
  );
}
