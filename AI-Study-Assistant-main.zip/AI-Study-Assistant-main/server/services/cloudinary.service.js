const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure:     true,
});

/**
 * Upload from a data URI, local path, or remote URL.
 * Used for avatar / image sources that are already string-encoded.
 */
async function uploadFile(fileSource, folder = 'uploads') {
  const result = await cloudinary.uploader.upload(fileSource, { folder });
  return { url: result.secure_url, publicId: result.public_id };
}

/**
 * Upload a raw Node.js Buffer (from Multer memory storage) to Cloudinary.
 *
 * Uses upload_stream instead of upload because:
 *  1. Multer stores files in memory as Buffers, not as paths or data URIs
 *  2. upload_stream accepts a writable stream — we pipe the Buffer to it
 *  3. This avoids writing a temp file to disk (better for serverless/Render)
 *
 * @param {Buffer} buffer   - File contents from multer req.file.buffer
 * @param {object} options  - Cloudinary upload options
 *   - resource_type: 'raw' for PDFs, 'image' for images (default)
 *   - folder: destination folder in Cloudinary
 *   - public_id: optional explicit identifier
 *
 * @returns {{ url: string, publicId: string }}
 */
async function uploadBuffer(buffer, options = {}) {
  return new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(options, (error, result) => {
      if (error) return reject(error);
      resolve({ url: result.secure_url, publicId: result.public_id });
    });
    stream.end(buffer);
  });
}

/**
 * Delete a file from Cloudinary by its public ID.
 * Pass resourceType: 'raw' for PDFs, 'image' (default) for images.
 */
async function deleteFile(publicId, resourceType = 'image') {
  return cloudinary.uploader.destroy(publicId, { resource_type: resourceType });
}

module.exports = { uploadFile, uploadBuffer, deleteFile };
