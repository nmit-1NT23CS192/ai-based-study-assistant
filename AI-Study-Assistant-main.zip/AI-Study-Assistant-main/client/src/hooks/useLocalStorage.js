import { useState } from 'react';

/**
 * useState but persisted in localStorage.
 * Useful for theme preference, draft notes, etc.
 */
function useLocalStorage(key, initialValue) {
  const [stored, setStored] = useState(() => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  function setValue(value) {
    try {
      const valueToStore = value instanceof Function ? value(stored) : value;
      setStored(valueToStore);
      localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (err) {
      console.error(`useLocalStorage [${key}]:`, err);
    }
  }

  return [stored, setValue];
}

export default useLocalStorage;
