import { useState } from 'react';
import { Sparkles, Save, Loader2, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import flashcardService from '../../services/flashcard.service';
import FlashcardPreview from './FlashcardPreview';
import { cn } from '../../utils/cn';

const SUBJECTS = [
  'Programming',
  'Data Structures',
  'Algorithms',
  'Web Development',
  'Database Systems',
  'Computer Networks',
  'Operating Systems',
  'Discrete Mathematics',
  'Calculus',
  'Linear Algebra',
  'Statistics',
  'Physics',
  'Software Engineering',
  'IT Fundamentals',
  'General Computer Science',
];

export default function FlashcardGenerator({ onSaved }) {
  // ── Form state ─────────────────────────────────────────────────────────
  const [topic,   setTopic]   = useState('');
  const [subject, setSubject] = useState(SUBJECTS[0]);
  const [count,   setCount]   = useState(10);

  // ── Generation state ───────────────────────────────────────────────────
  const [cards,      setCards]      = useState([]);
  const [generating, setGenerating] = useState(false);
  const [genError,   setGenError]   = useState('');

  // ── Save state ─────────────────────────────────────────────────────────
  const [setTitle, setSetTitle] = useState('');
  const [saving,   setSaving]   = useState(false);
  const [saveError, setSaveError] = useState('');

  // ── Generate ───────────────────────────────────────────────────────────
  async function handleGenerate(e) {
    e.preventDefault();
    if (!topic.trim()) return;

    setGenerating(true);
    setGenError('');
    setCards([]);
    setSetTitle('');

    try {
      const data = await flashcardService.generate(topic.trim(), subject, count);
      setCards(data.cards);
      // Pre-fill the set title with the topic so the user doesn't have to type it
      setSetTitle(topic.trim().slice(0, 80));
    } catch (err) {
      setGenError(
        err.response?.data?.error ||
        err.response?.data?.errors?.[0]?.msg ||
        'Failed to generate flashcards. Please try again.',
      );
    } finally {
      setGenerating(false);
    }
  }

  // ── Preview edit/remove callbacks ──────────────────────────────────────
  function handleUpdateCard(index, updated) {
    setCards(prev => prev.map((c, i) => (i === index ? updated : c)));
  }

  function handleRemoveCard(index) {
    setCards(prev => prev.filter((_, i) => i !== index));
  }

  // ── Save ───────────────────────────────────────────────────────────────
  async function handleSave() {
    if (!setTitle.trim() || cards.length === 0) return;

    setSaving(true);
    setSaveError('');

    try {
      const saved = await flashcardService.save(setTitle.trim(), subject, cards);
      setCards([]);
      setSetTitle('');
      setTopic('');
      toast.success(`"${saved.title}" saved — ${saved.flashcards.length} cards ready!`);
      onSaved?.(saved);
    } catch (err) {
      const msg = err.response?.data?.error || 'Failed to save. Please try again.';
      setSaveError(msg);
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-8">

      {/* ── Generator form ─────────────────────────────────────────────── */}
      <form
        onSubmit={handleGenerate}
        className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 space-y-5"
      >
        <div className="flex items-center gap-2 mb-1">
          <Sparkles size={18} className="text-violet-500" />
          <h2 className="text-base font-semibold text-gray-900 dark:text-white">
            Generate Flashcards
          </h2>
        </div>

        {/* Topic */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
            Topic
          </label>
          <input
            type="text"
            value={topic}
            onChange={e => setTopic(e.target.value)}
            placeholder="e.g. Binary search trees, React hooks, OSI model…"
            maxLength={150}
            required
            className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm transition-shadow"
          />
        </div>

        {/* Subject + Count row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Subject
            </label>
            <select
              value={subject}
              onChange={e => setSubject(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
            >
              {SUBJECTS.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Number of cards: <span className="text-indigo-600 dark:text-indigo-400 font-bold">{count}</span>
            </label>
            <input
              type="range"
              min={5}
              max={20}
              step={1}
              value={count}
              onChange={e => setCount(Number(e.target.value))}
              className="w-full accent-indigo-600"
            />
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <span>5</span>
              <span>20</span>
            </div>
          </div>
        </div>

        {/* Error */}
        {genError && (
          <div className="flex items-start gap-2 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 text-red-700 dark:text-red-400 rounded-xl px-4 py-3 text-sm">
            <AlertCircle size={15} className="shrink-0 mt-0.5" />
            <span>{genError}</span>
          </div>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={generating || !topic.trim()}
          className={cn(
            'flex items-center justify-center gap-2 w-full py-3 rounded-xl font-medium text-sm transition-colors',
            generating || !topic.trim()
              ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white cursor-pointer',
          )}
        >
          {generating ? (
            <><Loader2 size={16} className="animate-spin" /> Generating {count} cards…</>
          ) : (
            <><Sparkles size={16} /> Generate {count} Flashcards</>
          )}
        </button>
      </form>

      {/* ── Preview section ─────────────────────────────────────────────── */}
      {cards.length > 0 && (
        <div className="space-y-5">
          <FlashcardPreview
            cards={cards}
            onUpdateCard={handleUpdateCard}
            onRemoveCard={handleRemoveCard}
          />

          {/* Save block */}
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
              Save this set
            </h3>
            <input
              type="text"
              value={setTitle}
              onChange={e => setSetTitle(e.target.value)}
              placeholder="Set title (e.g. Data Structures Midterm Review)"
              maxLength={100}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm transition-shadow"
            />

            {saveError && (
              <div className="flex items-start gap-2 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 text-red-700 dark:text-red-400 rounded-xl px-4 py-3 text-sm">
                <AlertCircle size={15} className="shrink-0 mt-0.5" />
                <span>{saveError}</span>
              </div>
            )}

            <button
              onClick={handleSave}
              disabled={saving || !setTitle.trim() || cards.length === 0}
              className={cn(
                'flex items-center justify-center gap-2 w-full py-2.5 rounded-xl font-medium text-sm transition-colors',
                saving || !setTitle.trim() || cards.length === 0
                  ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer',
              )}
            >
              {saving ? (
                <><Loader2 size={15} className="animate-spin" /> Saving…</>
              ) : (
                <><Save size={15} /> Save {cards.length} Cards</>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
