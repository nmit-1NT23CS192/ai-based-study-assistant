import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from './LoadingSpinner';

/**
 * Guards authenticated routes. Supports two usage patterns:
 *
 *   1. Wrapper component (explicit children):
 *      <ProtectedRoute><DashboardPage /></ProtectedRoute>
 *
 *   2. React Router layout route (Outlet — no children):
 *      <Route element={<ProtectedRoute />}>
 *        <Route element={<DashboardLayout />}>
 *          <Route path="/dashboard" element={<DashboardPage />} />
 *        </Route>
 *      </Route>
 */
export default function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();

  if (loading) return <LoadingSpinner fullScreen size={32} />;
  if (!user)   return <Navigate to="/login" replace />;
  return children ?? <Outlet />;
}
