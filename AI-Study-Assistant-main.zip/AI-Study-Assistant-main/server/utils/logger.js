const isProd = process.env.NODE_ENV === 'production';

/**
 * Thin logger wrapper.
 * - logger.log / logger.info  → silent in production (debug/info noise)
 * - logger.warn               → silent in production
 * - logger.error              → always logged (errors must be visible)
 *
 * Morgan handles HTTP access logs; this handles application-level logs.
 */
const logger = {
  log:   (...args) => { if (!isProd) console.log(...args); },
  info:  (...args) => { if (!isProd) console.log('[INFO]', ...args); },
  warn:  (...args) => { if (!isProd) console.warn('[WARN]', ...args); },
  error: (...args) => console.error('[ERROR]', ...args),
};

module.exports = logger;
