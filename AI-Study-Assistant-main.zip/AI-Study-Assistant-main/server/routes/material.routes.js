const { Router } = require('express');
const {
  uploadMaterial,
  getUserMaterials,
  getMaterial,
  summarizeMaterial,
  deleteMaterial,
} = require('../controllers/material.controller');
const { protect }        = require('../middleware/auth.middleware');
const { aiRateLimiter }  = require('../middleware/rateLimiter.middleware');
const { uploadSingle }   = require('../middleware/upload.middleware');

const router = Router();
router.use(protect);

// POST /api/materials/upload
// Authentication runs first; then Multer processes the file in a custom
// callback so LIMIT_FILE_SIZE and file-type errors map to clean HTTP responses.
router.post('/upload', (req, res, next) => {
  uploadSingle(req, res, (err) => {
    if (!err) return next();
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ error: 'File must be 10 MB or smaller.' });
    }
    return res.status(400).json({ error: err.message });
  });
}, uploadMaterial);

router.get('/',                                 getUserMaterials);
router.get('/:materialId',                      getMaterial);
router.post('/:materialId/summarize',           aiRateLimiter, summarizeMaterial);
router.delete('/:materialId',                   deleteMaterial);

module.exports = router;
