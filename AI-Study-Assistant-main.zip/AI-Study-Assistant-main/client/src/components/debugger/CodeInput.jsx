import { useRef, useMemo } from 'react';
import { X } from 'lucide-react';
import { getLanguage } from './LanguageSelector';
import { cn } from '../../utils/cn';

const MAX_CHARS = 8000;
const TAB       = '  '; // 2-space tab

export default function CodeInput({ value, onChange, language, disabled, placeholder }) {
  const textareaRef = useRef(null);
  const gutterRef   = useRef(null);

  // Compute line count to render the gutter — memoised so it only recalculates
  // when the code changes, not on every parent re-render.
  const lineCount = useMemo(
    () => Math.max(1, (value || '').split('\n').length),
    [value],
  );

  // Sync line-number gutter scroll with the textarea scroll
  function handleScroll() {
    if (gutterRef.current && textareaRef.current) {
      gutterRef.current.scrollTop = textareaRef.current.scrollTop;
    }
  }

  // Tab key inserts spaces instead of moving focus
  function handleKeyDown(e) {
    if (e.key === 'Tab') {
      e.preventDefault();
      const { selectionStart: start, selectionEnd: end } = e.target;
      const updated =
        value.slice(0, start) + TAB + value.slice(end);
      onChange(updated);
      // Restore cursor after the inserted spaces
      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = start + TAB.length;
          textareaRef.current.selectionEnd   = start + TAB.length;
        }
      });
    }
  }

  const lang      = getLanguage(language);
  const charsLeft = MAX_CHARS - (value?.length ?? 0);
  const nearLimit = charsLeft < 500;

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 bg-gray-100 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 rounded-t-xl shrink-0">
        <div className="flex items-center gap-2">
          {/* Traffic-light dots (purely decorative, common in code editors) */}
          <span className="w-3 h-3 rounded-full bg-red-400" />
          <span className="w-3 h-3 rounded-full bg-yellow-400" />
          <span className="w-3 h-3 rounded-full bg-green-400" />
          <span className="ml-2 text-xs font-medium text-gray-500 dark:text-gray-400">
            {lang.label}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {nearLimit && (
            <span className={cn(
              'text-xs tabular-nums',
              charsLeft < 100 ? 'text-red-500' : 'text-amber-500',
            )}>
              {charsLeft.toLocaleString()} chars left
            </span>
          )}
          {value && (
            <button
              onClick={() => onChange('')}
              disabled={disabled}
              className="p-1 rounded text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
              aria-label="Clear code"
            >
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Editor area: gutter + textarea */}
      <div className="flex flex-1 overflow-hidden rounded-b-xl border border-t-0 border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-950">
        {/* Line-number gutter */}
        <div
          ref={gutterRef}
          aria-hidden="true"
          className="overflow-hidden select-none shrink-0 text-right font-mono text-xs leading-6 py-3 px-2 bg-gray-50 dark:bg-gray-900 text-gray-400 dark:text-gray-600 border-r border-gray-200 dark:border-gray-700"
          style={{ minWidth: `${String(lineCount).length + 2}ch` }}
        >
          {Array.from({ length: lineCount }, (_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>

        {/* Code textarea */}
        <textarea
          ref={textareaRef}
          value={value}
          onChange={e => {
            if (e.target.value.length <= MAX_CHARS) onChange(e.target.value);
          }}
          onScroll={handleScroll}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          placeholder={placeholder ?? '// Paste your code here…'}
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
          className={cn(
            'flex-1 min-w-0 resize-none outline-none',
            'font-mono text-xs leading-6 py-3 px-3',
            'text-gray-900 dark:text-gray-100',
            'bg-white dark:bg-gray-950',
            'placeholder:text-gray-300 dark:placeholder:text-gray-700',
            'disabled:opacity-50',
          )}
        />
      </div>
    </div>
  );
}
