const jwt = require('jsonwebtoken');

/**
 * Signs a JWT containing only userId and role.
 *
 * Keeping the payload minimal is intentional:
 *   - Smaller token size in every request header
 *   - Email/name changes don't invalidate existing tokens
 *   - Sensitive PII stays out of the (base64-decodable) payload
 */
function generateToken(userId, role) {
  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET is not set in environment variables');
  }

  return jwt.sign(
    { userId, role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

/**
 * Verifies and decodes a JWT.
 * Throws JsonWebTokenError or TokenExpiredError on failure —
 * callers must catch and handle both cases.
 */
function verifyToken(token) {
  return jwt.verify(token, process.env.JWT_SECRET);
}

module.exports = { generateToken, verifyToken };
