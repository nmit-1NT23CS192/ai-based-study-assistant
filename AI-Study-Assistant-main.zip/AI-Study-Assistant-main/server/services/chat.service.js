const prisma = require('../utils/prismaClient');

// ── Helpers ────────────────────────────────────────────────────────────────

/**
 * Derives a session title from the first user message.
 * Truncated to 60 chars — long enough to be meaningful, short enough for the
 * sidebar list UI. A future enhancement could use Gemini to generate a proper title.
 */
function deriveTitle(firstMessage) {
  const cleaned = firstMessage.trim().replace(/\s+/g, ' ');
  return cleaned.length > 60 ? cleaned.slice(0, 57) + '…' : cleaned;
}

// ── createSession ──────────────────────────────────────────────────────────

/**
 * Creates a new ChatSession row for the given user.
 * Called by the controller when no sessionId is provided in the request body.
 */
async function createSession(userId, firstMessage) {
  return prisma.chatSession.create({
    data: {
      userId,
      title: deriveTitle(firstMessage),
    },
  });
}

// ── addMessage ─────────────────────────────────────────────────────────────

/**
 * Persists a single message to chat_messages.
 * @param {string} sessionId
 * @param {'USER'|'ASSISTANT'} role  - Matches the MessageRole Prisma enum
 * @param {string} content
 */
async function addMessage(sessionId, role, content) {
  return prisma.chatMessage.create({
    data: { sessionId, role, content },
  });
}

// ── getLastMessages ────────────────────────────────────────────────────────

/**
 * Returns the last `limit` messages for a session in chronological order.
 * Used to build the Gemini context window — we intentionally cap at 10 to:
 *   1. Stay within the prompt token budget
 *   2. Keep latency low (shorter prompts = faster responses)
 *   3. Avoid hitting the free-tier context limit
 *
 * The "desc + reverse" pattern is the idiomatic way to get the last N rows
 * in ascending order from Prisma (no negative take support).
 */
async function getLastMessages(sessionId, limit = 10) {
  const messages = await prisma.chatMessage.findMany({
    where:   { sessionId },
    orderBy: { createdAt: 'desc' },
    take:    limit,
  });
  return messages.reverse(); // Restore chronological order for Gemini
}

// ── getSessionMessages ─────────────────────────────────────────────────────

/**
 * Returns ALL messages for a session, guarded by ownership check.
 * Returns null if the session doesn't exist or isn't owned by this user.
 * Callers convert null → 404.
 */
async function getSessionMessages(sessionId, userId) {
  const session = await prisma.chatSession.findUnique({
    where: { id: sessionId },
  });

  if (!session || session.userId !== userId) return null;

  return prisma.chatMessage.findMany({
    where:   { sessionId },
    orderBy: { createdAt: 'asc' },
  });
}

// ── getUserSessions ────────────────────────────────────────────────────────

/**
 * Returns up to 50 sessions for a user, newest first.
 * Includes a message count (_count) so the UI can show "12 messages"
 * without a separate query per session.
 */
async function getUserSessions(userId) {
  return prisma.chatSession.findMany({
    where:   { userId },
    orderBy: { updatedAt: 'desc' },
    take:    50,
    include: {
      _count: { select: { messages: true } },
    },
  });
}

// ── verifySessionOwnership ─────────────────────────────────────────────────

/**
 * Fetches a session and verifies it belongs to the given user.
 * Returns the session object on success, null on not-found or wrong owner.
 * Used by the controller before reading/writing to an existing session.
 */
async function verifySessionOwnership(sessionId, userId) {
  const session = await prisma.chatSession.findUnique({
    where: { id: sessionId },
  });
  return session?.userId === userId ? session : null;
}

// ── deleteSession ──────────────────────────────────────────────────────────

/**
 * Hard-deletes a session (cascade removes all messages via the DB constraint).
 * Throws string error codes so the controller can map them to HTTP statuses.
 */
async function deleteSession(sessionId, userId) {
  const session = await prisma.chatSession.findUnique({
    where: { id: sessionId },
  });

  if (!session)                    throw new Error('SESSION_NOT_FOUND');
  if (session.userId !== userId)   throw new Error('SESSION_NOT_OWNED');

  await prisma.chatSession.delete({ where: { id: sessionId } });
}

module.exports = {
  createSession,
  addMessage,
  getLastMessages,
  getSessionMessages,
  getUserSessions,
  verifySessionOwnership,
  deleteSession,
};
