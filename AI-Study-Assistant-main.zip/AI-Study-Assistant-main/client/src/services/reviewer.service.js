import api from './api';

const reviewerService = {
  async generate(topic, subject, reviewerType, inputText = '') {
    const res = await api.post('/reviewers/generate', { topic, subject, reviewerType, inputText });
    return res.data; // { content, topic, subject, reviewerType }
  },

  async save(title, subject, content) {
    const res = await api.post('/reviewers/save', { title, subject, content });
    return res.data.reviewer;
  },

  async getAll() {
    const res = await api.get('/reviewers');
    return res.data.reviewers;
  },

  async getOne(reviewerId) {
    const res = await api.get(`/reviewers/${reviewerId}`);
    return res.data.reviewer;
  },

  async remove(reviewerId) {
    await api.delete(`/reviewers/${reviewerId}`);
  },

  async updateTitle(reviewerId, title) {
    const res = await api.patch(`/reviewers/${reviewerId}`, { title });
    return res.data.reviewer;
  },
};

export default reviewerService;
