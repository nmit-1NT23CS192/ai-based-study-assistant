import { useEffect, useState } from 'react';
import { Sparkles, BookOpen, Layers } from 'lucide-react';
import flashcardService from '../services/flashcard.service';
import FlashcardGenerator from '../components/flashcards/FlashcardGenerator';
import FlashcardSetCard   from '../components/flashcards/FlashcardSetCard';
import FlashcardStudyMode from '../components/flashcards/FlashcardStudyMode';
import LoadingSpinner     from '../components/LoadingSpinner';
import { cn } from '../utils/cn';

const TABS = [
  { id: 'generate', label: 'Generate',  icon: Sparkles  },
  { id: 'my-sets',  label: 'My Sets',   icon: BookOpen  },
];

export default function FlashcardsPage() {
  const [tab,        setTab]        = useState('generate');
  const [sets,       setSets]       = useState([]);
  const [loadingSets, setLoadingSets] = useState(false);
  const [studyingSet, setStudyingSet] = useState(null); // { id, title, flashcards[] }

  // ── Load sets when "My Sets" tab is opened ──────────────────────────────
  useEffect(() => {
    if (tab === 'my-sets') loadSets();
  }, [tab]);

  async function loadSets() {
    setLoadingSets(true);
    try {
      const data = await flashcardService.getSets();
      setSets(data);
    } catch {
      // Silently fail — user sees empty state
    } finally {
      setLoadingSets(false);
    }
  }

  // Called by FlashcardGenerator after a successful save
  function handleSaved(newSet) {
    setSets(prev => [newSet, ...prev]);
    setTab('my-sets');
  }

  // Called by FlashcardSetCard "Study" button
  async function handleStudy(setId) {
    try {
      const set = await flashcardService.getSet(setId);
      setStudyingSet(set);
    } catch {
      // Could show a toast here in a later iteration
    }
  }

  async function handleDeleteSet(setId) {
    await flashcardService.deleteSet(setId);
    setSets(prev => prev.filter(s => s.id !== setId));
    if (studyingSet?.id === setId) setStudyingSet(null);
  }

  return (
    // Full-height scrollable container — DashboardLayout's <main> is overflow-hidden
    <div className="h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">

        {/* ── Page header ──────────────────────────────────────────────── */}
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Layers size={22} className="text-violet-500" />
            Flashcards
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Generate AI-powered flashcards from any topic and study them with smart flip cards.
          </p>
        </div>

        {/* ── Tabs ─────────────────────────────────────────────────────── */}
        <div className="flex gap-1 p-1 bg-gray-100 dark:bg-gray-800/60 rounded-xl w-fit">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={cn(
                'flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all',
                tab === id
                  ? 'bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200',
              )}
            >
              <Icon size={15} />
              {label}
              {id === 'my-sets' && sets.length > 0 && (
                <span className="ml-0.5 text-xs bg-violet-100 dark:bg-violet-950 text-violet-600 dark:text-violet-400 px-1.5 py-0.5 rounded-full">
                  {sets.length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* ── Tab content ──────────────────────────────────────────────── */}
        {tab === 'generate' && (
          <FlashcardGenerator onSaved={handleSaved} />
        )}

        {tab === 'my-sets' && (
          loadingSets ? (
            <div className="flex items-center justify-center py-24">
              <LoadingSpinner size={28} />
            </div>
          ) : sets.length === 0 ? (
            <div className="text-center py-24">
              <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mx-auto mb-4">
                <Layers size={28} className="text-gray-400 dark:text-gray-500" />
              </div>
              <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-1">
                No flashcard sets yet
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Generate your first set using the Generator tab.
              </p>
              <button
                onClick={() => setTab('generate')}
                className="text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Go to Generator →
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {sets.map(set => (
                <FlashcardSetCard
                  key={set.id}
                  set={set}
                  onStudy={handleStudy}
                  onDelete={handleDeleteSet}
                />
              ))}
            </div>
          )
        )}
      </div>

      {/* ── Study mode overlay ─────────────────────────────────────────── */}
      {studyingSet && (
        <FlashcardStudyMode
          set={studyingSet}
          onClose={() => setStudyingSet(null)}
        />
      )}
    </div>
  );
}
