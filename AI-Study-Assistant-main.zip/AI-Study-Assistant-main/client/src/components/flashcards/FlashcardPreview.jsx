import { useState } from 'react';
import { Pencil, Trash2, Check, X } from 'lucide-react';
import { cn } from '../../utils/cn';

// ── EditableCard ───────────────────────────────────────────────────────────

function EditableCard({ card, index, onUpdate, onRemove }) {
  const [editing, setEditing]       = useState(false);
  const [question, setQuestion]     = useState(card.question);
  const [answer,   setAnswer]       = useState(card.answer);

  function handleSave() {
    if (!question.trim() || !answer.trim()) return;
    onUpdate(index, { question: question.trim(), answer: answer.trim() });
    setEditing(false);
  }

  function handleCancel() {
    setQuestion(card.question);
    setAnswer(card.answer);
    setEditing(false);
  }

  if (editing) {
    return (
      <div className="bg-white dark:bg-gray-900 border-2 border-indigo-400 dark:border-indigo-600 rounded-2xl p-4 flex flex-col gap-3">
        <div>
          <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1">
            Question
          </label>
          <textarea
            value={question}
            onChange={e => setQuestion(e.target.value)}
            rows={2}
            className="w-full text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1">
            Answer
          </label>
          <textarea
            value={answer}
            onChange={e => setAnswer(e.target.value)}
            rows={3}
            className="w-full text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
          />
        </div>
        <div className="flex gap-2 justify-end">
          <button
            onClick={handleCancel}
            className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
          >
            <X size={12} /> Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!question.trim() || !answer.trim()}
            className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white disabled:opacity-50 transition-colors"
          >
            <Check size={12} /> Save
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="group bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-4 flex flex-col gap-3 hover:border-gray-300 dark:hover:border-gray-700 transition-colors">
      {/* Card number + actions */}
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-gray-400 dark:text-gray-500">
          Card {index + 1}
        </span>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => setEditing(true)}
            className="p-1.5 rounded-lg text-gray-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition-colors"
            aria-label="Edit card"
          >
            <Pencil size={13} />
          </button>
          <button
            onClick={() => onRemove(index)}
            className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
            aria-label="Remove card"
          >
            <Trash2 size={13} />
          </button>
        </div>
      </div>

      {/* Q */}
      <div>
        <p className="text-xs font-semibold text-indigo-500 dark:text-indigo-400 uppercase tracking-wider mb-1">
          Q
        </p>
        <p className="text-sm text-gray-800 dark:text-gray-200 leading-relaxed">
          {card.question}
        </p>
      </div>

      {/* A */}
      <div className="pt-3 border-t border-gray-100 dark:border-gray-800">
        <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider mb-1">
          A
        </p>
        <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
          {card.answer}
        </p>
      </div>
    </div>
  );
}

// ── FlashcardPreview ───────────────────────────────────────────────────────

export default function FlashcardPreview({ cards, onUpdateCard, onRemoveCard }) {
  if (cards.length === 0) return null;

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300">
          Preview — {cards.length} {cards.length === 1 ? 'card' : 'cards'}
        </h3>
        <span className="text-xs text-gray-400 dark:text-gray-500">
          Hover to edit or remove
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {cards.map((card, i) => (
          <EditableCard
            key={i}
            card={card}
            index={i}
            onUpdate={onUpdateCard}
            onRemove={onRemoveCard}
          />
        ))}
      </div>
    </div>
  );
}
