const { GoogleGenerativeAI } = require('@google/generative-ai');
const logger = require('../utils/logger');

// ── Singleton ──────────────────────────────────────────────────────────────
// The GoogleGenerativeAI client is created once and reused for every request.
// Creating it is cheap (no network call), but we do it lazily so that missing
// GEMINI_API_KEY fails at request time with a clear error rather than at
// server startup.

let _genAI = null;

function getGenAI() {
  if (!_genAI) {
    if (!process.env.GEMINI_API_KEY) {
      throw new Error('GEMINI_API_KEY environment variable is not set.');
    }
    _genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  }
  return _genAI;
}

// ── Model factory ──────────────────────────────────────────────────────────
// getGenerativeModel() is a pure config call — no network I/O.
// We create a new model object per feature call so different features
// (chat, reviewer, flashcard generator) can pass different system prompts.

function buildModel(systemInstruction) {
  return getGenAI().getGenerativeModel({
    model: 'gemini-2.5-flash',
    systemInstruction,
    generationConfig: {
      temperature:     0.7,   // Balanced creativity vs determinism
      topP:            0.95,
      maxOutputTokens: 2048,  // Enough for detailed explanations + code
    },
  });
}

// ── sendChatMessage ────────────────────────────────────────────────────────
/**
 * Sends a full conversation history to Gemini and returns the model's reply.
 *
 * @param {Array<{role:'user'|'model', parts:[{text:string}]}>} messages
 *   The conversation to send. Must start with a 'user' turn and end with a
 *   'user' turn. The model automatically responds to the last user message.
 *
 * @param {string} systemPrompt
 *   Feature-specific instruction injected as the system role.
 *   Kept separate from the conversation so it doesn't consume the context
 *   window proportionally as conversation grows.
 *
 * @returns {{ text: string, tokensUsed: number }}
 */
async function sendChatMessage(messages, systemPrompt) {
  const model = buildModel(systemPrompt);

  try {
    const result = await model.generateContent({ contents: messages });
    const response = result.response;

    // ── Safety block detection ─────────────────────────────────────────────
    // Gemini may refuse to answer if the prompt or response triggers its
    // safety classifiers. finishReason 'SAFETY' means the response was blocked.
    const finishReason = response.candidates?.[0]?.finishReason;
    if (finishReason === 'SAFETY') {
      const blockReason = response.promptFeedback?.blockReason ?? 'SAFETY';
      const err = new Error(`Response blocked by safety filters: ${blockReason}`);
      err.code = 'SAFETY_BLOCK';
      throw err;
    }

    const text = response.text();
    const usage = response.usageMetadata ?? {};

    // Log token usage in development for cost/quota awareness.
    // tokensUsed includes system prompt tokens (API-counted); we cannot
    // easily separate them out, so we log the full total.
    logger.log(
      `[gemini] tokens — prompt: ${usage.promptTokenCount ?? '?'}, ` +
      `response: ${usage.candidatesTokenCount ?? '?'}, ` +
      `total: ${usage.totalTokenCount ?? '?'}`,
    );

    return {
      text,
      tokensUsed: usage.totalTokenCount ?? 0,
    };
  } catch (err) {
    // Already a domain error — re-throw
    if (err.code === 'SAFETY_BLOCK') throw err;

    // Gemini quota / rate limit (HTTP 429) or service unavailable (503)
    // Detected by status code since error class exports vary between versions.
    const httpStatus = err?.status ?? err?.response?.status;

    if (httpStatus === 429 || err.message?.toLowerCase().includes('quota')) {
      const quotaErr = new Error(
        'The AI service is temporarily rate-limited. Please wait a moment and try again.',
      );
      quotaErr.code = 'GEMINI_QUOTA';
      quotaErr.status = 429;
      throw quotaErr;
    }

    if (httpStatus === 503) {
      const svcErr = new Error('The AI service is temporarily unavailable. Please try again.');
      svcErr.code = 'GEMINI_UNAVAILABLE';
      svcErr.status = 503;
      throw svcErr;
    }

    console.error('[gemini] Unexpected API error:', err.message);
    throw new Error('Failed to get a response from the AI. Please try again.');
  }
}

// ── generateJSON ──────────────────────────────────────────────────────────
/**
 * Single-turn Gemini call that guarantees a JSON response.
 *
 * Uses responseMimeType: 'application/json' so the model is constrained to
 * emit only valid JSON — no markdown fences, no prose wrapping. This is
 * more reliable than prompt-only "return JSON" instructions, which LLMs
 * occasionally ignore.
 *
 * Temperature is lower (0.4) than chat because we need consistent structure,
 * not creative variation. maxOutputTokens is higher because structured arrays
 * of 20 items can be verbose.
 *
 * @param {string} prompt        - The user instruction (what to generate)
 * @param {string} systemPrompt  - Feature-specific persona / constraints
 * @returns {{ text: string, tokensUsed: number }}
 */
async function generateJSON(prompt, systemPrompt) {
  const model = getGenAI().getGenerativeModel({
    model: 'gemini-2.5-flash',
    systemInstruction: systemPrompt,
    generationConfig: {
      responseMimeType: 'application/json',
      temperature:      0.4,
      maxOutputTokens:  4096,
    },
  });

  try {
    const result   = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
    });
    const response = result.response;

    const finishReason = response.candidates?.[0]?.finishReason;
    if (finishReason === 'SAFETY') {
      const err  = new Error('Response blocked by safety filters');
      err.code   = 'SAFETY_BLOCK';
      throw err;
    }

    const text  = response.text();
    const usage = response.usageMetadata ?? {};

    console.log(
      `[gemini/json] tokens — prompt: ${usage.promptTokenCount ?? '?'}, ` +
      `response: ${usage.candidatesTokenCount ?? '?'}, total: ${usage.totalTokenCount ?? '?'}`,
    );

    return { text, tokensUsed: usage.totalTokenCount ?? 0 };
  } catch (err) {
    if (err.code === 'SAFETY_BLOCK') throw err;

    const httpStatus = err?.status ?? err?.response?.status;
    if (httpStatus === 429 || err.message?.toLowerCase().includes('quota')) {
      const e = new Error('AI service is temporarily rate-limited. Please try again later.');
      e.code = 'GEMINI_QUOTA'; e.status = 429;
      throw e;
    }
    if (httpStatus === 503) {
      const e = new Error('AI service is temporarily unavailable. Please try again.');
      e.code = 'GEMINI_UNAVAILABLE'; e.status = 503;
      throw e;
    }

    console.error('[gemini/json] error:', err.message);
    throw new Error('Failed to generate content. Please try again.');
  }
}

// ── generateText ──────────────────────────────────────────────────────────
/**
 * Single-turn Gemini call optimised for long-form Markdown output.
 *
 * Differences from generateJSON:
 *   - No responseMimeType constraint — plain text / Markdown output
 *   - maxOutputTokens: 8192 — reviewers can be 2 000–5 000 words
 *   - temperature: 0.65 — fluent prose without JSON rigidity
 *
 * @param {string} prompt       - The user instruction
 * @param {string} systemPrompt - Feature-specific persona / constraints
 * @returns {{ text: string, tokensUsed: number }}
 */
async function generateText(prompt, systemPrompt) {
  const model = getGenAI().getGenerativeModel({
    model: 'gemini-2.5-flash',
    systemInstruction: systemPrompt,
    generationConfig: {
      temperature:     0.65,
      topP:            0.95,
      maxOutputTokens: 8192,
    },
  });

  try {
    const result   = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
    });
    const response = result.response;

    const finishReason = response.candidates?.[0]?.finishReason;
    if (finishReason === 'SAFETY') {
      const err  = new Error('Response blocked by safety filters');
      err.code   = 'SAFETY_BLOCK';
      throw err;
    }

    const text  = response.text();
    const usage = response.usageMetadata ?? {};

    console.log(
      `[gemini/text] tokens — prompt: ${usage.promptTokenCount ?? '?'}, ` +
      `response: ${usage.candidatesTokenCount ?? '?'}, total: ${usage.totalTokenCount ?? '?'}`,
    );

    return { text, tokensUsed: usage.totalTokenCount ?? 0 };
  } catch (err) {
    if (err.code === 'SAFETY_BLOCK') throw err;

    const httpStatus = err?.status ?? err?.response?.status;
    if (httpStatus === 429 || err.message?.toLowerCase().includes('quota')) {
      const e = new Error('AI service is temporarily rate-limited. Please try again later.');
      e.code = 'GEMINI_QUOTA'; e.status = 429;
      throw e;
    }
    if (httpStatus === 503) {
      const e = new Error('AI service is temporarily unavailable. Please try again.');
      e.code = 'GEMINI_UNAVAILABLE'; e.status = 503;
      throw e;
    }

    console.error('[gemini/text] error:', err.message);
    throw new Error('Failed to generate content. Please try again.');
  }
}

module.exports = { sendChatMessage, generateJSON, generateText };
