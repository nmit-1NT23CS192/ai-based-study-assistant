import { cn } from '../../utils/cn';

const COLORS = {
  blue:   'bg-blue-100   text-blue-700   dark:bg-blue-950   dark:text-blue-300',
  green:  'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
  yellow: 'bg-amber-100  text-amber-700  dark:bg-amber-950  dark:text-amber-300',
  red:    'bg-red-100    text-red-700    dark:bg-red-950    dark:text-red-300',
  gray:   'bg-gray-100   text-gray-600   dark:bg-gray-800   dark:text-gray-400',
};

/**
 * Small pill-shaped label for categories, statuses, and tags.
 */
export default function Badge({ color = 'gray', className, children }) {
  return (
    <span
      className={cn(
        'inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium',
        COLORS[color],
        className,
      )}
    >
      {children}
    </span>
  );
}
