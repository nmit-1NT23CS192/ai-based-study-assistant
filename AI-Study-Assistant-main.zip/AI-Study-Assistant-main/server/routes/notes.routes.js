const { Router } = require('express');
const { createNote, getUserNotes, getNote, updateNote, deleteNote } =
  require('../controllers/notes.controller');
const { protect } = require('../middleware/auth.middleware');

const router = Router();
router.use(protect);

router.get('/',      getUserNotes);
router.post('/',     createNote);
router.get('/:id',   getNote);
router.patch('/:id', updateNote);
router.delete('/:id', deleteNote);

module.exports = router;
