import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bookmark, Layers, BookOpen, StickyNote, FileText,
  ExternalLink, Trash2, Calendar,
} from 'lucide-react';
import bookmarksService from '../services/bookmarks.service';
import LoadingSpinner   from '../components/LoadingSpinner';
import { timeAgo }      from '../utils/formatDate';
import { cn }           from '../utils/cn';

// ── Type configuration ─────────────────────────────────────────────────────

const TYPE_CONFIG = {
  flashcard_set: {
    label:  'Flashcard Sets',
    icon:   Layers,
    route:  '/flashcards',
    color:  'text-violet-500',
    bg:     'bg-violet-100 dark:bg-violet-950',
  },
  reviewer: {
    label:  'Reviewers',
    icon:   BookOpen,
    route:  '/reviewer',
    color:  'text-sky-500',
    bg:     'bg-sky-100 dark:bg-sky-950',
  },
  note: {
    label:  'Notes',
    icon:   StickyNote,
    route:  '/notes',
    color:  'text-amber-500',
    bg:     'bg-amber-100 dark:bg-amber-950',
  },
  material: {
    label:  'Study Materials',
    icon:   FileText,
    route:  '/summarizer',
    color:  'text-red-500',
    bg:     'bg-red-100 dark:bg-red-950',
  },
};

// ── BookmarkItem ───────────────────────────────────────────────────────────

function BookmarkItem({ bookmark, onRemove }) {
  const navigate   = useNavigate();
  const [removing, setRemoving] = useState(false);
  const cfg        = TYPE_CONFIG[bookmark.referenceType];
  const item       = bookmark.item;
  if (!cfg || !item) return null;

  const Icon = cfg.icon;

  // Derive a subtitle line from the item's fields
  const subtitle = item.subject
    ? item.subject
    : item.fileType
    ? item.fileType === 'application/pdf' ? 'PDF' : 'Image'
    : item._count?.flashcards != null
    ? `${item._count.flashcards} cards`
    : null;

  async function handleRemove(e) {
    e.stopPropagation();
    setRemoving(true);
    try { await onRemove(bookmark.id); }
    finally { setRemoving(false); }
  }

  return (
    <div
      onClick={() => navigate(cfg.route)}
      className="group flex items-center gap-3 p-3.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-sm transition-all cursor-pointer"
    >
      {/* Icon */}
      <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center shrink-0', cfg.bg)}>
        <Icon size={16} className={cfg.color} />
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
          {item.title || 'Untitled'}
        </p>
        <div className="flex items-center gap-2 mt-0.5 text-xs text-gray-400">
          {subtitle && <span>{subtitle}</span>}
          {subtitle && <span>·</span>}
          <span className="flex items-center gap-1">
            <Calendar size={10} />
            {timeAgo(bookmark.createdAt)}
          </span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1 shrink-0">
        <span className="opacity-0 group-hover:opacity-100 transition-opacity">
          <ExternalLink size={13} className="text-gray-400" />
        </span>
        <button
          onClick={handleRemove}
          disabled={removing}
          className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-all"
          aria-label="Remove bookmark"
        >
          <Trash2 size={13} />
        </button>
      </div>
    </div>
  );
}

// ── BookmarksPage ──────────────────────────────────────────────────────────

export default function BookmarksPage() {
  const [bookmarks, setBookmarks] = useState([]);
  const [loading,   setLoading]   = useState(true);

  useEffect(() => {
    bookmarksService.getAll()
      .then(setBookmarks)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  function handleRemove(bookmarkId) {
    setBookmarks(prev => prev.filter(b => b.id !== bookmarkId));
    return bookmarksService.remove(bookmarkId);
  }

  // Group by referenceType in the display order defined in TYPE_CONFIG
  const grouped = Object.entries(TYPE_CONFIG).map(([type, cfg]) => ({
    type,
    cfg,
    items: bookmarks.filter(b => b.referenceType === type),
  })).filter(g => g.items.length > 0);

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-8">

        {/* Header */}
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Bookmark size={22} className="text-indigo-500" />
            Bookmarks
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Your saved flashcard sets, reviewers, notes, and study materials.
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <LoadingSpinner size={28} />
          </div>
        ) : bookmarks.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mx-auto mb-4">
              <Bookmark size={28} className="text-gray-400 dark:text-gray-500" />
            </div>
            <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-1">
              No bookmarks yet
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Bookmark flashcard sets, reviewers, notes, and study materials to see them here.
            </p>
          </div>
        ) : (
          grouped.map(({ type, cfg, items }) => (
            <div key={type}>
              <h2 className="flex items-center gap-2 text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
                <cfg.icon size={14} className={cfg.color} />
                {cfg.label}
                <span className="ml-auto text-xs font-normal normal-case text-gray-400">
                  {items.length} {items.length === 1 ? 'item' : 'items'}
                </span>
              </h2>
              <div className="space-y-2">
                {items.map(bm => (
                  <BookmarkItem key={bm.id} bookmark={bm} onRemove={handleRemove} />
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
