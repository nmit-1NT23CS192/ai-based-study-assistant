import { cn } from '../../utils/cn';

const VARIANTS = {
  default:
    'bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800',
  bordered:
    'bg-transparent border-2 border-gray-200 dark:border-gray-700',
  elevated:
    'bg-white dark:bg-gray-900 shadow-lg shadow-gray-100/80 dark:shadow-none border border-gray-100 dark:border-gray-800',
};

/**
 * Content container with consistent rounding and surface styling.
 * All props beyond variant/className are forwarded to the <div>.
 */
export default function Card({ variant = 'default', className, children, ...props }) {
  return (
    <div
      className={cn('rounded-2xl', VARIANTS[variant], className)}
      {...props}
    >
      {children}
    </div>
  );
}
