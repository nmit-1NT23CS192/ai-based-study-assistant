const prisma      = require('../utils/prismaClient');
const gemini      = require('../services/gemini.service');
const chatService = require('../services/chat.service');

// ── System prompt ──────────────────────────────────────────────────────────
// Defined at module scope so it is constructed once, not on every request.
// The prompt is injected as Gemini's systemInstruction — it is not part of
// the user/model conversation turns and does not count against the 10-message
// context window we send as `contents`.

const SYSTEM_PROMPT = `
You are StudyBot, an AI-powered academic tutor built for BSIT (Bachelor of Science in Information Technology) and college students in the Philippines.

## Your Expertise
You are proficient in:
- **Programming languages**: Python, Java, C/C++, JavaScript, TypeScript, PHP, SQL, HTML/CSS
- **CS Fundamentals**: Data Structures & Algorithms, Computer Architecture, Operating Systems, Computer Networks, DBMS
- **Software Engineering**: OOP, Design Patterns, SDLC, Agile, Git, RESTful APIs, Microservices
- **Web Development**: React, Vue, Node.js, Express, Spring Boot, Laravel, MySQL, PostgreSQL, MongoDB
- **Mathematics**: Discrete Mathematics, Calculus, Linear Algebra, Statistics & Probability
- **General college subjects**: Physics, Technical Writing, Research Methods

## Teaching Philosophy
1. **Explain with examples** — use analogies, real-world scenarios, and ASCII diagrams when helpful
2. **Show working code** — include code blocks with the correct language tag and inline comments
3. **Debug systematically** — identify the root cause → explain WHY it's a bug → show the fix → explain the correction
4. **Guide, don't just answer** — for homework and exercises, ask Socratic questions to lead students to the answer. Do not complete assignments outright
5. **Build up from fundamentals** — introduce prerequisites before complex concepts
6. **Be encouraging** — learning is hard; acknowledge effort and progress

## Language
- Respond in the same language the student uses
- If the student writes in Filipino/Tagalog, respond in Filipino
- If the student writes in English, respond in English
- Code, error messages, and technical terms remain in English regardless
- Natural code-switching (Taglish) is fine if the student does it

## Response Format
- Use Markdown: **bold** for key terms, \`inline code\` for snippets, \`\`\`lang\`\`\` blocks for full code
- Number steps when explaining a process
- Keep responses focused and concise — no unnecessary filler or repetition
- End debugging explanations with "Does this make sense?" or a follow-up question to confirm understanding
`.trim();

// ── Rate limit constants ───────────────────────────────────────────────────
const CHAT_LIMIT   = 20;
const WINDOW_MS    = 60 * 60 * 1000; // 1 hour

// ── Helpers ────────────────────────────────────────────────────────────────

/**
 * Counts how many chat messages this user has sent in the last hour
 * using the ai_usage_logs table (DB-backed, survives restarts).
 */
async function getUsageCount(userId) {
  return prisma.aiUsageLog.count({
    where: {
      userId,
      feature:   'chat',
      createdAt: { gte: new Date(Date.now() - WINDOW_MS) },
    },
  });
}

/**
 * Maps database message rows to the format Gemini expects.
 * DB role → Gemini role:  USER → 'user',  ASSISTANT → 'model'
 *
 * Gemini requires:
 *   1. Conversation starts with a 'user' turn
 *   2. Roles alternate (user, model, user, model …)
 *   3. Last turn is always 'user' (the current message)
 *
 * We trim any leading 'model' turns that may appear if the context
 * window was sliced at an AI response.
 */
function toGeminiContents(messages) {
  const contents = messages.map((msg) => ({
    role:  msg.role === 'USER' ? 'user' : 'model',
    parts: [{ text: msg.content }],
  }));

  // Ensure first turn is 'user'
  while (contents.length > 0 && contents[0].role !== 'user') {
    contents.shift();
  }

  return contents;
}

// ── sendMessage ────────────────────────────────────────────────────────────

async function sendMessage(req, res) {
  const { message, sessionId } = req.body;
  const userId = req.user.userId;

  // ── 1. Input validation ────────────────────────────────────────────────
  const trimmedMessage = typeof message === 'string' ? message.trim() : '';
  if (!trimmedMessage) {
    return res.status(422).json({ error: 'Message is required.' });
  }
  if (trimmedMessage.length > 2000) {
    return res.status(422).json({ error: 'Message must be 2000 characters or fewer.' });
  }

  try {
    // ── 2. DB-backed rate limit check ──────────────────────────────────────
    // RateLimiterMemory in the middleware is the fast first pass (30/hr general).
    // This second check is precise, per-feature, and persists across restarts.
    const usageCount = await getUsageCount(userId);
    if (usageCount >= CHAT_LIMIT) {
      return res.status(429).json({
        error: `You have reached the ${CHAT_LIMIT} message/hour limit for AI Chat. Please try again later.`,
        feature: 'chat',
        limit: CHAT_LIMIT,
      });
    }

    // ── 3. Session: create new or verify existing ownership ────────────────
    let currentSessionId = sessionId ?? null;

    if (!currentSessionId) {
      const session = await chatService.createSession(userId, trimmedMessage);
      currentSessionId = session.id;
    } else {
      const session = await chatService.verifySessionOwnership(currentSessionId, userId);
      if (!session) {
        return res.status(404).json({ error: 'Chat session not found.' });
      }
    }

    // ── 4. Persist the user message BEFORE calling Gemini ─────────────────
    // Saving first ensures the message is stored even if the AI call fails.
    // This also means the context we fetch next will include this message,
    // so Gemini receives the full conversation up to and including the current turn.
    await chatService.addMessage(currentSessionId, 'USER', trimmedMessage);

    // ── 5. Build the context window ────────────────────────────────────────
    // We send only the last 10 messages to Gemini to:
    //   • Stay within token budget (free tier has limited TPM)
    //   • Keep response latency low
    //   • Avoid hitting the model's context length limit on long sessions
    const contextMessages = await chatService.getLastMessages(currentSessionId, 10);
    const geminiContents  = toGeminiContents(contextMessages);

    // ── 6. Call Gemini ─────────────────────────────────────────────────────
    const { text: aiText, tokensUsed } = await gemini.sendChatMessage(
      geminiContents,
      SYSTEM_PROMPT,
    );

    // ── 7. Persist the AI response ─────────────────────────────────────────
    const aiMessage = await chatService.addMessage(currentSessionId, 'ASSISTANT', aiText);

    // ── 8. Update session timestamp so it rises to the top of the sidebar ──
    await prisma.chatSession.update({
      where: { id: currentSessionId },
      data:  { updatedAt: new Date() },
    });

    // ── 9. Log token usage for analytics and future rate-limit queries ─────
    await prisma.aiUsageLog.create({
      data: { userId, feature: 'chat', tokensUsed },
    });

    return res.status(200).json({
      sessionId: currentSessionId,
      message: {
        id:        aiMessage.id,
        role:      'ASSISTANT',
        content:   aiText,
        createdAt: aiMessage.createdAt,
      },
    });

  } catch (err) {
    // ── Translate domain errors to HTTP responses ───────────────────────────
    if (err.code === 'SAFETY_BLOCK') {
      return res.status(400).json({
        error: 'Your message could not be processed due to content safety policies. Please rephrase and try again.',
      });
    }
    if (err.code === 'GEMINI_QUOTA' || err.status === 429) {
      return res.status(429).json({ error: err.message });
    }
    if (err.code === 'GEMINI_UNAVAILABLE' || err.status === 503) {
      return res.status(503).json({ error: err.message });
    }

    console.error('[chat.sendMessage]', err);
    return res.status(500).json({ error: 'Failed to send message. Please try again.' });
  }
}

// ── getSessions ────────────────────────────────────────────────────────────

async function getSessions(req, res) {
  try {
    const sessions = await chatService.getUserSessions(req.user.userId);
    return res.status(200).json({ sessions });
  } catch (err) {
    console.error('[chat.getSessions]', err);
    return res.status(500).json({ error: 'Failed to fetch chat sessions.' });
  }
}

// ── getSessionMessages ─────────────────────────────────────────────────────

async function getSessionMessages(req, res) {
  const { sessionId } = req.params;
  const userId = req.user.userId;

  try {
    const messages = await chatService.getSessionMessages(sessionId, userId);

    // getSessionMessages returns null for not-found OR wrong owner.
    // We return 404 for both — leaking "session exists but isn't yours"
    // would be an information disclosure vulnerability.
    if (messages === null) {
      return res.status(404).json({ error: 'Chat session not found.' });
    }

    return res.status(200).json({ messages });
  } catch (err) {
    console.error('[chat.getSessionMessages]', err);
    return res.status(500).json({ error: 'Failed to fetch messages.' });
  }
}

// ── deleteSession ──────────────────────────────────────────────────────────

async function deleteSession(req, res) {
  const { sessionId } = req.params;
  const userId = req.user.userId;

  try {
    await chatService.deleteSession(sessionId, userId);
    return res.status(200).json({ message: 'Session deleted successfully.' });
  } catch (err) {
    if (err.message === 'SESSION_NOT_FOUND') {
      return res.status(404).json({ error: 'Chat session not found.' });
    }
    // Return 404 for wrong owner too — same information disclosure reasoning
    if (err.message === 'SESSION_NOT_OWNED') {
      return res.status(404).json({ error: 'Chat session not found.' });
    }
    console.error('[chat.deleteSession]', err);
    return res.status(500).json({ error: 'Failed to delete session.' });
  }
}

module.exports = { sendMessage, getSessions, getSessionMessages, deleteSession };
