const prisma              = require('../utils/prismaClient');
const cloudinaryService   = require('./cloudinary.service');
const pdfService          = require('./pdf.service');

// ── uploadMaterial ─────────────────────────────────────────────────────────
/**
 * Full upload pipeline for a single file:
 *   1. Extract text (if PDF) — done first so we don't upload on parse error
 *   2. Upload buffer to Cloudinary
 *   3. Persist StudyMaterial record with all metadata
 *
 * Text extraction happens before the Cloudinary upload deliberately:
 *   - If pdf-parse throws on a corrupt/password-protected PDF, we fail
 *     fast and never waste a Cloudinary upload slot.
 *   - If Cloudinary fails, the text extraction effort was cheap.
 *
 * @param {string} userId
 * @param {object} file   - multer req.file object
 * @param {string} title  - user-supplied title (defaults to original filename)
 */
async function uploadMaterial(userId, file, title) {
  const { buffer, originalname, mimetype, size } = file;
  const isPDF = mimetype === 'application/pdf';

  // ── Step 1: Extract text ────────────────────────────────────────────────
  let extractedText = null;
  let pageCount     = null;

  if (isPDF) {
    try {
      const result  = await pdfService.extractTextFromPDF(buffer);
      extractedText = result.text;
      pageCount     = result.pageCount;
    } catch (err) {
      // Scanned / password-protected PDFs can't be parsed.
      // We still allow the upload — the user just won't be able to summarise it.
      console.warn(`[material] PDF text extraction failed for "${originalname}":`, err.message);
    }
  }

  // ── Step 2: Upload to Cloudinary ────────────────────────────────────────
  // PDFs must use resource_type:'raw' — Cloudinary rejects them as 'image'.
  // Images use the default resource_type:'image'.
  const resourceType = isPDF ? 'raw' : 'image';
  const safeFileName = originalname.replace(/[^a-zA-Z0-9._-]/g, '_');

  const { url, publicId } = await cloudinaryService.uploadBuffer(buffer, {
    resource_type: resourceType,
    folder:        `study-materials/${userId}`,
    public_id:     `${Date.now()}-${safeFileName}`,
  });

  // ── Step 3: Persist ─────────────────────────────────────────────────────
  return prisma.studyMaterial.create({
    data: {
      userId,
      title:              (title?.trim() || originalname).slice(0, 200),
      fileUrl:            url,
      fileType:           mimetype,
      cloudinaryPublicId: publicId,
      fileSize:           size,
      pageCount,
      extractedText,
    },
  });
}

// ── getUserMaterials ───────────────────────────────────────────────────────

async function getUserMaterials(userId) {
  return prisma.studyMaterial.findMany({
    where:   { userId },
    orderBy: { createdAt: 'desc' },
    select:  {
      id: true, userId: true, title: true, fileUrl: true,
      fileType: true, fileSize: true, pageCount: true,
      createdAt: true, updatedAt: true,
      // extractedText deliberately omitted — it can be large and
      // the list view never shows it. Fetched only for summarisation.
    },
  });
}

// ── getMaterial ────────────────────────────────────────────────────────────

async function getMaterial(materialId, userId) {
  const material = await prisma.studyMaterial.findUnique({
    where: { id: materialId },
  });
  if (!material || material.userId !== userId) return null;
  return material;
}

// ── deleteMaterial ─────────────────────────────────────────────────────────

async function deleteMaterial(materialId, userId) {
  const material = await prisma.studyMaterial.findUnique({ where: { id: materialId } });
  if (!material)               throw new Error('MATERIAL_NOT_FOUND');
  if (material.userId !== userId) throw new Error('MATERIAL_NOT_OWNED');

  // Delete from Cloudinary first so we don't leave orphaned files if DB fails
  if (material.cloudinaryPublicId) {
    const resourceType = material.fileType === 'application/pdf' ? 'raw' : 'image';
    try {
      await cloudinaryService.deleteFile(material.cloudinaryPublicId, resourceType);
    } catch (err) {
      // Cloudinary deletion failure is logged but doesn't block DB deletion.
      // The file may already be gone; the DB record should still be removed.
      console.warn('[material] Cloudinary delete failed:', err.message);
    }
  }

  await prisma.studyMaterial.delete({ where: { id: materialId } });
}

// ── summarizeMaterial ──────────────────────────────────────────────────────
/**
 * Fetches the stored extractedText and passes it to Gemini for summarisation.
 * Summaries are NOT persisted — they are returned to the client who can then
 * choose to "Save as Reviewer" (which calls the reviewer API separately).
 */
async function summarizeMaterial(materialId, userId, summaryType) {
  const material = await getMaterial(materialId, userId);
  if (!material) throw new Error('MATERIAL_NOT_FOUND');

  if (!material.extractedText) {
    throw new Error('NO_EXTRACTED_TEXT');
  }

  const truncated = pdfService.truncateTextForAI(material.extractedText, 8000);
  const { summary, tokensUsed } = await pdfService.generateSummaryWithAI(truncated, summaryType);

  return { summary, tokensUsed, materialTitle: material.title };
}

module.exports = {
  uploadMaterial,
  getUserMaterials,
  getMaterial,
  deleteMaterial,
  summarizeMaterial,
};
