import { Construction } from 'lucide-react';

/**
 * Temporary placeholder for sidebar routes not yet implemented.
 * Each future milestone replaces the relevant PlaceholderPage with a real page.
 */
export default function PlaceholderPage({ title }) {
  return (
    <div className="h-full overflow-y-auto flex flex-col items-center justify-center p-8 text-center">
      <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mb-5">
        <Construction size={28} className="text-gray-400 dark:text-gray-500" />
      </div>
      <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">{title}</h2>
      <p className="text-sm text-gray-500 dark:text-gray-400 max-w-xs">
        This feature is coming in a future milestone. Check back soon!
      </p>
    </div>
  );
}
