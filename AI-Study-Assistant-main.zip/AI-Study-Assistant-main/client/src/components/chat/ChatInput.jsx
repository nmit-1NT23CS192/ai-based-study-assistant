import { useRef, useState, useEffect } from 'react';
import { SendHorizontal } from 'lucide-react';
import { cn } from '../../utils/cn';

const MAX_CHARS    = 2000;
const MAX_HEIGHT   = 144; // 6 lines × 24px
const WARN_AT      = 200; // show counter below this

export default function ChatInput({ onSend, disabled }) {
  const [text, setText] = useState('');
  const textareaRef = useRef(null);

  // Auto-grow textarea up to MAX_HEIGHT
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, MAX_HEIGHT)}px`;
  }, [text]);

  // Focus on mount
  useEffect(() => {
    if (!disabled) textareaRef.current?.focus();
  }, [disabled]);

  function handleChange(e) {
    if (e.target.value.length <= MAX_CHARS) setText(e.target.value);
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey && !disabled) {
      e.preventDefault();
      handleSend();
    }
  }

  function handleSend() {
    if (!text.trim() || disabled) return;
    onSend(text);
    setText('');
    // Reset height after clearing
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
  }

  const charsLeft = MAX_CHARS - text.length;
  const canSend   = text.trim().length > 0 && !disabled;

  return (
    <div className="border border-gray-200 dark:border-gray-700 rounded-2xl bg-white dark:bg-gray-800 shadow-sm focus-within:ring-2 focus-within:ring-indigo-500 focus-within:border-transparent transition-shadow">
      <textarea
        ref={textareaRef}
        value={text}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        placeholder={disabled ? 'AI is responding…' : 'Ask anything about your studies…'}
        rows={1}
        className={cn(
          'w-full px-4 pt-3.5 pb-2 text-sm bg-transparent resize-none outline-none',
          'text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500',
          'disabled:opacity-60',
        )}
        style={{
          overflowY: text.length > 0 && textareaRef.current?.scrollHeight >= MAX_HEIGHT ? 'auto' : 'hidden',
        }}
        aria-label="Chat message input"
      />

      <div className="flex items-center justify-between px-3 pb-2.5 gap-2">
        {/* Keyboard hint */}
        <span className="text-xs text-gray-400 dark:text-gray-500 select-none hidden sm:block">
          ↵ send · ⇧↵ new line
        </span>

        <div className="flex items-center gap-3 ml-auto">
          {/* Character counter — only visible when approaching limit */}
          {charsLeft < WARN_AT && (
            <span className={cn(
              'text-xs tabular-nums',
              charsLeft < 50 ? 'text-red-500' : 'text-amber-500 dark:text-amber-400',
            )}>
              {charsLeft}
            </span>
          )}

          {/* Send button */}
          <button
            onClick={handleSend}
            disabled={!canSend}
            aria-label="Send message"
            className={cn(
              'flex items-center justify-center w-8 h-8 rounded-lg transition-colors',
              canSend
                ? 'bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white cursor-pointer'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-400 cursor-not-allowed',
            )}
          >
            <SendHorizontal size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
