/**
 * Dedicated admin-only middleware.
 *
 * Must be used AFTER the `protect` middleware so req.user is populated.
 * Returns 403 Forbidden if the authenticated user is not an ADMIN.
 *
 * Usage:
 *   router.get('/admin/users', protect, requireAdmin, handler);
 */
function requireAdmin(req, res, next) {
  if (req.user?.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
}

module.exports = { requireAdmin };
