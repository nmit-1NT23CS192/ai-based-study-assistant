const { Router } = require('express');
const { register, login, getMe }           = require('../controllers/auth.controller');
const { registerValidation, loginValidation } = require('../middleware/validate.middleware');
const { protect }                           = require('../middleware/auth.middleware');
const { authRateLimiter }                   = require('../middleware/rateLimiter.middleware');

const router = Router();

// POST /api/auth/register
// Rate limited → validated → create account
router.post('/register', authRateLimiter, registerValidation, register);

// POST /api/auth/login
// Rate limited → validated → authenticate
router.post('/login', authRateLimiter, loginValidation, login);

// GET /api/auth/me
// Token verified by protect middleware → return current user
router.get('/me', protect, getMe);

module.exports = router;
