import { useEffect, useState, useCallback } from 'react';
import { X, ChevronLeft, ChevronRight, RotateCcw, Brain } from 'lucide-react';
import { cn } from '../../utils/cn';

export default function FlashcardStudyMode({ set, onClose }) {
  const cards = set?.flashcards ?? [];

  const [index,   setIndex]   = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [done,    setDone]    = useState(false);

  const card = cards[index];
  const isFirst = index === 0;
  const isLast  = index === cards.length - 1;

  // ── Navigation helpers ─────────────────────────────────────────────────
  const goNext = useCallback(() => {
    if (isLast) { setDone(true); return; }
    setFlipped(false);
    // Small delay so the card finishes un-flipping before advancing
    setTimeout(() => setIndex(i => i + 1), flipped ? 300 : 0);
  }, [isLast, flipped]);

  const goPrev = useCallback(() => {
    if (isFirst) return;
    setFlipped(false);
    setTimeout(() => setIndex(i => i - 1), flipped ? 300 : 0);
  }, [isFirst, flipped]);

  function restart() {
    setIndex(0);
    setFlipped(false);
    setDone(false);
  }

  // ── Keyboard shortcuts ─────────────────────────────────────────────────
  useEffect(() => {
    function handleKey(e) {
      if (e.key === ' ')           { e.preventDefault(); setFlipped(f => !f); }
      if (e.key === 'ArrowRight')  { e.preventDefault(); goNext(); }
      if (e.key === 'ArrowLeft')   { e.preventDefault(); goPrev(); }
      if (e.key === 'Escape')      { onClose(); }
    }
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [goNext, goPrev, onClose]);

  // Reset flip when index changes (navigating reveals question-side first)
  useEffect(() => { setFlipped(false); }, [index]);

  const progress = ((index + (done ? 1 : 0)) / cards.length) * 100;

  return (
    // Full-screen overlay — sits above DashboardLayout
    <div className="fixed inset-0 z-50 bg-gray-950/95 backdrop-blur-sm flex flex-col">

      {/* ── Header ────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between px-6 py-4 shrink-0">
        <div className="flex items-center gap-2">
          <Brain size={18} className="text-indigo-400" />
          <span className="text-sm font-semibold text-white">{set.title}</span>
          <span className="text-xs text-gray-500 ml-1">{set.subject}</span>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
          aria-label="Exit study mode"
        >
          <X size={20} />
        </button>
      </div>

      {/* ── Progress bar ──────────────────────────────────────────────── */}
      <div className="px-6 pb-2 shrink-0">
        <div className="flex items-center justify-between text-xs text-gray-500 mb-1.5">
          <span>{done ? cards.length : index + 1} / {cards.length}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-indigo-500 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* ── Card area ─────────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-4">
        {done ? (
          /* ── Completion screen ───────────────────────────────────── */
          <div className="text-center">
            <div className="text-5xl mb-4">🎉</div>
            <h2 className="text-2xl font-bold text-white mb-2">Session complete!</h2>
            <p className="text-gray-400 mb-8">
              You reviewed all {cards.length} cards in <em>{set.title}</em>.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={restart}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-medium transition-colors"
              >
                <RotateCcw size={16} />
                Study again
              </button>
              <button
                onClick={onClose}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-700 text-gray-300 hover:bg-gray-800 transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* ── Flip card ───────────────────────────────────────────── */
          <div className="w-full max-w-2xl" style={{ height: '340px' }}>
            <div className="fc-scene">
              <div
                className={cn('fc-card', flipped && 'is-flipped')}
                onClick={() => setFlipped(f => !f)}
                role="button"
                aria-label={flipped ? 'Click to see question' : 'Click to reveal answer'}
                tabIndex={0}
                onKeyDown={e => e.key === 'Enter' && setFlipped(f => !f)}
              >
                {/* Front — Question */}
                <div className="fc-face bg-white dark:bg-gray-900 border-2 border-gray-200 dark:border-gray-700 select-none">
                  <div className="text-center max-w-lg">
                    <p className="text-xs font-semibold text-indigo-500 dark:text-indigo-400 uppercase tracking-widest mb-4">
                      Question
                    </p>
                    <p className="text-xl font-medium text-gray-900 dark:text-white leading-relaxed">
                      {card.question}
                    </p>
                    <p className="text-xs text-gray-400 dark:text-gray-600 mt-6">
                      Click or press Space to reveal
                    </p>
                  </div>
                </div>

                {/* Back — Answer */}
                <div className="fc-face fc-face-back bg-indigo-600 select-none">
                  <div className="text-center max-w-lg">
                    <p className="text-xs font-semibold text-indigo-200 uppercase tracking-widest mb-4">
                      Answer
                    </p>
                    <p className="text-xl font-medium text-white leading-relaxed">
                      {card.answer}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ── Navigation ────────────────────────────────────────────────── */}
      {!done && (
        <div className="flex items-center justify-center gap-4 pb-8 shrink-0">
          <button
            onClick={goPrev}
            disabled={isFirst}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-gray-700 text-gray-300 hover:bg-gray-800 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <ChevronLeft size={18} />
            <span className="text-sm">Prev</span>
          </button>

          <button
            onClick={() => setFlipped(f => !f)}
            className="px-6 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-white text-sm font-medium border border-gray-700 transition-colors"
          >
            {flipped ? 'Hide answer' : 'Reveal answer'}
          </button>

          <button
            onClick={goNext}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white disabled:opacity-30 transition-all"
          >
            <span className="text-sm">{isLast ? 'Finish' : 'Next'}</span>
            <ChevronRight size={18} />
          </button>
        </div>
      )}

      {/* ── Keyboard hint ─────────────────────────────────────────────── */}
      {!done && (
        <p className="text-center text-xs text-gray-600 pb-4 shrink-0">
          Space = flip · ← → = navigate · Esc = exit
        </p>
      )}
    </div>
  );
}
