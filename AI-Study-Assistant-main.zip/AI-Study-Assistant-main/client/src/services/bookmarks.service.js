import api from './api';

const bookmarksService = {
  async getAll() {
    const res = await api.get('/bookmarks');
    return res.data.bookmarks; // [{ id, referenceType, referenceId, item, createdAt }]
  },

  async add(referenceType, referenceId) {
    const res = await api.post('/bookmarks', { referenceType, referenceId });
    return res.data.bookmark;
  },

  async remove(bookmarkId) {
    await api.delete(`/bookmarks/${bookmarkId}`);
  },
};

export default bookmarksService;
