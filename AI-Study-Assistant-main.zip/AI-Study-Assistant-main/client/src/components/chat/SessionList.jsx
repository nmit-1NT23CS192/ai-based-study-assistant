import { useState } from 'react';
import { Plus, Trash2, MessageSquare, AlertTriangle } from 'lucide-react';
import { timeAgo } from '../../utils/formatDate';
import { cn } from '../../utils/cn';

// ── DeleteConfirm ──────────────────────────────────────────────────────────
// Inline micro-confirmation — avoids a modal for a low-stakes action.

function DeleteConfirm({ onConfirm, onCancel }) {
  return (
    <div className="flex items-center gap-1 ml-auto">
      <span className="text-xs text-gray-500 dark:text-gray-400 mr-1">Delete?</span>
      <button
        onClick={(e) => { e.stopPropagation(); onConfirm(); }}
        className="p-1 rounded text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
        aria-label="Confirm delete"
      >
        <AlertTriangle size={13} />
      </button>
      <button
        onClick={(e) => { e.stopPropagation(); onCancel(); }}
        className="text-xs px-1.5 py-0.5 rounded text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
        aria-label="Cancel delete"
      >
        ✕
      </button>
    </div>
  );
}

// ── SessionItem ────────────────────────────────────────────────────────────

function SessionItem({ session, isActive, onSelect, onDelete }) {
  const [confirming, setConfirming] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const title = session.title?.length > 30
    ? session.title.slice(0, 28) + '…'
    : session.title;

  async function handleDelete() {
    setDeleting(true);
    try {
      await onDelete(session.id);
    } finally {
      setDeleting(false);
      setConfirming(false);
    }
  }

  return (
    <li>
      <button
        onClick={() => onSelect(session.id)}
        className={cn(
          'w-full text-left px-3 py-2.5 rounded-lg group flex items-start gap-2.5 transition-colors',
          isActive
            ? 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300'
            : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800',
        )}
      >
        <MessageSquare
          size={15}
          className={cn(
            'mt-0.5 shrink-0',
            isActive ? 'text-indigo-500' : 'text-gray-400',
          )}
        />

        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate leading-tight">{title}</p>
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
            {timeAgo(session.updatedAt)}
          </p>
        </div>

        {/* Show delete button on hover / while confirming */}
        {confirming ? (
          <DeleteConfirm
            onConfirm={handleDelete}
            onCancel={() => setConfirming(false)}
          />
        ) : (
          <button
            onClick={(e) => { e.stopPropagation(); setConfirming(true); }}
            disabled={deleting}
            className="opacity-0 group-hover:opacity-100 focus:opacity-100 ml-auto p-1 rounded text-gray-400 hover:text-red-500 dark:hover:text-red-400 transition-all"
            aria-label="Delete session"
          >
            <Trash2 size={13} />
          </button>
        )}
      </button>
    </li>
  );
}

// ── SessionList ────────────────────────────────────────────────────────────

export default function SessionList({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
}) {
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-3 border-b border-gray-200 dark:border-gray-800 shrink-0">
        <button
          onClick={onNewChat}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-medium transition-colors"
        >
          <Plus size={16} />
          New Chat
        </button>
      </div>

      {/* Session list */}
      <div className="flex-1 overflow-y-auto p-2">
        {sessions.length === 0 ? (
          <div className="text-center py-10 px-4">
            <MessageSquare size={28} className="mx-auto text-gray-300 dark:text-gray-600 mb-2" />
            <p className="text-xs text-gray-400 dark:text-gray-500">
              No conversations yet.
              <br />Start a new chat above.
            </p>
          </div>
        ) : (
          <ul className="space-y-0.5">
            {sessions.map(session => (
              <SessionItem
                key={session.id}
                session={session}
                isActive={session.id === activeSessionId}
                onSelect={onSelectSession}
                onDelete={onDeleteSession}
              />
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
