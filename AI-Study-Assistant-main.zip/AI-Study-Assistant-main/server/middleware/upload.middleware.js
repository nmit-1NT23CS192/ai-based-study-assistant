const multer = require('multer');

// ── Allowed MIME types ─────────────────────────────────────────────────────
// PDFs for text extraction; images for future OCR / study material scanning.
const ALLOWED_TYPES = new Set([
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/webp',
]);

// ── File filter ────────────────────────────────────────────────────────────
function fileFilter(req, file, cb) {
  if (ALLOWED_TYPES.has(file.mimetype)) {
    cb(null, true);
  } else {
    // Passing an Error to cb rejects the upload and triggers the MulterError
    // handler in the route without reaching the controller.
    cb(new Error(`File type "${file.mimetype}" is not allowed. Upload a PDF or image.`), false);
  }
}

// ── Multer instance ────────────────────────────────────────────────────────
// memoryStorage keeps the file as a Buffer in req.file.buffer.
// No disk writes → no temp-file cleanup needed → safer on serverless.
const upload = multer({
  storage: multer.memoryStorage(),
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10 MB
    files:    1,
  },
});

// Export a single-file middleware bound to the field name 'file'.
// Routes wrap it in a custom callback to translate MulterError → HTTP response.
module.exports = {
  uploadSingle: upload.single('file'),
  ALLOWED_TYPES,
};
