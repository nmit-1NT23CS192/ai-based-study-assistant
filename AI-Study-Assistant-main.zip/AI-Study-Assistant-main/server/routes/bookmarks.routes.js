const { Router } = require('express');
const { addBookmark, getUserBookmarks, removeBookmark } =
  require('../controllers/bookmarks.controller');
const { protect } = require('../middleware/auth.middleware');

const router = Router();
router.use(protect);

router.post('/',    addBookmark);
router.get('/',     getUserBookmarks);
router.delete('/:id', removeBookmark);

module.exports = router;
