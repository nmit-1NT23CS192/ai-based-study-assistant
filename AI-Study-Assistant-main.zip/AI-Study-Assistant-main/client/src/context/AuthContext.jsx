import { createContext, useContext, useState, useEffect } from 'react';
import authService from '../services/auth.service';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]   = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);

  // On mount: if a token exists, validate it against the server.
  // This catches expired tokens immediately instead of trusting stale
  // localStorage data — a user whose token expired while the tab was closed
  // gets redirected to /login on next visit, not shown stale dashboard data.
  useEffect(() => {
    const stored = localStorage.getItem('token');

    if (!stored) {
      setLoading(false);
      return;
    }

    authService.getMe()
      .then(({ user: me }) => setUser(me))
      .catch(() => {
        // Invalid / expired token — clean up silently
        localStorage.removeItem('token');
        setToken(null);
      })
      .finally(() => setLoading(false));
  }, []); // runs once on mount

  // Listen for 401s from the Axios interceptor.
  // When a mid-session API call returns 401, the interceptor dispatches
  // 'auth:unauthorized'. We clear React state here so ProtectedRoute
  // automatically redirects — no window.location.href, no page reload.
  useEffect(() => {
    function handleUnauthorized() {
      setUser(null);
      setToken(null);
    }
    window.addEventListener('auth:unauthorized', handleUnauthorized);
    return () => window.removeEventListener('auth:unauthorized', handleUnauthorized);
  }, []); // setUser / setToken are stable references from useState

  async function login(email, password) {
    const data = await authService.login(email, password);
    localStorage.setItem('token', data.token);
    setToken(data.token);
    setUser(data.user);
    return data;
  }

  async function register(name, email, password) {
    const data = await authService.register(name, email, password);
    localStorage.setItem('token', data.token);
    setToken(data.token);
    setUser(data.user);
    return data;
  }

  function logout() {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
