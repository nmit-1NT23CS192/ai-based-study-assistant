import api from './api';

const flashcardService = {
  async generate(topic, subject, count) {
    const res = await api.post('/flashcards/generate', { topic, subject, count });
    return res.data; // { cards: [{question, answer}], topic, subject }
  },

  async save(title, subject, flashcards) {
    const res = await api.post('/flashcards/save', { title, subject, flashcards });
    return res.data.set; // full FlashcardSet with flashcards[]
  },

  async getSets() {
    const res = await api.get('/flashcards');
    return res.data.sets;
  },

  async getSet(setId) {
    const res = await api.get(`/flashcards/${setId}`);
    return res.data.set;
  },

  async deleteSet(setId) {
    await api.delete(`/flashcards/${setId}`);
  },
};

export default flashcardService;
