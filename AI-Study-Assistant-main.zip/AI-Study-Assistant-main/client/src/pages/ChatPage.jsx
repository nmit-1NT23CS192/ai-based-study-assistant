import { useState } from 'react';
import useChat from '../hooks/useChat';
import SessionList from '../components/chat/SessionList';
import ChatWindow from '../components/chat/ChatWindow';
import { cn } from '../utils/cn';

export default function ChatPage() {
  const chat = useChat();

  // Controls the session list panel on mobile.
  // On desktop (md+) the panel is always visible in the layout.
  const [showSessions, setShowSessions] = useState(false);

  function handleSelectSession(id) {
    chat.openSession(id);
    setShowSessions(false); // auto-close panel on mobile after selection
  }

  function handleNewChat() {
    chat.startNewChat();
    setShowSessions(false);
  }

  return (
    // h-full fills the DashboardLayout's <main> (which is overflow-hidden)
    <div className="flex h-full overflow-hidden relative">

      {/* ── Mobile overlay backdrop ─────────────────────────────────────── */}
      {showSessions && (
        <div
          className="fixed inset-0 z-20 bg-black/40 md:hidden"
          onClick={() => setShowSessions(false)}
          aria-hidden="true"
        />
      )}

      {/* ── Session list panel ──────────────────────────────────────────── */}
      {/*
        Desktop: always visible, 272px wide, in document flow.
        Mobile:  fixed overlay, slides in from left via transform.
      */}
      <aside
        className={cn(
          'flex-none w-68 border-r border-gray-200 dark:border-gray-800',
          'bg-white dark:bg-gray-900',
          // Mobile: overlay
          'fixed inset-y-0 left-0 z-30',
          'transition-transform duration-300 ease-in-out',
          showSessions ? 'translate-x-0' : '-translate-x-full',
          // Desktop: in-flow, always visible
          'md:relative md:translate-x-0 md:z-auto',
        )}
        style={{ width: '272px' }}
        aria-label="Chat sessions"
      >
        <SessionList
          sessions={chat.sessions}
          activeSessionId={chat.activeSessionId}
          onSelectSession={handleSelectSession}
          onNewChat={handleNewChat}
          onDeleteSession={chat.deleteSession}
        />
      </aside>

      {/* ── Chat area ───────────────────────────────────────────────────── */}
      <div className="flex-1 min-w-0 relative">
        <ChatWindow
          messages={chat.messages}
          loadingMessages={chat.loadingMessages}
          sending={chat.sending}
          error={chat.error}
          activeSessionId={chat.activeSessionId}
          onSendMessage={chat.sendMessage}
          onToggleSidebar={() => setShowSessions(v => !v)}
          onClearError={() => chat.setError(null)}
        />
      </div>
    </div>
  );
}
