import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, MessageSquare, Layers, BookOpen,
  FileText, Terminal, PenLine, Bookmark, TrendingUp,
  Settings, LogOut, Brain, PanelLeftClose, PanelLeftOpen, X, ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import Avatar from '../ui/Avatar';
import { cn } from '../../utils/cn';

// ── Navigation definition ──────────────────────────────────────────────────
// Centralised here so adding a new route = one line.

const NAV_ITEMS = [
  { to: '/dashboard',  label: 'Dashboard',      icon: LayoutDashboard },
  { to: '/chat',       label: 'AI Chat',         icon: MessageSquare   },
  { to: '/flashcards', label: 'Flashcards',      icon: Layers          },
  { to: '/reviewer',   label: 'Reviewer',        icon: BookOpen        },
  { to: '/summarizer', label: 'PDF Summarizer',  icon: FileText        },
  { to: '/debugger',   label: 'Code Debugger',   icon: Terminal        },
  { to: '/notes',      label: 'Notes',           icon: PenLine         },
  { to: '/bookmarks',  label: 'Bookmarks',       icon: Bookmark        },
  { to: '/analytics', label: 'Analytics',       icon: TrendingUp      },
];

const BOTTOM_NAV = [
  { to: '/settings', label: 'Settings', icon: Settings },
];

// ── NavItem ────────────────────────────────────────────────────────────────

function NavItem({ to, label, icon: Icon, isCollapsed }) {
  return (
    // title provides a native browser tooltip when collapsed.
    // A tooltip library would be the production upgrade path.
    <li title={isCollapsed ? label : undefined}>
      <NavLink
        to={to}
        className={({ isActive }) =>
          cn(
            'flex items-center gap-3 rounded-lg text-sm font-medium transition-colors',
            isCollapsed ? 'justify-center px-0 py-2.5 mx-auto w-10' : 'px-3 py-2',
            isActive
              ? 'bg-indigo-600 text-white'
              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white',
          )
        }
      >
        <Icon size={20} className="shrink-0" />
        {!isCollapsed && <span className="truncate">{label}</span>}
      </NavLink>
    </li>
  );
}

// ── Sidebar ────────────────────────────────────────────────────────────────

export default function Sidebar({ isMobileOpen, isCollapsed, onClose, onToggleCollapse }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate('/login');
  }

  return (
    <>
      {/* ── Mobile backdrop overlay ─────────────────────────────────────── */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/50 md:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* ── Sidebar panel ──────────────────────────────────────────────── */}
      <aside
        className={cn(
          // Positioning: fixed for mobile overlay, relative for desktop layout
          'fixed inset-y-0 left-0 z-40 flex flex-col',
          'md:relative md:translate-x-0 md:z-auto',
          // Surface
          'bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800',
          // Smooth transition covers both the mobile slide-in and desktop width collapse
          'transition-all duration-300 ease-in-out',
          // Mobile: always full width, visibility via transform
          'w-64',
          isMobileOpen ? 'translate-x-0' : '-translate-x-full',
          // Desktop: override width based on collapse state
          isCollapsed ? 'md:w-16' : 'md:w-60',
        )}
      >
        {/* ── Header ─────────────────────────────────────────────────── */}
        <div className={cn(
          'flex items-center border-b border-gray-200 dark:border-gray-800 h-16 shrink-0',
          isCollapsed ? 'justify-center px-3' : 'justify-between px-4',
        )}>
          {/* Logo — hidden in collapsed desktop, always visible on mobile */}
          {!isCollapsed && (
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shrink-0">
                <Brain size={18} className="text-white" />
              </div>
              <span className="font-semibold text-sm text-gray-900 dark:text-white truncate">
                AI Study Assistant
              </span>
            </div>
          )}

          {isCollapsed && (
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <Brain size={18} className="text-white" />
            </div>
          )}

          {/* Close button — mobile only */}
          <button
            onClick={onClose}
            className="md:hidden p-1 rounded-md text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
            aria-label="Close sidebar"
          >
            <X size={18} />
          </button>
        </div>

        {/* ── Collapse toggle — desktop only ──────────────────────────── */}
        <button
          onClick={onToggleCollapse}
          title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className={cn(
            'hidden md:flex items-center gap-2 text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors py-2 border-b border-gray-200 dark:border-gray-800',
            isCollapsed ? 'justify-center px-3' : 'px-4',
          )}
        >
          {isCollapsed
            ? <PanelLeftOpen size={16} />
            : <><PanelLeftClose size={16} /><span>Collapse</span></>
          }
        </button>

        {/* ── Main navigation ─────────────────────────────────────────── */}
        <nav className="flex-1 p-3 overflow-y-auto">
          <ul className="space-y-0.5">
            {NAV_ITEMS.map((item) => (
              <NavItem key={item.to} {...item} isCollapsed={isCollapsed} />
            ))}
          </ul>
        </nav>

        {/* ── Bottom section ──────────────────────────────────────────── */}
        <div className="p-3 border-t border-gray-200 dark:border-gray-800 space-y-0.5">
          {BOTTOM_NAV.map((item) => (
            <NavItem key={item.to} {...item} isCollapsed={isCollapsed} />
          ))}
          {/* Admin link — only visible to ADMIN role users */}
          {user?.role === 'ADMIN' && (
            <NavItem
              to="/admin"
              label="Admin Panel"
              icon={ShieldAlert}
              isCollapsed={isCollapsed}
            />
          )}
        </div>

        {/* ── User footer ─────────────────────────────────────────────── */}
        <div className={cn(
          'p-3 border-t border-gray-200 dark:border-gray-800 flex items-center gap-3',
          isCollapsed && 'flex-col gap-2',
        )}>
          <Avatar user={user} size="sm" className="shrink-0" />

          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-gray-900 dark:text-white truncate">
                {user?.name}
              </p>
              <p className="text-xs text-gray-400 truncate">{user?.email}</p>
            </div>
          )}

          <button
            onClick={handleLogout}
            title="Sign out"
            className="p-1.5 rounded-md text-gray-400 hover:text-red-500 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
            aria-label="Sign out"
          >
            <LogOut size={15} />
          </button>
        </div>
      </aside>
    </>
  );
}
