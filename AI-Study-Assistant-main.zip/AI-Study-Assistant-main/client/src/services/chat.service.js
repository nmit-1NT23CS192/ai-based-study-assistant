import api from './api';

/**
 * Raw API calls for chat endpoints.
 * Returns unwrapped data so callers work with plain objects/arrays.
 */
const chatService = {
  async sendMessage(message, sessionId = null) {
    const res = await api.post('/chat/send', { message, sessionId });
    return res.data; // { sessionId, message: { id, role, content, createdAt } }
  },

  async getSessions() {
    const res = await api.get('/chat/sessions');
    return res.data.sessions; // [{ id, title, updatedAt, _count }]
  },

  async getSessionMessages(sessionId) {
    const res = await api.get(`/chat/sessions/${sessionId}/messages`);
    return res.data.messages; // [{ id, role, content, createdAt }]
  },

  async deleteSession(sessionId) {
    const res = await api.delete(`/chat/sessions/${sessionId}`);
    return res.data;
  },
};

export default chatService;
