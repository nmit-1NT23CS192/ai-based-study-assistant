const { verifyToken } = require('../utils/jwt.utils');

/**
 * Verifies the Bearer JWT and attaches the decoded payload to req.user.
 * req.user shape: { userId, role, iat, exp }
 *
 * TokenExpiredError and JsonWebTokenError are separated so the frontend
 * can show "session expired, please log in" vs a generic auth error.
 */
function protect(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.split(' ')[1];

  try {
    req.user = verifyToken(token);
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
}

/**
 * Gate for admin-only routes. Must be used after `protect`.
 * Usage: router.delete('/users/:id', protect, requireAdmin, handler)
 */
function requireAdmin(req, res, next) {
  if (req.user?.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

module.exports = { protect, requireAdmin };
