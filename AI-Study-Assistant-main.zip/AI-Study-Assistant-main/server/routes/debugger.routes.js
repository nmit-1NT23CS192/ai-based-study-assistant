const { Router } = require('express');
const { debugCode, explainCode } = require('../controllers/debugger.controller');
const { protect }       = require('../middleware/auth.middleware');
const { aiRateLimiter } = require('../middleware/rateLimiter.middleware');

const router = Router();
router.use(protect);

router.post('/debug',   aiRateLimiter, debugCode);
router.post('/explain', aiRateLimiter, explainCode);

module.exports = router;
