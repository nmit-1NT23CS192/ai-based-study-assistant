import api from './api';

/**
 * Raw API calls for auth endpoints.
 * These functions know nothing about React state — they just talk to the server.
 * AuthContext calls these and is responsible for updating React state afterward.
 */
const authService = {
  async login(email, password) {
    const res = await api.post('/auth/login', { email, password });
    return res.data; // { message, token, user }
  },

  async register(name, email, password) {
    const res = await api.post('/auth/register', { name, email, password });
    return res.data; // { message, token, user }
  },

  async getMe() {
    const res = await api.get('/auth/me');
    return res.data; // { user }
  },
};

export default authService;
