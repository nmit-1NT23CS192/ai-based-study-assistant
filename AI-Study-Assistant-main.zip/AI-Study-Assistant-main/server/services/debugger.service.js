const { generateJSON, generateText } = require('./gemini.service');

// ── System prompts ─────────────────────────────────────────────────────────

const DEBUG_SYSTEM_PROMPT = `
You are an expert programming tutor helping college students debug their code.
Always be encouraging and educational. Explain mistakes as learning opportunities.
Return ONLY a JSON object with exactly three keys:
  "explanation" — string, what is wrong and why (in plain student-friendly language)
  "fixedCode"   — string, the corrected code with NO surrounding markdown backticks
  "keyChanges"  — array of strings, each describing one specific change made and why
`.trim();

const EXPLAIN_SYSTEM_PROMPT = `
You are an expert programming tutor explaining code to college students.
Use clear, simple language. Be thorough but accessible.
Format your response in Markdown with clear headers and bullet points.
`.trim();

// ── Prompt builders ────────────────────────────────────────────────────────

function buildDebugPrompt(code, language, errorMessage, userDescription) {
  const errorLine   = errorMessage?.trim()
    ? `Error message: ${errorMessage.trim()}`
    : 'Error message: (none provided)';
  const descLine    = userDescription?.trim()
    ? `Student's description: ${userDescription.trim()}`
    : "Student's description: (none provided)";

  return `You are an expert programming tutor helping a student debug their code.

Language: ${language}
${errorLine}
${descLine}

Code:
\`\`\`${language}
${code}
\`\`\`

Please provide:
1. "explanation": What is wrong and why (explain simply for a student)
2. "fixedCode": The corrected code — plain string, NO backtick fences, NO markdown
3. "keyChanges": A list of strings, each describing exactly what was changed and why

Be encouraging and educational. Explain like you're teaching, not just fixing.`;
}

function buildExplainPrompt(code, language) {
  return `Explain the following ${language} code to a college student.

Cover:
- **Overview**: What the code does in 1–2 sentences
- **Breakdown**: Walk through each significant block or function
- **Key Concepts**: Programming concepts demonstrated (e.g. recursion, loops, OOP)
- **Potential Issues**: Any bugs, edge cases, or improvements worth noting

Code:
\`\`\`${language}
${code}
\`\`\``;
}

// ── Response parser ────────────────────────────────────────────────────────
// Defensive parsing: handles key-name variations the model might produce.

function parseDebugResponse(jsonText) {
  const raw = JSON.parse(jsonText);

  const explanation = String(raw.explanation ?? raw.bugExplanation ?? '').trim();
  const fixedCode   = String(raw.fixedCode ?? raw.fixed_code ?? raw.correctedCode ?? '').trim();
  const keyChanges  = Array.isArray(raw.keyChanges ?? raw.key_changes ?? raw.changes)
    ? (raw.keyChanges ?? raw.key_changes ?? raw.changes).map(s => String(s).trim())
    : [];

  if (!explanation && !fixedCode) {
    throw new Error('AI returned an unrecognised response structure. Please try again.');
  }

  return { explanation, fixedCode, keyChanges };
}

// ── debugCodeWithAI ────────────────────────────────────────────────────────
/**
 * Identifies the bug in the student's code and returns a structured fix.
 *
 * Uses generateJSON (responseMimeType:'application/json') for reliable
 * structure — the three-field contract (explanation / fixedCode / keyChanges)
 * needs to be machine-readable so the frontend can render each part distinctly.
 *
 * Temperature 0.35: lower than chat — code fixes must be precise, not creative.
 */
async function debugCodeWithAI(code, language, errorMessage, userDescription) {
  const prompt = buildDebugPrompt(code, language, errorMessage, userDescription);
  const { text, tokensUsed } = await generateJSON(prompt, DEBUG_SYSTEM_PROMPT);

  const result = parseDebugResponse(text);
  return { ...result, tokensUsed };
}

// ── explainCodeWithAI ──────────────────────────────────────────────────────
/**
 * Returns a markdown explanation of what the code does.
 *
 * Uses generateText (not JSON) because an explanation is free-form prose
 * with headers, bullets, and code references — better as rich markdown.
 */
async function explainCodeWithAI(code, language) {
  const prompt = buildExplainPrompt(code, language);
  const { text, tokensUsed } = await generateText(prompt, EXPLAIN_SYSTEM_PROMPT);

  if (!text?.trim()) throw new Error('AI returned an empty explanation. Please try again.');
  return { explanation: text, tokensUsed };
}

module.exports = { debugCodeWithAI, explainCodeWithAI };
