import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { useTheme } from '../../context/ThemeContext';

/**
 * Full-page markdown renderer for reviewer content.
 *
 * Deliberately more spacious than the chat bubble MarkdownContent:
 *  - Reviewers are long-form documents, not conversational snippets
 *  - Larger heading hierarchy (h2 = section, h3 = sub-section)
 *  - More vertical rhythm for readability
 *  - Print-safe styling (the .reviewer-print-area parent handles @media print)
 *
 * All component overrides are defined inline so the rendered HTML is
 * self-contained when printed (no Tailwind class purging surprises).
 */
export default function ReviewerContent({ content }) {
  const { theme } = useTheme();
  const codeStyle = theme === 'dark' ? oneDark : oneLight;

  return (
    <div className="reviewer-print-area text-gray-800 dark:text-gray-100 text-sm leading-relaxed">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          // ── Headings ─────────────────────────────────────────────────────
          h1: ({ children }) => (
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mt-8 mb-4 first:mt-0 pb-2 border-b border-gray-200 dark:border-gray-700">
              {children}
            </h1>
          ),
          h2: ({ children }) => (
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mt-7 mb-3 first:mt-0">
              {children}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 className="text-base font-semibold text-gray-900 dark:text-white mt-5 mb-2 first:mt-0">
              {children}
            </h3>
          ),
          h4: ({ children }) => (
            <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mt-4 mb-1.5">
              {children}
            </h4>
          ),

          // ── Body text ─────────────────────────────────────────────────────
          p: ({ children }) => (
            <p className="mb-4 last:mb-0 leading-7">{children}</p>
          ),

          // ── Lists ─────────────────────────────────────────────────────────
          ul: ({ children }) => (
            <ul className="list-disc list-outside ml-5 mb-4 space-y-2">{children}</ul>
          ),
          ol: ({ children }) => (
            <ol className="list-decimal list-outside ml-5 mb-4 space-y-2">{children}</ol>
          ),
          li: ({ children }) => (
            <li className="leading-7 text-gray-700 dark:text-gray-300">{children}</li>
          ),

          // ── Emphasis ──────────────────────────────────────────────────────
          strong: ({ children }) => (
            <strong className="font-semibold text-gray-900 dark:text-white">{children}</strong>
          ),
          em: ({ children }) => (
            <em className="italic text-gray-700 dark:text-gray-300">{children}</em>
          ),

          // ── Code ──────────────────────────────────────────────────────────
          // Block code (with language tag) → SyntaxHighlighter
          // Inline code (no language tag)  → styled <code> span
          code({ className, children, ...props }) {
            const match = /language-(\w+)/.exec(className || '');
            if (match) {
              return (
                <SyntaxHighlighter
                  language={match[1]}
                  style={codeStyle}
                  PreTag="div"
                  customStyle={{
                    borderRadius: '10px',
                    fontSize:     '13px',
                    margin:       '12px 0',
                    padding:      '16px 18px',
                  }}
                  showLineNumbers={String(children).split('\n').length > 6}
                >
                  {String(children).replace(/\n$/, '')}
                </SyntaxHighlighter>
              );
            }
            return (
              <code
                className="bg-gray-100 dark:bg-gray-700 text-indigo-600 dark:text-indigo-400 px-1.5 py-0.5 rounded text-[13px] font-mono"
                {...props}
              >
                {children}
              </code>
            );
          },

          // ── Blockquote ────────────────────────────────────────────────────
          blockquote: ({ children }) => (
            <blockquote className="border-l-4 border-indigo-400 dark:border-indigo-600 pl-4 py-1 my-4 bg-indigo-50 dark:bg-indigo-950/30 rounded-r-lg text-gray-700 dark:text-gray-300 italic">
              {children}
            </blockquote>
          ),

          // ── Tables ────────────────────────────────────────────────────────
          table: ({ children }) => (
            <div className="overflow-x-auto my-5">
              <table className="min-w-full border-collapse text-sm">{children}</table>
            </div>
          ),
          thead: ({ children }) => (
            <thead className="bg-gray-100 dark:bg-gray-800">{children}</thead>
          ),
          th: ({ children }) => (
            <th className="border border-gray-300 dark:border-gray-600 px-4 py-2 font-semibold text-left text-gray-900 dark:text-white">
              {children}
            </th>
          ),
          td: ({ children }) => (
            <td className="border border-gray-300 dark:border-gray-600 px-4 py-2 text-gray-700 dark:text-gray-300">
              {children}
            </td>
          ),

          // ── Horizontal rule ───────────────────────────────────────────────
          hr: () => <hr className="my-6 border-gray-200 dark:border-gray-700" />,

          // ── Links ─────────────────────────────────────────────────────────
          a: ({ children, href }) => (
            <a
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="text-indigo-600 dark:text-indigo-400 underline hover:no-underline"
            >
              {children}
            </a>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
