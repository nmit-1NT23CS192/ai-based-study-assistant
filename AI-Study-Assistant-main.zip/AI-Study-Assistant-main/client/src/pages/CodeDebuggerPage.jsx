import { useState } from 'react';
import { Bug, BookOpen, Loader2, AlertCircle, Terminal } from 'lucide-react';
import debuggerService from '../services/debugger.service';
import CodeInput       from '../components/debugger/CodeInput';
import DebugOutput     from '../components/debugger/DebugOutput';
import LanguageSelector from '../components/debugger/LanguageSelector';
import { cn } from '../utils/cn';

const MODES = [
  { id: 'debug',   label: 'Debug',   icon: Bug      },
  { id: 'explain', label: 'Explain', icon: BookOpen },
];

export default function CodeDebuggerPage() {
  // ── Shared input state ────────────────────────────────────────────────
  const [code,        setCode]        = useState('');
  const [language,    setLanguage]    = useState('javascript');
  const [mode,        setMode]        = useState('debug');

  // ── Debug-only fields ─────────────────────────────────────────────────
  const [errorMessage, setErrorMessage] = useState('');
  const [description,  setDescription]  = useState('');

  // ── Result & UI state ─────────────────────────────────────────────────
  const [result,    setResult]    = useState(null);
  const [loading,   setLoading]   = useState(false);
  const [error,     setError]     = useState('');

  // ── Submit ────────────────────────────────────────────────────────────
  async function handleSubmit(e) {
    e.preventDefault();
    if (!code.trim()) return;
    setLoading(true);
    setError('');
    setResult(null);

    try {
      let data;
      if (mode === 'debug') {
        data = await debuggerService.debug(code, language, errorMessage, description);
      } else {
        data = await debuggerService.explain(code, language);
      }
      setResult(data);
    } catch (err) {
      setError(
        err.response?.data?.error ||
        err.response?.data?.errors?.[0]?.msg ||
        'Something went wrong. Please try again.',
      );
    } finally {
      setLoading(false);
    }
  }

  // "Apply to editor" from DebugOutput replaces code with the AI fix
  function handleApplyFix(fixedCode) {
    setCode(fixedCode);
    setResult(null); // clear output so user sees the updated code
  }

  const canSubmit = code.trim().length > 0 && !loading;

  return (
    // Full-height split layout — same pattern as ChatPage and PDFSummarizerPage
    <div className="flex h-full overflow-hidden flex-col lg:flex-row">

      {/* ── Left panel: Input form ───────────────────────────────────── */}
      <div className={cn(
        'flex flex-col shrink-0 border-b lg:border-b-0 lg:border-r border-gray-200 dark:border-gray-800',
        result ? 'lg:w-[480px] xl:w-[540px]' : 'lg:flex-1',
      )}>
        <div className="flex flex-col h-full overflow-hidden">

          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shrink-0">
            <div className="flex items-center gap-2">
              <Terminal size={18} className="text-indigo-500" />
              <h1 className="text-base font-semibold text-gray-900 dark:text-white">
                Code Debugger
              </h1>
            </div>
            <LanguageSelector
              value={language}
              onChange={val => { setLanguage(val); setResult(null); }}
              disabled={loading}
            />
          </div>

          {/* Mode tabs */}
          <div className="flex gap-0.5 p-1.5 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 shrink-0">
            {MODES.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => { setMode(id); setResult(null); setError(''); }}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all',
                  mode === id
                    ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm'
                    : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200',
                )}
              >
                <Icon size={14} />
                {label}
              </button>
            ))}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden p-4 gap-3">

            {/* Code input — takes most of the space */}
            <div className="flex-1 min-h-0">
              <CodeInput
                value={code}
                onChange={setCode}
                language={language}
                disabled={loading}
                placeholder={
                  mode === 'debug'
                    ? `// Paste your broken ${language} code here…`
                    : `// Paste the ${language} code you want explained…`
                }
              />
            </div>

            {/* Debug-only: error message + description */}
            {mode === 'debug' && (
              <div className="space-y-2 shrink-0">
                <div>
                  <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                    Error message <span className="text-gray-400">(optional)</span>
                  </label>
                  <input
                    type="text"
                    value={errorMessage}
                    onChange={e => setErrorMessage(e.target.value)}
                    disabled={loading}
                    placeholder="e.g. TypeError: cannot read properties of undefined"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono disabled:opacity-50 transition-shadow"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                    What were you trying to do? <span className="text-gray-400">(optional)</span>
                  </label>
                  <textarea
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    disabled={loading}
                    rows={2}
                    placeholder="Briefly describe what your code should do…"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs resize-none disabled:opacity-50 transition-shadow"
                  />
                </div>
              </div>
            )}

            {/* Error banner */}
            {error && (
              <div className="flex items-start gap-2 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 text-red-700 dark:text-red-400 rounded-xl px-3 py-2.5 text-xs shrink-0">
                <AlertCircle size={13} className="shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {/* Submit button */}
            <button
              type="submit"
              disabled={!canSubmit}
              className={cn(
                'flex items-center justify-center gap-2 py-2.5 rounded-xl font-medium text-sm transition-colors shrink-0',
                canSubmit
                  ? mode === 'debug'
                    ? 'bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white cursor-pointer'
                    : 'bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white cursor-pointer'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed',
              )}
            >
              {loading ? (
                <><Loader2 size={16} className="animate-spin" /> Analysing…</>
              ) : mode === 'debug' ? (
                <><Bug size={16} /> Debug Code</>
              ) : (
                <><BookOpen size={16} /> Explain Code</>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* ── Right panel: Output ──────────────────────────────────────── */}
      <div className="flex-1 min-w-0 min-h-0 overflow-hidden bg-gray-50 dark:bg-gray-950">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-full gap-3 text-center p-8">
            <Loader2 size={32} className="animate-spin text-indigo-500" />
            <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
              {mode === 'debug' ? 'Analysing your code…' : 'Reading your code…'}
            </p>
            <p className="text-xs text-gray-400 dark:text-gray-500">This usually takes 5–15 seconds</p>
          </div>
        ) : result ? (
          <DebugOutput
            result={result}
            mode={mode}
            language={language}
            onApplyFix={handleApplyFix}
          />
        ) : (
          /* Empty state */
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mb-4">
              <Terminal size={28} className="text-gray-300 dark:text-gray-600" />
            </div>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
              No output yet
            </p>
            <p className="text-xs text-gray-400 dark:text-gray-500 max-w-xs">
              {mode === 'debug'
                ? 'Paste broken code on the left, optionally add the error message, then click Debug.'
                : 'Paste any code on the left and click Explain to understand what it does.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
