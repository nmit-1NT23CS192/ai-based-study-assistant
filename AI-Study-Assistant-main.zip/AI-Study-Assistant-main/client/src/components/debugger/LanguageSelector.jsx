import { cn } from '../../utils/cn';

export const LANGUAGES = [
  { value: 'javascript', label: 'JavaScript', color: 'bg-yellow-400',              dot: 'bg-yellow-400' },
  { value: 'typescript', label: 'TypeScript',  color: 'bg-blue-500',               dot: 'bg-blue-500'   },
  { value: 'python',     label: 'Python',      color: 'bg-sky-500',                dot: 'bg-sky-500'    },
  { value: 'java',       label: 'Java',        color: 'bg-orange-500',             dot: 'bg-orange-500' },
  { value: 'php',        label: 'PHP',         color: 'bg-violet-500',             dot: 'bg-violet-500' },
  { value: 'cpp',        label: 'C++',         color: 'bg-blue-700',               dot: 'bg-blue-700'   },
  { value: 'c',          label: 'C',           color: 'bg-slate-500',              dot: 'bg-slate-500'  },
  { value: 'html',       label: 'HTML',        color: 'bg-orange-400',             dot: 'bg-orange-400' },
  { value: 'css',        label: 'CSS',         color: 'bg-sky-400',                dot: 'bg-sky-400'    },
  { value: 'sql',        label: 'SQL',         color: 'bg-teal-500',               dot: 'bg-teal-500'   },
  { value: 'other',      label: 'Other',       color: 'bg-gray-400',               dot: 'bg-gray-400'   },
];

export function getLanguage(value) {
  return LANGUAGES.find(l => l.value === value) ?? LANGUAGES[LANGUAGES.length - 1];
}

// Maps our values to react-syntax-highlighter language names
export const SYNTAX_LANG_MAP = {
  javascript: 'javascript',
  typescript: 'typescript',
  python:     'python',
  java:       'java',
  php:        'php',
  cpp:        'cpp',
  c:          'c',
  html:       'html',
  css:        'css',
  sql:        'sql',
  other:      'text',
};

export default function LanguageSelector({ value, onChange, disabled }) {
  const selected = getLanguage(value);

  return (
    <div className="relative inline-flex items-center gap-2">
      <span className={cn('w-2.5 h-2.5 rounded-full shrink-0', selected.dot)} />
      <select
        value={value}
        onChange={e => onChange(e.target.value)}
        disabled={disabled}
        className="appearance-none bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg pl-2 pr-6 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 cursor-pointer"
      >
        {LANGUAGES.map(lang => (
          <option key={lang.value} value={lang.value}>{lang.label}</option>
        ))}
      </select>
      {/* Custom chevron */}
      <span className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-gray-400">
        <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
          <path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </span>
    </div>
  );
}
