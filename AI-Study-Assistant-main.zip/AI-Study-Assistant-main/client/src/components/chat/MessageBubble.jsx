import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Brain, Copy, Check } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { cn } from '../../utils/cn';

// ── Typing indicator ───────────────────────────────────────────────────────

function TypingIndicator() {
  return (
    <div className="flex gap-1 items-center h-5 px-1">
      {[0, 150, 300].map(delay => (
        <span
          key={delay}
          className="w-2 h-2 rounded-full bg-gray-400 dark:bg-gray-500 animate-bounce"
          style={{ animationDelay: `${delay}ms`, animationDuration: '900ms' }}
        />
      ))}
    </div>
  );
}

// ── MarkdownContent ────────────────────────────────────────────────────────
// Renders AI markdown with syntax-highlighted code blocks.
// Uses react-markdown v10 component API.

function MarkdownContent({ content }) {
  const { theme } = useTheme();
  const codeStyle = theme === 'dark' ? oneDark : oneLight;

  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      components={{
        // Block vs inline code: block code has a language-xxx className
        code({ className, children, ...props }) {
          const match = /language-(\w+)/.exec(className || '');

          if (match) {
            return (
              <SyntaxHighlighter
                language={match[1]}
                style={codeStyle}
                PreTag="div"
                customStyle={{
                  borderRadius: '8px',
                  fontSize: '12.5px',
                  margin: '10px 0',
                  padding: '14px 16px',
                }}
                showLineNumbers={String(children).split('\n').length > 5}
                wrapLongLines={false}
              >
                {String(children).replace(/\n$/, '')}
              </SyntaxHighlighter>
            );
          }

          return (
            <code
              className="bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 px-1.5 py-0.5 rounded text-[12.5px] font-mono"
              {...props}
            >
              {children}
            </code>
          );
        },

        // Styled markdown elements
        p:          ({ children }) => <p className="mb-3 last:mb-0 leading-relaxed">{children}</p>,
        h1:         ({ children }) => <h1 className="text-lg font-bold mb-2 mt-4 first:mt-0">{children}</h1>,
        h2:         ({ children }) => <h2 className="text-base font-bold mb-2 mt-3 first:mt-0">{children}</h2>,
        h3:         ({ children }) => <h3 className="text-sm font-semibold mb-1.5 mt-3 first:mt-0">{children}</h3>,
        ul:         ({ children }) => <ul className="list-disc list-outside ml-4 mb-3 space-y-1">{children}</ul>,
        ol:         ({ children }) => <ol className="list-decimal list-outside ml-4 mb-3 space-y-1">{children}</ol>,
        li:         ({ children }) => <li className="leading-relaxed">{children}</li>,
        blockquote: ({ children }) => (
          <blockquote className="border-l-4 border-gray-300 dark:border-gray-600 pl-3 my-3 text-gray-600 dark:text-gray-400 italic">
            {children}
          </blockquote>
        ),
        table:      ({ children }) => (
          <div className="overflow-x-auto my-3">
            <table className="min-w-full border-collapse text-sm">{children}</table>
          </div>
        ),
        th:         ({ children }) => (
          <th className="border border-gray-300 dark:border-gray-600 px-3 py-1.5 bg-gray-100 dark:bg-gray-700 font-semibold text-left">
            {children}
          </th>
        ),
        td:         ({ children }) => (
          <td className="border border-gray-300 dark:border-gray-600 px-3 py-1.5">{children}</td>
        ),
        a:          ({ children, href }) => (
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="text-indigo-600 dark:text-indigo-400 underline hover:no-underline"
          >
            {children}
          </a>
        ),
        hr: () => <hr className="my-4 border-gray-200 dark:border-gray-700" />,
      }}
    >
      {content}
    </ReactMarkdown>
  );
}

// ── MessageBubble ──────────────────────────────────────────────────────────

export default function MessageBubble({ message }) {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === 'USER';

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API unavailable — fail silently
    }
  }

  const timestamp = new Date(message.createdAt).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  // ── Typing indicator ─────────────────────────────────────────────────────
  if (message.isTyping) {
    return (
      <div className="flex items-end gap-2.5 animate-msg-in">
        <div className="w-7 h-7 rounded-full bg-indigo-600 flex items-center justify-center shrink-0">
          <Brain size={14} className="text-white" />
        </div>
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm">
          <TypingIndicator />
        </div>
      </div>
    );
  }

  // ── User bubble ──────────────────────────────────────────────────────────
  if (isUser) {
    return (
      <div className="flex justify-end group animate-msg-in">
        <div className="max-w-[75%] flex flex-col items-end gap-1">
          <div className="bg-indigo-600 text-white rounded-2xl rounded-br-sm px-4 py-3 shadow-sm">
            <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">
              {message.content}
            </p>
          </div>
          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <span className="text-xs text-gray-400">{timestamp}</span>
            <button
              onClick={handleCopy}
              title="Copy message"
              className="p-1 rounded text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
            >
              {copied ? <Check size={12} className="text-green-500" /> : <Copy size={12} />}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── AI bubble ────────────────────────────────────────────────────────────
  return (
    <div className="flex items-start gap-2.5 group animate-msg-in">
      {/* AI avatar */}
      <div className="w-7 h-7 rounded-full bg-indigo-600 flex items-center justify-center shrink-0 mt-0.5">
        <Brain size={14} className="text-white" />
      </div>

      <div className="flex-1 min-w-0 max-w-[85%]">
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm">
          <div className="text-sm text-gray-800 dark:text-gray-100">
            <MarkdownContent content={message.content} />
          </div>
        </div>
        <div className="flex items-center gap-2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <span className="text-xs text-gray-400">{timestamp}</span>
          <button
            onClick={handleCopy}
            title="Copy response"
            className="p-1 rounded text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
          >
            {copied ? <Check size={12} className="text-green-500" /> : <Copy size={12} />}
          </button>
        </div>
      </div>
    </div>
  );
}
