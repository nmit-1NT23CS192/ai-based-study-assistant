const prisma = require('../utils/prismaClient');

// ── createNote ──────────────────────────────────────────────────────────────
// Creates immediately with empty defaults — auto-save updates it.
// This avoids the create-vs-update ambiguity in the frontend.

async function createNote(req, res) {
  const userId = req.user.userId;
  const title   = String(req.body.title ?? '').trim() || 'Untitled Note';
  const content = String(req.body.content ?? '');

  try {
    const note = await prisma.note.create({
      data: { userId, title, content },
    });
    return res.status(201).json({ note });
  } catch (err) {
    console.error('[notes.create]', err);
    return res.status(500).json({ error: 'Failed to create note.' });
  }
}

// ── getUserNotes ────────────────────────────────────────────────────────────
// Returns metadata only (no content) so the list loads fast.
// Full content is fetched when a note is opened.

async function getUserNotes(req, res) {
  try {
    const notes = await prisma.note.findMany({
      where:   { userId: req.user.userId },
      orderBy: { updatedAt: 'desc' },
      select:  { id: true, title: true, createdAt: true, updatedAt: true },
    });
    return res.status(200).json({ notes });
  } catch (err) {
    console.error('[notes.getAll]', err);
    return res.status(500).json({ error: 'Failed to fetch notes.' });
  }
}

// ── getNote ─────────────────────────────────────────────────────────────────

async function getNote(req, res) {
  try {
    const note = await prisma.note.findUnique({ where: { id: req.params.id } });
    if (!note || note.userId !== req.user.userId) {
      return res.status(404).json({ error: 'Note not found.' });
    }
    return res.status(200).json({ note });
  } catch (err) {
    console.error('[notes.getOne]', err);
    return res.status(500).json({ error: 'Failed to fetch note.' });
  }
}

// ── updateNote ──────────────────────────────────────────────────────────────
// PATCH: only updates fields that are present in the body.
// Auto-save sends both title and content on every flush.

async function updateNote(req, res) {
  const { id } = req.params;
  const userId  = req.user.userId;

  try {
    const note = await prisma.note.findUnique({ where: { id } });
    if (!note || note.userId !== userId) {
      return res.status(404).json({ error: 'Note not found.' });
    }

    const data = {};
    if (req.body.title   !== undefined) data.title   = String(req.body.title).trim() || 'Untitled Note';
    if (req.body.content !== undefined) data.content = String(req.body.content);

    const updated = await prisma.note.update({ where: { id }, data });
    return res.status(200).json({ note: updated });
  } catch (err) {
    console.error('[notes.update]', err);
    return res.status(500).json({ error: 'Failed to update note.' });
  }
}

// ── deleteNote ──────────────────────────────────────────────────────────────

async function deleteNote(req, res) {
  const { id } = req.params;
  const userId  = req.user.userId;

  try {
    const note = await prisma.note.findUnique({ where: { id } });
    if (!note || note.userId !== userId) {
      return res.status(404).json({ error: 'Note not found.' });
    }
    await prisma.note.delete({ where: { id } });
    return res.status(200).json({ message: 'Note deleted.' });
  } catch (err) {
    console.error('[notes.delete]', err);
    return res.status(500).json({ error: 'Failed to delete note.' });
  }
}

module.exports = { createNote, getUserNotes, getNote, updateNote, deleteNote };
