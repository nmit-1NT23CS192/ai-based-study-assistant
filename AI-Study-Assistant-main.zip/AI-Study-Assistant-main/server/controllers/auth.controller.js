const bcrypt = require('bcrypt');
const prisma = require('../utils/prismaClient');
const { generateToken } = require('../utils/jwt.utils');

const SALT_ROUNDS = 10;
// 10 rounds ≈ 100ms hash time on modern hardware.
// Low enough to not slow down legitimate logins,
// high enough to make brute-forcing a stolen hash impractical.

// ── Helper ─────────────────────────────────────────────────────────────────

/**
 * Strips the password field before sending a user object to the client.
 * Done at the JS level (not only at the Prisma select level) so this
 * protection applies even if a future code path passes a raw DB row here.
 */
function sanitizeUser(user) {
  const { password: _password, ...safe } = user;
  return safe;
}

// ── Register ───────────────────────────────────────────────────────────────

async function register(req, res) {
  const { name, email, password } = req.body;
  // At this point, express-validator has already run — inputs are safe.

  try {
    const existing = await prisma.user.findUnique({ where: { email } });

    if (existing) {
      // 409 Conflict: the resource (email address) already exists.
      return res.status(409).json({ error: 'An account with that email already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    const user = await prisma.user.create({
      data: { name, email, password: hashedPassword },
    });

    const token = generateToken(user.id, user.role);

    return res.status(201).json({
      message: 'Account created successfully.',
      token,
      user: sanitizeUser(user),
    });
  } catch (err) {
    console.error('[auth.register]', err);
    return res.status(500).json({ error: 'Failed to create account. Please try again.' });
  }
}

// ── Login ──────────────────────────────────────────────────────────────────

async function login(req, res) {
  const { email, password } = req.body;

  try {
    const user = await prisma.user.findUnique({ where: { email } });

    // SECURITY: identical error message whether the email doesn't exist
    // or the password is wrong. This prevents user enumeration — an attacker
    // cannot tell whether an email is registered by the error response.
    const passwordMatch = user ? await bcrypt.compare(password, user.password) : false;

    if (!user || !passwordMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Banned users cannot log in
    if (user.isActive === false) {
      return res.status(403).json({ error: 'Your account has been deactivated. Please contact support.' });
    }

    const token = generateToken(user.id, user.role);

    return res.status(200).json({
      message: 'Login successful.',
      token,
      user: sanitizeUser(user),
    });
  } catch (err) {
    console.error('[auth.login]', err);
    return res.status(500).json({ error: 'Login failed. Please try again.' });
  }
}

// ── Get Current User ───────────────────────────────────────────────────────

async function getMe(req, res) {
  // req.user.userId is set by the protect middleware — token is already verified.
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.userId },
      // Using Prisma select instead of sanitizeUser() here: the password
      // is never fetched from the DB at all, not just stripped afterward.
      select: {
        id:        true,
        name:      true,
        email:     true,
        role:      true,
        avatarUrl: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    if (!user) {
      // Token was valid but the account was deleted after it was issued.
      return res.status(404).json({ error: 'Account not found.' });
    }

    return res.status(200).json({ user });
  } catch (err) {
    console.error('[auth.getMe]', err);
    return res.status(500).json({ error: 'Failed to fetch user data.' });
  }
}

module.exports = { register, login, getMe };
