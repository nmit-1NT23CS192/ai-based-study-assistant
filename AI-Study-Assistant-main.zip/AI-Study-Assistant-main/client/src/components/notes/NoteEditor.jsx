import MDEditor from '@uiw/react-md-editor';
import { Loader2, Check, AlertCircle } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

// @uiw/react-md-editor v4 uses data-color-mode on the container div
// to switch between light and dark themes.

const STATUS_UI = {
  saving: { icon: Loader2, text: 'Saving…',       className: 'text-gray-400 animate-pulse'         },
  saved:  { icon: Check,   text: 'Saved',          className: 'text-emerald-500'                    },
  error:  { icon: AlertCircle, text: 'Save failed', className: 'text-red-500'                       },
  idle:   null,
};

/**
 * Markdown editor for a single note.
 *
 * Receives controlled title + content values from NotesPage.
 * Notifies the parent on every keystroke — debounced auto-save lives in the parent.
 */
export default function NoteEditor({
  title,
  content,
  onTitleChange,
  onContentChange,
  saveStatus,
  disabled,
}) {
  const { theme } = useTheme();
  const statusInfo = STATUS_UI[saveStatus];

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900">

      {/* ── Title row ────────────────────────────────────────────────── */}
      <div className="shrink-0 px-6 pt-5 pb-3 border-b border-gray-200 dark:border-gray-800">
        <input
          type="text"
          value={title}
          onChange={e => onTitleChange(e.target.value)}
          placeholder="Note title…"
          disabled={disabled}
          maxLength={200}
          className="w-full text-xl font-bold bg-transparent outline-none text-gray-900 dark:text-white placeholder:text-gray-300 dark:placeholder:text-gray-600 disabled:opacity-50"
        />

        {/* Save status indicator */}
        <div className="flex items-center gap-1.5 mt-1.5 h-4">
          {statusInfo && (
            <>
              <statusInfo.icon
                size={11}
                className={statusInfo.className + (saveStatus === 'saving' ? '' : '')}
              />
              <span className={`text-xs ${statusInfo.className}`}>
                {statusInfo.text}
              </span>
            </>
          )}
        </div>
      </div>

      {/* ── MDEditor ─────────────────────────────────────────────────── */}
      {/*
        data-color-mode is the official way to control the editor's theme.
        "dark" / "light" toggles the editor's own CSS variables.
      */}
      <div
        className="flex-1 overflow-hidden"
        data-color-mode={theme === 'dark' ? 'dark' : 'light'}
      >
        <MDEditor
          value={content}
          onChange={val => onContentChange(val ?? '')}
          preview="live"
          visibleDragbar={false}
          style={{ height: '100%', borderRadius: 0, border: 'none' }}
          textareaProps={{ disabled }}
        />
      </div>
    </div>
  );
}
