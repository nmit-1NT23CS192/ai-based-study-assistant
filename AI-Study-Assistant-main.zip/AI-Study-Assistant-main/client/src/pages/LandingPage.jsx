import { Navigate, Link } from 'react-router-dom';
import {
  Brain, MessageSquare, Layers, BookOpen, FileText,
  Terminal, StickyNote, ArrowRight,
  Upload, Sparkles, GraduationCap, CheckCircle, Moon, Sun,
} from 'lucide-react';

// Lucide v1 removed brand icons — using inline SVG for GitHub
function GithubIcon({ size = 16, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0 1 12 6.844a9.59 9.59 0 0 1 2.504.337c1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.02 10.02 0 0 0 22 12.017C22 6.484 17.522 2 12 2z" />
    </svg>
  );
}
import { useAuth }  from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import LoadingSpinner from '../components/LoadingSpinner';

// ── Data ───────────────────────────────────────────────────────────────────

const FEATURES = [
  {
    icon:   MessageSquare,
    title:  'AI Chat Assistant',
    desc:   'Ask anything about your subjects. Multi-turn conversations saved automatically.',
    color:  'bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400',
  },
  {
    icon:   Layers,
    title:  'Smart Flashcards',
    desc:   'AI generates Q&A flashcards from any topic. Study with immersive 3D flip cards.',
    color:  'bg-violet-100 dark:bg-violet-950 text-violet-600 dark:text-violet-400',
  },
  {
    icon:   BookOpen,
    title:  'Study Reviewer',
    desc:   'Get AI-written study reviewers — comprehensive, Q&A, key concepts, or quick summary.',
    color:  'bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400',
  },
  {
    icon:   FileText,
    title:  'PDF Summarizer',
    desc:   'Upload any PDF and get instant AI summaries, key points, or study guides.',
    color:  'bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400',
  },
  {
    icon:   Terminal,
    title:  'Code Debugger',
    desc:   'Paste broken code and get a clear explanation of the bug plus the fixed version.',
    color:  'bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400',
  },
  {
    icon:   StickyNote,
    title:  'Smart Notes',
    desc:   'Markdown note editor with 2-second auto-save. Study materials always at hand.',
    color:  'bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400',
  },
];

const STEPS = [
  {
    step:  '01',
    icon:  Upload,
    title: 'Input your material',
    desc:  'Type a topic, paste your notes, or upload a PDF. Any study material works.',
  },
  {
    step:  '02',
    icon:  Sparkles,
    title: 'AI processes instantly',
    desc:  'Google Gemini 2.5 Flash analyzes your content and generates study materials in seconds.',
  },
  {
    step:  '03',
    icon:  GraduationCap,
    title: 'Study smarter',
    desc:  'Use flashcards, reviewers, summaries, and an AI tutor to ace your exams.',
  },
];

const TECH_STACK = [
  { label: 'React 19',    bg: 'bg-cyan-50  dark:bg-cyan-950',   text: 'text-cyan-700   dark:text-cyan-300'   },
  { label: 'Vite',        bg: 'bg-violet-50 dark:bg-violet-950', text: 'text-violet-700 dark:text-violet-300' },
  { label: 'Tailwind v4', bg: 'bg-sky-50    dark:bg-sky-950',    text: 'text-sky-700    dark:text-sky-300'    },
  { label: 'Node.js 20',  bg: 'bg-green-50  dark:bg-green-950',  text: 'text-green-700  dark:text-green-300'  },
  { label: 'Express 5',   bg: 'bg-gray-100  dark:bg-gray-800',   text: 'text-gray-700   dark:text-gray-300'   },
  { label: 'PostgreSQL',  bg: 'bg-blue-50   dark:bg-blue-950',   text: 'text-blue-700   dark:text-blue-300'   },
  { label: 'Prisma 7',    bg: 'bg-indigo-50 dark:bg-indigo-950', text: 'text-indigo-700 dark:text-indigo-300' },
  { label: 'Gemini AI',   bg: 'bg-red-50    dark:bg-red-950',    text: 'text-red-700    dark:text-red-300'    },
  { label: 'Cloudinary',  bg: 'bg-amber-50  dark:bg-amber-950',  text: 'text-amber-700  dark:text-amber-300'  },
];

// ── Sub-components ──────────────────────────────────────────────────────────

function Navbar({ user, theme, toggleTheme }) {
  return (
    <nav className="sticky top-0 z-50 border-b border-gray-200/80 dark:border-gray-800/80 bg-white/80 dark:bg-gray-950/80 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
            <Brain size={18} className="text-white" />
          </div>
          <span className="font-bold text-gray-900 dark:text-white">AI Study Assistant</span>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
          </button>

          {user ? (
            <Link
              to="/dashboard"
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium transition-colors"
            >
              Go to Dashboard <ArrowRight size={14} />
            </Link>
          ) : (
            <>
              <Link
                to="/login"
                className="px-4 py-2 rounded-lg text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium transition-colors"
              >
                Get Started
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

// ── LandingPage ────────────────────────────────────────────────────────────

export default function LandingPage() {
  const { user, loading } = useAuth();
  const { theme, toggleTheme } = useTheme();

  // All hooks above any conditional return
  if (loading) return <LoadingSpinner fullScreen />;
  if (user)    return <Navigate to="/dashboard" replace />;

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-white">
      <Navbar user={user} theme={theme} toggleTheme={toggleTheme} />

      {/* ── Hero ───────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden py-24 sm:py-32">
        {/* Gradient orb backgrounds */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-200 h-100 bg-linear-to-b from-indigo-100 to-transparent dark:from-indigo-950/30 dark:to-transparent rounded-full blur-3xl opacity-60 pointer-events-none" />

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 text-sm font-medium mb-8">
            <Sparkles size={14} />
            Powered by Google Gemini 2.5 Flash
          </div>

          {/* Headline */}
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6 leading-[1.1]">
            Your AI Study Partner
            <span className="block bg-linear-to-r from-indigo-600 via-violet-600 to-indigo-600 bg-clip-text text-transparent">
              for College
            </span>
          </h1>

          {/* Subtext */}
          <p className="text-lg sm:text-xl text-gray-500 dark:text-gray-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Flashcards, study reviewers, PDF summaries, AI chat, code debugging,
            and smart notes — everything a BSIT student needs, powered by AI.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
            <Link
              to="/register"
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-sm transition-colors shadow-lg shadow-indigo-200 dark:shadow-none"
            >
              Start for Free <ArrowRight size={16} />
            </Link>
            <a
              href="https://github.com/Iya15/AI-Study-Assistant"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-6 py-3 rounded-xl border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-semibold text-sm hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            >
              <GithubIcon size={16} /> View on GitHub
            </a>
          </div>

          {/* Trust indicators */}
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-gray-400 dark:text-gray-500">
            {['100% Free', 'No credit card', 'Open source'].map(item => (
              <span key={item} className="flex items-center gap-1.5">
                <CheckCircle size={13} className="text-emerald-500" /> {item}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ───────────────────────────────────────────────────── */}
      <section className="py-20 bg-gray-50 dark:bg-gray-900/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Everything you need to study smarter
            </h2>
            <p className="text-gray-500 dark:text-gray-400 max-w-xl mx-auto">
              Six AI-powered tools in one platform — no subscriptions, no limits on the features that matter.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURES.map(({ icon: Icon, title, desc, color }) => (
              <div
                key={title}
                className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
              >
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center mb-4 ${color}`}>
                  <Icon size={22} />
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">{title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How it works ───────────────────────────────────────────────── */}
      <section className="py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">How it works</h2>
            <p className="text-gray-500 dark:text-gray-400">
              From material to mastery in three steps.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {/* Connector line — desktop only */}
            <div className="hidden md:block absolute top-10 left-[calc(33.33%+1rem)] right-[calc(33.33%+1rem)] h-px bg-linear-to-r from-indigo-200 via-indigo-300 to-indigo-200 dark:from-indigo-900 dark:via-indigo-700 dark:to-indigo-900" />

            {STEPS.map(({ step, icon: Icon, title, desc }) => (
              <div key={step} className="relative text-center">
                {/* Step icon */}
                <div className="relative inline-flex">
                  <div className="w-20 h-20 rounded-2xl bg-indigo-600 flex items-center justify-center mx-auto mb-5 shadow-lg shadow-indigo-200 dark:shadow-none">
                    <Icon size={32} className="text-white" />
                  </div>
                  <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-white dark:bg-gray-950 border-2 border-indigo-600 text-indigo-600 text-xs font-bold flex items-center justify-center">
                    {step.slice(1)}
                  </span>
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">{title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Tech stack ─────────────────────────────────────────────────── */}
      <section className="py-16 bg-gray-50 dark:bg-gray-900/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <p className="text-sm font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-8">
            Built with modern tech
          </p>
          <div className="flex flex-wrap justify-center gap-2.5">
            {TECH_STACK.map(({ label, bg, text }) => (
              <span
                key={label}
                className={`px-3.5 py-1.5 rounded-full text-sm font-medium ${bg} ${text}`}
              >
                {label}
              </span>
            ))}
          </div>
          <p className="mt-6 text-sm text-gray-400 dark:text-gray-500">
            Full-stack SaaS architecture · JWT auth · REST API · Prisma ORM · 100% free infrastructure
          </p>
        </div>
      </section>

      {/* ── CTA ────────────────────────────────────────────────────────── */}
      <section className="py-24">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Ready to study smarter?
          </h2>
          <p className="text-gray-500 dark:text-gray-400 mb-8">
            Join students who are already using AI to study faster and remember more.
          </p>
          <Link
            to="/register"
            className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-base transition-colors shadow-lg shadow-indigo-200 dark:shadow-none"
          >
            Create free account <ArrowRight size={18} />
          </Link>
        </div>
      </section>

      {/* ── Footer ─────────────────────────────────────────────────────── */}
      <footer className="border-t border-gray-200 dark:border-gray-800 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-gray-400 dark:text-gray-500">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center">
              <Brain size={13} className="text-white" />
            </div>
            <span>AI Study Assistant · Built for BSIT students</span>
          </div>
          <div className="flex items-center gap-5">
            <Link to="/login"    className="hover:text-gray-700 dark:hover:text-gray-300 transition-colors">Sign In</Link>
            <Link to="/register" className="hover:text-gray-700 dark:hover:text-gray-300 transition-colors">Sign Up</Link>
            <a
              href="https://github.com/Iya15/AI-Study-Assistant"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
            >
              <GithubIcon size={14} /> GitHub
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
