const prisma           = require('../utils/prismaClient');
const debuggerService  = require('../services/debugger.service');

const VALID_LANGUAGES = [
  'javascript', 'typescript', 'python', 'java', 'php',
  'cpp', 'c', 'html', 'css', 'sql', 'other',
];

const DEBUG_LIMIT  = 15;   // per hour
const WINDOW_MS    = 60 * 60 * 1000;

async function getUsageCount(userId, feature) {
  return prisma.aiUsageLog.count({
    where: {
      userId,
      feature,
      createdAt: { gte: new Date(Date.now() - WINDOW_MS) },
    },
  });
}

// ── debugCode ──────────────────────────────────────────────────────────────

async function debugCode(req, res) {
  const userId = req.user.userId;
  let { code, language, errorMessage, description } = req.body;

  code         = typeof code     === 'string' ? code.trim()         : '';
  language     = typeof language === 'string' ? language.toLowerCase().trim() : 'other';
  errorMessage = typeof errorMessage === 'string' ? errorMessage.trim() : '';
  description  = typeof description  === 'string' ? description.trim()  : '';

  if (!code)              return res.status(422).json({ error: 'Code is required.' });
  if (code.length > 8000) return res.status(422).json({ error: 'Code must be 8000 characters or fewer.' });
  if (!VALID_LANGUAGES.includes(language)) language = 'other';

  try {
    const count = await getUsageCount(userId, 'debugger');
    if (count >= DEBUG_LIMIT) {
      return res.status(429).json({
        error: `You have reached the ${DEBUG_LIMIT} debug requests/hour limit. Please wait and try again.`,
      });
    }

    const { explanation, fixedCode, keyChanges, tokensUsed } =
      await debuggerService.debugCodeWithAI(code, language, errorMessage, description);

    await prisma.aiUsageLog.create({
      data: { userId, feature: 'debugger', tokensUsed },
    });

    return res.status(200).json({ explanation, fixedCode, keyChanges, language });

  } catch (err) {
    if (err.code === 'GEMINI_QUOTA' || err.status === 429) return res.status(429).json({ error: err.message });
    if (err.code === 'SAFETY_BLOCK') return res.status(400).json({ error: 'Content safety policy prevented analysis.' });
    console.error('[debugger.debugCode]', err);
    return res.status(500).json({ error: err.message || 'Failed to debug code. Please try again.' });
  }
}

// ── explainCode ────────────────────────────────────────────────────────────

async function explainCode(req, res) {
  const userId = req.user.userId;
  let { code, language } = req.body;

  code     = typeof code     === 'string' ? code.trim()         : '';
  language = typeof language === 'string' ? language.toLowerCase().trim() : 'other';

  if (!code)              return res.status(422).json({ error: 'Code is required.' });
  if (code.length > 8000) return res.status(422).json({ error: 'Code must be 8000 characters or fewer.' });
  if (!VALID_LANGUAGES.includes(language)) language = 'other';

  try {
    const count = await getUsageCount(userId, 'debugger');
    if (count >= DEBUG_LIMIT) {
      return res.status(429).json({
        error: `You have reached the ${DEBUG_LIMIT} requests/hour limit. Please wait and try again.`,
      });
    }

    const { explanation, tokensUsed } =
      await debuggerService.explainCodeWithAI(code, language);

    await prisma.aiUsageLog.create({
      data: { userId, feature: 'debugger', tokensUsed },
    });

    return res.status(200).json({ explanation, language });

  } catch (err) {
    if (err.code === 'GEMINI_QUOTA' || err.status === 429) return res.status(429).json({ error: err.message });
    if (err.code === 'SAFETY_BLOCK') return res.status(400).json({ error: 'Content safety policy prevented analysis.' });
    console.error('[debugger.explainCode]', err);
    return res.status(500).json({ error: err.message || 'Failed to explain code. Please try again.' });
  }
}

module.exports = { debugCode, explainCode };
