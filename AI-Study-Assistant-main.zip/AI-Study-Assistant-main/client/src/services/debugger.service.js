import api from './api';

const debuggerService = {
  async debug(code, language, errorMessage = '', description = '') {
    const res = await api.post('/debugger/debug', {
      code, language, errorMessage, description,
    });
    return res.data; // { explanation, fixedCode, keyChanges, language }
  },

  async explain(code, language) {
    const res = await api.post('/debugger/explain', { code, language });
    return res.data; // { explanation, language }
  },
};

export default debuggerService;
