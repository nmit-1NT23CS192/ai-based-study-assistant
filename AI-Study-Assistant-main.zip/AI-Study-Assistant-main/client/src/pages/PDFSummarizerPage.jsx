import { useEffect, useState } from 'react';
import { FileText, X } from 'lucide-react';
import materialService from '../services/material.service';
import FileUploader    from '../components/pdf/FileUploader';
import MaterialCard    from '../components/pdf/MaterialCard';
import SummaryViewer   from '../components/pdf/SummaryViewer';
import LoadingSpinner  from '../components/LoadingSpinner';

export default function PDFSummarizerPage() {
  const [materials,    setMaterials]    = useState([]);
  const [loadingList,  setLoadingList]  = useState(true);
  const [summaryResult, setSummaryResult] = useState(null); // { summary, summaryType, materialTitle }

  useEffect(() => {
    loadMaterials();
  }, []);

  async function loadMaterials() {
    setLoadingList(true);
    try {
      const data = await materialService.getAll();
      setMaterials(data);
    } finally {
      setLoadingList(false);
    }
  }

  function handleUploaded(newMaterial) {
    setMaterials(prev => [newMaterial, ...prev]);
  }

  async function handleSummarize(materialId, summaryType) {
    const result = await materialService.summarize(materialId, summaryType);
    setSummaryResult(result);
  }

  async function handleDelete(materialId) {
    await materialService.remove(materialId);
    setMaterials(prev => prev.filter(m => m.id !== materialId));
    // Close the summary viewer if it was showing this material's summary
    setSummaryResult(null);
  }

  return (
    // Split layout: left = upload + list, right = summary viewer
    // On mobile, summary viewer appears below the list (flex-col).
    <div className="flex h-full overflow-hidden flex-col lg:flex-row">

      {/* ── Left panel: Uploader + Materials list ──────────────────── */}
      <div className={`flex flex-col ${summaryResult ? 'lg:w-80 xl:w-96' : 'w-full'} shrink-0 border-b lg:border-b-0 lg:border-r border-gray-200 dark:border-gray-800 overflow-hidden`}>

        {/* Scrollable inner container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">

          {/* Page header */}
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <FileText size={22} className="text-red-500" />
              PDF Summarizer
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Upload a PDF and AI will extract and summarise the content.
            </p>
          </div>

          {/* Uploader */}
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
            <h2 className="text-sm font-semibold text-gray-900 dark:text-white mb-4">
              Upload a file
            </h2>
            <FileUploader onUploaded={handleUploaded} />
          </div>

          {/* Materials list */}
          <div>
            <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
              My Materials
              {materials.length > 0 && (
                <span className="ml-2 text-xs font-normal text-gray-400">
                  ({materials.length})
                </span>
              )}
            </h2>

            {loadingList ? (
              <div className="flex items-center justify-center py-12">
                <LoadingSpinner size={24} />
              </div>
            ) : materials.length === 0 ? (
              <div className="text-center py-12 text-sm text-gray-400 dark:text-gray-500">
                <FileText size={28} className="mx-auto mb-2 opacity-30" />
                No files uploaded yet.
              </div>
            ) : (
              <div className="space-y-3">
                {materials.map(material => (
                  <MaterialCard
                    key={material.id}
                    material={material}
                    onSummarize={handleSummarize}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Right panel: Summary viewer ────────────────────────────── */}
      {summaryResult ? (
        <div className="flex-1 min-w-0 min-h-0 overflow-hidden bg-gray-50 dark:bg-gray-950">
          <SummaryViewer
            result={summaryResult}
            onClose={() => setSummaryResult(null)}
          />
        </div>
      ) : (
        // Empty state shown when no summary has been generated yet — desktop only
        <div className="hidden lg:flex flex-1 items-center justify-center text-center p-8 bg-gray-50 dark:bg-gray-950">
          <div>
            <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mx-auto mb-4">
              <FileText size={28} className="text-gray-300 dark:text-gray-600" />
            </div>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
              No summary yet
            </p>
            <p className="text-xs text-gray-400 dark:text-gray-500">
              Upload a PDF and click Summarize on any file.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
