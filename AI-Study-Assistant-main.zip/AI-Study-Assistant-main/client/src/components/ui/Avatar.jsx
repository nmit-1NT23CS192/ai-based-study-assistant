import { cn } from '../../utils/cn';

const SIZE = {
  sm: 'w-7 h-7 text-xs',
  md: 'w-9 h-9 text-sm',
  lg: 'w-11 h-11 text-base',
};

/**
 * Shows the user's avatar image, or falls back to coloured initials.
 * Used in both Sidebar (user footer) and Topbar (dropdown trigger).
 */
export default function Avatar({ user, size = 'md', className }) {
  const initials = (user?.name ?? '?')
    .split(' ')
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase() ?? '')
    .join('');

  if (user?.avatarUrl) {
    return (
      <img
        src={user.avatarUrl}
        alt={user.name}
        className={cn('rounded-full object-cover shrink-0', SIZE[size], className)}
      />
    );
  }

  return (
    <div
      aria-label={user?.name}
      className={cn(
        'rounded-full bg-indigo-600 text-white flex items-center justify-center font-semibold shrink-0',
        SIZE[size],
        className,
      )}
    >
      {initials}
    </div>
  );
}
