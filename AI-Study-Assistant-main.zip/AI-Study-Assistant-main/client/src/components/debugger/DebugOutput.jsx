import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Copy, Check, ArrowLeftRight, AlertCircle, List, Code2, BookOpen } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { SYNTAX_LANG_MAP } from './LanguageSelector';
import { cn } from '../../utils/cn';

// ── CopyButton ─────────────────────────────────────────────────────────────

function CopyButton({ text, label = 'Copy', size = 14 }) {
  const [copied, setCopied] = useState(false);
  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* silent */ }
  }
  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
    >
      {copied ? <Check size={size} className="text-emerald-500" /> : <Copy size={size} />}
      {copied ? 'Copied!' : label}
    </button>
  );
}

// ── Section wrapper ────────────────────────────────────────────────────────

function Section({ icon: Icon, title, accent = 'indigo', children }) {
  const accentMap = {
    indigo: 'border-indigo-300 dark:border-indigo-700 bg-indigo-50 dark:bg-indigo-950/30',
    emerald: 'border-emerald-300 dark:border-emerald-700 bg-emerald-50 dark:bg-emerald-950/30',
    amber:  'border-amber-300  dark:border-amber-700  bg-amber-50  dark:bg-amber-950/30',
  };
  const iconMap = {
    indigo:  'text-indigo-500',
    emerald: 'text-emerald-500',
    amber:   'text-amber-500',
  };
  return (
    <div className={cn('rounded-xl border p-4', accentMap[accent])}>
      <div className="flex items-center gap-2 mb-3">
        <Icon size={15} className={iconMap[accent]} />
        <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-100">{title}</h3>
      </div>
      {children}
    </div>
  );
}

// ── DebugResult ────────────────────────────────────────────────────────────

function DebugResult({ result, language, onApplyFix }) {
  const { theme } = useTheme();
  const codeStyle = theme === 'dark' ? oneDark : oneLight;
  const syntaxLang = SYNTAX_LANG_MAP[language] ?? 'text';

  return (
    <div className="space-y-4">
      {/* 1. Bug explanation */}
      <Section icon={AlertCircle} title="Bug Explanation" accent="amber">
        <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
          {result.explanation}
        </p>
      </Section>

      {/* 2. Fixed code */}
      <Section icon={Code2} title="Fixed Code" accent="emerald">
        <div className="flex items-center justify-end gap-2 mb-2">
          <button
            onClick={() => onApplyFix(result.fixedCode)}
            className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
          >
            <ArrowLeftRight size={12} />
            Apply to editor
          </button>
          <CopyButton text={result.fixedCode} label="Copy code" />
        </div>
        <SyntaxHighlighter
          language={syntaxLang}
          style={codeStyle}
          PreTag="div"
          customStyle={{ borderRadius: '8px', fontSize: '12px', margin: 0 }}
          showLineNumbers={result.fixedCode.split('\n').length > 4}
        >
          {result.fixedCode}
        </SyntaxHighlighter>
      </Section>

      {/* 3. Key changes */}
      {result.keyChanges?.length > 0 && (
        <Section icon={List} title="Key Changes" accent="indigo">
          <ul className="space-y-2">
            {result.keyChanges.map((change, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300">
                <span className="shrink-0 w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs font-bold mt-0.5">
                  {i + 1}
                </span>
                {change}
              </li>
            ))}
          </ul>
        </Section>
      )}
    </div>
  );
}

// ── ExplainResult ──────────────────────────────────────────────────────────
// Reuses the reviewer markdown styling pattern for free-form explanation.

function ExplainResult({ explanation }) {
  const { theme } = useTheme();
  const codeStyle = theme === 'dark' ? oneDark : oneLight;

  return (
    <Section icon={BookOpen} title="Code Explanation" accent="indigo">
      <div className="text-sm text-gray-800 dark:text-gray-100 leading-relaxed">
        <ReactMarkdown
          remarkPlugins={[remarkGfm]}
          components={{
            code({ className, children, ...props }) {
              const match = /language-(\w+)/.exec(className || '');
              if (match) {
                return (
                  <SyntaxHighlighter
                    language={match[1]}
                    style={codeStyle}
                    PreTag="div"
                    customStyle={{ borderRadius: '8px', fontSize: '12px', margin: '8px 0' }}
                  >
                    {String(children).replace(/\n$/, '')}
                  </SyntaxHighlighter>
                );
              }
              return (
                <code className="bg-gray-100 dark:bg-gray-800 text-indigo-600 dark:text-indigo-400 px-1.5 py-0.5 rounded text-[12px] font-mono" {...props}>
                  {children}
                </code>
              );
            },
            p:      ({ children }) => <p className="mb-3 last:mb-0 leading-7">{children}</p>,
            h2:     ({ children }) => <h2 className="text-base font-bold mt-5 mb-2 first:mt-0 text-gray-900 dark:text-white">{children}</h2>,
            h3:     ({ children }) => <h3 className="text-sm font-semibold mt-4 mb-1.5 text-gray-900 dark:text-white">{children}</h3>,
            ul:     ({ children }) => <ul className="list-disc list-outside ml-4 mb-3 space-y-1">{children}</ul>,
            ol:     ({ children }) => <ol className="list-decimal list-outside ml-4 mb-3 space-y-1">{children}</ol>,
            li:     ({ children }) => <li className="leading-7">{children}</li>,
            strong: ({ children }) => <strong className="font-semibold text-gray-900 dark:text-white">{children}</strong>,
          }}
        >
          {explanation}
        </ReactMarkdown>
      </div>
    </Section>
  );
}

// ── DebugOutput (main export) ──────────────────────────────────────────────

/**
 * Renders either a structured debug result (explanation + fixedCode + keyChanges)
 * or a free-form markdown explanation, depending on which mode was used.
 *
 * onApplyFix(fixedCode) — called when the user clicks "Apply to editor".
 * The parent CodeDebuggerPage receives this callback and updates the code state.
 */
export default function DebugOutput({ result, mode, language, onApplyFix }) {
  if (!result) return null;

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      {mode === 'debug' ? (
        <DebugResult result={result} language={language} onApplyFix={onApplyFix} />
      ) : (
        <ExplainResult explanation={result.explanation} />
      )}
    </div>
  );
}
