const prisma           = require('../utils/prismaClient');
const materialService  = require('../services/material.service');

const VALID_SUMMARY_TYPES = ['brief', 'detailed', 'key_points', 'study_guide'];
const SUMMARIZE_LIMIT     = 10;
const WINDOW_MS           = 60 * 60 * 1000;

async function getSummarizeCount(userId) {
  return prisma.aiUsageLog.count({
    where: {
      userId,
      feature:   'summarizer',
      createdAt: { gte: new Date(Date.now() - WINDOW_MS) },
    },
  });
}

// ── uploadMaterial ─────────────────────────────────────────────────────────

async function uploadMaterial(req, res) {
  if (!req.file) {
    return res.status(400).json({ error: 'No file provided.' });
  }

  const userId = req.user.userId;
  const title  = req.body.title?.trim() || req.file.originalname;

  try {
    const material = await materialService.uploadMaterial(userId, req.file, title);
    return res.status(201).json({
      material,
      message: material.extractedText
        ? 'File uploaded and text extracted successfully.'
        : 'File uploaded. Text extraction was not possible for this file (scanned or protected PDF).',
    });
  } catch (err) {
    console.error('[material.upload]', err);
    return res.status(500).json({ error: err.message || 'Upload failed. Please try again.' });
  }
}

// ── getUserMaterials ───────────────────────────────────────────────────────

async function getUserMaterials(req, res) {
  try {
    const materials = await materialService.getUserMaterials(req.user.userId);
    return res.status(200).json({ materials });
  } catch (err) {
    console.error('[material.getAll]', err);
    return res.status(500).json({ error: 'Failed to fetch materials.' });
  }
}

// ── getMaterial ────────────────────────────────────────────────────────────

async function getMaterial(req, res) {
  try {
    const material = await materialService.getMaterial(req.params.materialId, req.user.userId);
    if (!material) return res.status(404).json({ error: 'Material not found.' });
    return res.status(200).json({ material });
  } catch (err) {
    console.error('[material.getOne]', err);
    return res.status(500).json({ error: 'Failed to fetch material.' });
  }
}

// ── summarizeMaterial ──────────────────────────────────────────────────────

async function summarizeMaterial(req, res) {
  const userId      = req.user.userId;
  const summaryType = VALID_SUMMARY_TYPES.includes(req.body.summaryType)
    ? req.body.summaryType
    : 'brief';

  try {
    const count = await getSummarizeCount(userId);
    if (count >= SUMMARIZE_LIMIT) {
      return res.status(429).json({
        error: `You have reached the ${SUMMARIZE_LIMIT} summaries/hour limit. Please wait and try again.`,
      });
    }

    const { summary, tokensUsed, materialTitle } = await materialService.summarizeMaterial(
      req.params.materialId, userId, summaryType,
    );

    await prisma.aiUsageLog.create({
      data: { userId, feature: 'summarizer', tokensUsed },
    });

    return res.status(200).json({ summary, summaryType, materialTitle });

  } catch (err) {
    if (err.message === 'MATERIAL_NOT_FOUND') return res.status(404).json({ error: 'Material not found.' });
    if (err.message === 'NO_EXTRACTED_TEXT') {
      return res.status(422).json({
        error: 'This file could not be summarised because its text could not be extracted. This happens with scanned or password-protected PDFs.',
      });
    }
    if (err.code === 'GEMINI_QUOTA' || err.status === 429) return res.status(429).json({ error: err.message });
    if (err.code === 'SAFETY_BLOCK') return res.status(400).json({ error: 'Content safety policy prevented summarisation.' });
    console.error('[material.summarize]', err);
    return res.status(500).json({ error: 'Failed to generate summary. Please try again.' });
  }
}

// ── deleteMaterial ─────────────────────────────────────────────────────────

async function deleteMaterial(req, res) {
  try {
    await materialService.deleteMaterial(req.params.materialId, req.user.userId);
    return res.status(200).json({ message: 'Material deleted.' });
  } catch (err) {
    if (err.message === 'MATERIAL_NOT_FOUND') return res.status(404).json({ error: 'Material not found.' });
    if (err.message === 'MATERIAL_NOT_OWNED')  return res.status(404).json({ error: 'Material not found.' });
    console.error('[material.delete]', err);
    return res.status(500).json({ error: 'Failed to delete material.' });
  }
}

module.exports = { uploadMaterial, getUserMaterials, getMaterial, summarizeMaterial, deleteMaterial };
