const { Router } = require('express');
const {
  generateFlashcards,
  saveFlashcardSet,
  getMyFlashcardSets,
  getFlashcardSet,
  deleteFlashcardSet,
} = require('../controllers/flashcard.controller');
const { protect }       = require('../middleware/auth.middleware');
const { aiRateLimiter } = require('../middleware/rateLimiter.middleware');

const router = Router();

router.use(protect);

router.post('/generate',   aiRateLimiter, generateFlashcards);
router.post('/save',       saveFlashcardSet);
router.get('/',            getMyFlashcardSets);
router.get('/:setId',      getFlashcardSet);
router.delete('/:setId',   deleteFlashcardSet);

module.exports = router;
