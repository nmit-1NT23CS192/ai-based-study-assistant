import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { useTheme } from '../../context/ThemeContext';

// ── Feature colour palette ─────────────────────────────────────────────────
// Distinct enough to tell apart in both light and dark mode.

const FEATURES = [
  { key: 'chat',       label: 'Chat',        color: '#6366f1' },  // indigo
  { key: 'flashcard',  label: 'Flashcards',  color: '#8b5cf6' },  // violet
  { key: 'reviewer',   label: 'Reviewer',    color: '#0ea5e9' },  // sky
  { key: 'summarizer', label: 'Summarizer',  color: '#ef4444' },  // red
  { key: 'debugger',   label: 'Debugger',    color: '#f59e0b' },  // amber
];

// ── Data transformer ───────────────────────────────────────────────────────
// Converts flat [{ date, feature, count }] array into recharts format:
// [{ date, chat: n, flashcard: n, ... }]
// Generates all 30 days so every day appears on the X-axis (even zero days).

function buildChartData(stats) {
  const today = new Date();
  const days  = Array.from({ length: 30 }, (_, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() - (29 - i));
    return d.toISOString().split('T')[0];
  });

  const lookup = {};
  for (const s of stats) {
    lookup[`${s.date}__${s.feature}`] = s.count;
  }

  return days.map(date => {
    const row = { date };
    for (const { key } of FEATURES) {
      row[key] = lookup[`${date}__${key}`] ?? 0;
    }
    return row;
  });
}

// ── Custom tooltip ─────────────────────────────────────────────────────────

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  const total = payload.reduce((s, p) => s + (p.value ?? 0), 0);

  return (
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-3 shadow-lg text-xs">
      <p className="font-semibold text-gray-700 dark:text-gray-200 mb-2">{label}</p>
      {payload.map(p => p.value > 0 && (
        <div key={p.dataKey} className="flex items-center justify-between gap-6">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full" style={{ background: p.fill }} />
            <span className="text-gray-600 dark:text-gray-300">{p.name}</span>
          </span>
          <span className="font-medium text-gray-900 dark:text-white">{p.value}</span>
        </div>
      ))}
      <div className="mt-2 pt-2 border-t border-gray-100 dark:border-gray-700 flex justify-between font-semibold text-gray-700 dark:text-gray-200">
        <span>Total</span>
        <span>{total}</span>
      </div>
    </div>
  );
}

// ── UsageChart ─────────────────────────────────────────────────────────────

export default function UsageChart({ stats }) {
  const { theme } = useTheme();
  const isDark    = theme === 'dark';

  const axisColor = isDark ? '#6b7280' : '#9ca3af';  // gray-500 / gray-400
  const gridColor = isDark ? '#1f2937' : '#f3f4f6';  // gray-800 / gray-100

  const data = buildChartData(stats ?? []);

  // X-axis tick: show only every ~5th label to avoid crowding
  function formatXTick(val) {
    const date = new Date(val);
    if (isNaN(date)) return val;
    return `${date.getMonth() + 1}/${date.getDate()}`;
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} margin={{ top: 5, right: 10, left: -15, bottom: 0 }} barSize={8}>
        <CartesianGrid
          strokeDasharray="3 3"
          vertical={false}
          stroke={gridColor}
        />
        <XAxis
          dataKey="date"
          tickFormatter={formatXTick}
          tick={{ fontSize: 10, fill: axisColor }}
          tickLine={false}
          axisLine={false}
          interval={4}
        />
        <YAxis
          tick={{ fontSize: 10, fill: axisColor }}
          tickLine={false}
          axisLine={false}
          allowDecimals={false}
        />
        <Tooltip content={<CustomTooltip />} cursor={{ fill: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)' }} />
        <Legend
          iconType="circle"
          iconSize={8}
          wrapperStyle={{ fontSize: '11px', paddingTop: '12px' }}
        />
        {FEATURES.map(({ key, label, color }, idx) => (
          <Bar
            key={key}
            dataKey={key}
            name={label}
            stackId="features"
            fill={color}
            // Only round the top of the last stacked bar
            radius={idx === FEATURES.length - 1 ? [3, 3, 0, 0] : [0, 0, 0, 0]}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}
