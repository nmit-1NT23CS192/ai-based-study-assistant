const { Router } = require('express');
const { getUserAnalytics } = require('../controllers/analytics.controller');
const { protect } = require('../middleware/auth.middleware');

const router = Router();
router.use(protect);

// GET /api/analytics — user's personal study analytics
router.get('/', getUserAnalytics);

module.exports = router;
