import { useNavigate } from 'react-router-dom';
import {
  MessageSquare, Layers, BookOpen, FileText,
  Clock, TrendingUp, ArrowRight,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';

// ── Stats ──────────────────────────────────────────────────────────────────

const STATS = [
  { label: 'Flashcard Sets',    value: 0, icon: Layers,       color: 'text-violet-500' },
  { label: 'Saved Reviewers',   value: 0, icon: BookOpen,     color: 'text-sky-500'    },
  { label: 'Chat Sessions',     value: 0, icon: MessageSquare, color: 'text-indigo-500' },
  { label: 'Uploaded Materials', value: 0, icon: FileText,    color: 'text-emerald-500'},
];

// ── Quick actions ──────────────────────────────────────────────────────────

const QUICK_ACTIONS = [
  { label: 'Start AI Chat',        to: '/chat',       icon: MessageSquare, variant: 'primary'  },
  { label: 'Create Flashcards',    to: '/flashcards', icon: Layers,        variant: 'secondary' },
  { label: 'Generate Reviewer',    to: '/reviewer',   icon: BookOpen,      variant: 'secondary' },
  { label: 'Upload PDF',           to: '/summarizer', icon: FileText,      variant: 'secondary' },
];

// ── Component ──────────────────────────────────────────────────────────────

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const firstName = user?.name?.split(' ')[0] ?? 'there';

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6">
    <div className="max-w-5xl mx-auto space-y-8">

      {/* Welcome ──────────────────────────────────────────────────────── */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          Welcome back, {firstName} 👋
        </h2>
        <p className="text-gray-500 dark:text-gray-400 mt-1">
          Here's an overview of your study progress.
        </p>
      </div>

      {/* Stats row ────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {STATS.map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="p-5">
            <div className="flex items-start justify-between mb-3">
              <Icon size={20} className={color} />
              {/* Placeholder trend badge — will show real delta from API */}
              <Badge color="gray">—</Badge>
            </div>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{label}</p>
          </Card>
        ))}
      </div>

      {/* Quick actions ────────────────────────────────────────────────── */}
      <div>
        <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
          Quick Actions
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {QUICK_ACTIONS.map(({ label, to, icon: Icon, variant }) => (
            <Button
              key={to}
              variant={variant}
              className="flex-col h-20 gap-2 rounded-xl w-full"
              onClick={() => navigate(to)}
            >
              <Icon size={20} />
              <span className="text-xs font-medium leading-tight text-center">{label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Recent activity ──────────────────────────────────────────────── */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Recent Activity
          </h3>
          <button className="flex items-center gap-1 text-xs text-indigo-600 dark:text-indigo-400 hover:underline">
            View all <ArrowRight size={12} />
          </button>
        </div>

        {/* Empty state — replaced with real data in a later milestone */}
        <Card className="py-16 text-center">
          <div className="flex flex-col items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
              <Clock size={24} className="text-gray-400 dark:text-gray-500" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">
                No activity yet
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Start studying and your recent sessions will appear here.
              </p>
            </div>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => navigate('/chat')}
              className="mt-1"
            >
              <TrendingUp size={14} />
              Start your first session
            </Button>
          </div>
        </Card>
      </div>

    </div>
    </div>
  );
}
