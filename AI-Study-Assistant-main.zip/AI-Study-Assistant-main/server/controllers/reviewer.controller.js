const prisma           = require('../utils/prismaClient');
const reviewerService  = require('../services/reviewer.service');

const VALID_TYPES   = ['comprehensive', 'summary', 'key_concepts', 'q_and_a'];
const GENERATE_LIMIT = 5;
const WINDOW_MS      = 60 * 60 * 1000;

async function getGenerationCount(userId) {
  return prisma.aiUsageLog.count({
    where: {
      userId,
      feature:   'reviewer',
      createdAt: { gte: new Date(Date.now() - WINDOW_MS) },
    },
  });
}

// ── generateReviewer ───────────────────────────────────────────────────────

async function generateReviewer(req, res) {
  const userId = req.user.userId;
  let { topic, subject, inputText, reviewerType } = req.body;

  topic        = typeof topic    === 'string' ? topic.trim()    : '';
  subject      = typeof subject  === 'string' ? subject.trim()  : '';
  inputText    = typeof inputText === 'string' ? inputText.trim() : '';
  reviewerType = VALID_TYPES.includes(reviewerType) ? reviewerType : 'comprehensive';

  if (!topic)           return res.status(422).json({ error: 'Topic is required.' });
  if (topic.length > 200) return res.status(422).json({ error: 'Topic must be 200 characters or fewer.' });
  if (!subject)         return res.status(422).json({ error: 'Subject is required.' });
  if (inputText.length > 5000)
    return res.status(422).json({ error: 'Notes must be 5000 characters or fewer.' });

  try {
    const usageCount = await getGenerationCount(userId);
    if (usageCount >= GENERATE_LIMIT) {
      return res.status(429).json({
        error: `You have reached the ${GENERATE_LIMIT} reviewer generation/hour limit. Please wait and try again.`,
      });
    }

    const { content, tokensUsed } = await reviewerService.generateReviewerWithAI(
      topic, subject, reviewerType, inputText,
    );

    await prisma.aiUsageLog.create({
      data: { userId, feature: 'reviewer', tokensUsed },
    });

    return res.status(200).json({ content, topic, subject, reviewerType });

  } catch (err) {
    if (err.code === 'GEMINI_QUOTA' || err.status === 429) {
      return res.status(429).json({ error: err.message });
    }
    if (err.code === 'SAFETY_BLOCK') {
      return res.status(400).json({ error: 'This topic could not be processed due to content safety policies.' });
    }
    console.error('[reviewer.generate]', err);
    return res.status(500).json({ error: err.message || 'Failed to generate reviewer.' });
  }
}

// ── saveReviewer ───────────────────────────────────────────────────────────

async function saveReviewer(req, res) {
  const userId = req.user.userId;
  let { title, subject, content } = req.body;

  title   = typeof title   === 'string' ? title.trim()   : '';
  subject = typeof subject === 'string' ? subject.trim() : '';
  content = typeof content === 'string' ? content.trim() : '';

  if (!title)           return res.status(422).json({ error: 'Title is required.' });
  if (title.length > 150) return res.status(422).json({ error: 'Title must be 150 characters or fewer.' });
  if (!subject)         return res.status(422).json({ error: 'Subject is required.' });
  if (!content)         return res.status(422).json({ error: 'Content is required.' });

  try {
    const reviewer = await reviewerService.saveReviewer(userId, title, subject, content);
    return res.status(201).json({ reviewer });
  } catch (err) {
    console.error('[reviewer.save]', err);
    return res.status(500).json({ error: 'Failed to save reviewer.' });
  }
}

// ── getMyReviewers ─────────────────────────────────────────────────────────

async function getMyReviewers(req, res) {
  try {
    const reviewers = await reviewerService.getUserReviewers(req.user.userId);
    return res.status(200).json({ reviewers });
  } catch (err) {
    console.error('[reviewer.getAll]', err);
    return res.status(500).json({ error: 'Failed to fetch reviewers.' });
  }
}

// ── getReviewer ────────────────────────────────────────────────────────────

async function getReviewer(req, res) {
  try {
    const reviewer = await reviewerService.getReviewer(req.params.reviewerId, req.user.userId);
    if (!reviewer) return res.status(404).json({ error: 'Reviewer not found.' });
    return res.status(200).json({ reviewer });
  } catch (err) {
    console.error('[reviewer.getOne]', err);
    return res.status(500).json({ error: 'Failed to fetch reviewer.' });
  }
}

// ── deleteReviewer ─────────────────────────────────────────────────────────

async function deleteReviewer(req, res) {
  try {
    await reviewerService.deleteReviewer(req.params.reviewerId, req.user.userId);
    return res.status(200).json({ message: 'Reviewer deleted.' });
  } catch (err) {
    if (err.message === 'REVIEWER_NOT_FOUND') return res.status(404).json({ error: 'Reviewer not found.' });
    if (err.message === 'REVIEWER_NOT_OWNED') return res.status(404).json({ error: 'Reviewer not found.' });
    console.error('[reviewer.delete]', err);
    return res.status(500).json({ error: 'Failed to delete reviewer.' });
  }
}

module.exports = { generateReviewer, saveReviewer, getMyReviewers, getReviewer, deleteReviewer };
