import { Loader2 } from 'lucide-react';

/**
 * @param {boolean} fullScreen - Centers the spinner in the full viewport.
 *   Used while AuthContext is validating the stored token on app load.
 * @param {number}  size       - Icon size in px.
 */
export default function LoadingSpinner({ fullScreen = false, size = 24 }) {
  if (fullScreen) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white dark:bg-gray-950">
        <Loader2 size={size} className="animate-spin text-indigo-600 dark:text-indigo-400" />
      </div>
    );
  }

  return <Loader2 size={size} className="animate-spin" />;
}
