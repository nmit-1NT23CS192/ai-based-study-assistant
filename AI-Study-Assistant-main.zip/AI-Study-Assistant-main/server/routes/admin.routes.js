const { Router }     = require('express');
const { protect }    = require('../middleware/auth.middleware');
const { requireAdmin } = require('../middleware/admin.middleware');
const {
  getDashboardStats,
  getAIUsageStats,
  getUsers,
  toggleUserStatus,
} = require('../controllers/admin.controller');

const router = Router();

// All admin routes require a valid JWT AND the ADMIN role
router.use(protect, requireAdmin);

router.get('/stats/dashboard',           getDashboardStats);
router.get('/stats/ai-usage',            getAIUsageStats);
router.get('/users',                     getUsers);
router.patch('/users/:userId/status',    toggleUserStatus);

module.exports = router;
