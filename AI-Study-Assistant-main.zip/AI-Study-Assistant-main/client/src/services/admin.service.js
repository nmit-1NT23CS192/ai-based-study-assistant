import api from './api';

const adminService = {
  async getDashboardStats() {
    const res = await api.get('/admin/stats/dashboard');
    return res.data; // { totalUsers, totalAICalls, totalMaterials, activeToday }
  },

  async getAIUsageStats() {
    const res = await api.get('/admin/stats/ai-usage');
    return res.data.stats; // [{ date, feature, count, tokens }]
  },

  async getUsers({ page = 1, limit = 20, search = '' } = {}) {
    const res = await api.get('/admin/users', { params: { page, limit, search } });
    return res.data; // { users, total, page, totalPages }
  },

  async toggleUserStatus(userId) {
    const res = await api.patch(`/admin/users/${userId}/status`);
    return res.data.user; // { id, isActive, name }
  },
};

export default adminService;
