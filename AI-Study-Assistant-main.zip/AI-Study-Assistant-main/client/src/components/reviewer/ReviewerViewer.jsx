import { ArrowLeft, Printer, BookOpen, Calendar, FileText } from 'lucide-react';
import ReviewerContent from './ReviewerContent';
import { formatDate } from '../../utils/formatDate';

function wordCount(text) {
  return text?.trim().split(/\s+/).filter(w => w.length > 0).length ?? 0;
}

/**
 * Full-page viewer for a saved reviewer.
 *
 * Print behaviour:
 *   window.print() combined with @media print in index.css hides all
 *   .no-print elements (topbar, sidebar, action buttons) so only the
 *   .reviewer-print-area (the markdown content) appears in print / PDF.
 */
export default function ReviewerViewer({ reviewer, onBack }) {
  const words = wordCount(reviewer.content);

  function handlePrint() {
    window.print();
  }

  return (
    <div className="max-w-3xl mx-auto">

      {/* ── Toolbar (hidden on print) ─────────────────────────────────── */}
      <div className="no-print flex items-center justify-between mb-6 gap-4">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
        >
          <ArrowLeft size={16} />
          Back to Reviewers
        </button>

        <button
          onClick={handlePrint}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-gray-200 dark:border-gray-700 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
          title="Print or save as PDF"
        >
          <Printer size={15} />
          Print / Export PDF
        </button>
      </div>

      {/* ── Reviewer header ───────────────────────────────────────────── */}
      <div className="mb-6 pb-5 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-sky-100 dark:bg-sky-950 flex items-center justify-center">
            <BookOpen size={16} className="text-sky-600 dark:text-sky-400" />
          </div>
          <span className="text-xs font-medium text-sky-600 dark:text-sky-400 uppercase tracking-wider">
            {reviewer.subject}
          </span>
        </div>

        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-3 leading-tight">
          {reviewer.title}
        </h1>

        <div className="flex items-center gap-4 text-xs text-gray-400 dark:text-gray-500">
          <span className="flex items-center gap-1.5">
            <Calendar size={12} />
            {formatDate(reviewer.createdAt)}
          </span>
          <span className="flex items-center gap-1.5">
            <FileText size={12} />
            {words.toLocaleString()} words
          </span>
        </div>
      </div>

      {/* ── Reviewer body ─────────────────────────────────────────────── */}
      <ReviewerContent content={reviewer.content} />

      {/* ── Footer (hidden on print) ──────────────────────────────────── */}
      <div className="no-print mt-10 pt-6 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
        >
          <ArrowLeft size={16} />
          Back to Reviewers
        </button>
        <button
          onClick={handlePrint}
          className="flex items-center gap-1.5 text-sm text-indigo-600 dark:text-indigo-400 hover:underline"
        >
          <Printer size={14} />
          Print / Export
        </button>
      </div>
    </div>
  );
}
