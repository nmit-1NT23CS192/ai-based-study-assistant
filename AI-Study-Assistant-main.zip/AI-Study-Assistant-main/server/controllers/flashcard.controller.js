const prisma             = require('../utils/prismaClient');
const flashcardService   = require('../services/flashcard.service');

// ── Rate limit constants ───────────────────────────────────────────────────
const GENERATE_LIMIT = 10;        // generations per hour per user
const WINDOW_MS      = 60 * 60 * 1000;

async function getGenerationCount(userId) {
  return prisma.aiUsageLog.count({
    where: {
      userId,
      feature:   'flashcard',
      createdAt: { gte: new Date(Date.now() - WINDOW_MS) },
    },
  });
}

// ── generateFlashcards ─────────────────────────────────────────────────────
/**
 * POST /api/flashcards/generate
 * Returns AI-generated cards WITHOUT saving them to the DB.
 * The client previews them and calls /save only if satisfied.
 *
 * Separation of generate → save gives users a chance to edit or discard
 * poor-quality AI output before it becomes persistent data.
 */
async function generateFlashcards(req, res) {
  const userId = req.user.userId;
  let { topic, subject, count } = req.body;

  // ── Validation ─────────────────────────────────────────────────────────
  topic   = typeof topic   === 'string' ? topic.trim()   : '';
  subject = typeof subject === 'string' ? subject.trim() : '';
  count   = parseInt(count, 10);

  if (!topic)           return res.status(422).json({ error: 'Topic is required.' });
  if (topic.length > 150) return res.status(422).json({ error: 'Topic must be 150 characters or fewer.' });
  if (!subject)         return res.status(422).json({ error: 'Subject is required.' });
  if (!count || count < 5 || count > 20)
    return res.status(422).json({ error: 'Count must be between 5 and 20.' });

  try {
    // ── DB-backed rate limit ────────────────────────────────────────────
    const usageCount = await getGenerationCount(userId);
    if (usageCount >= GENERATE_LIMIT) {
      return res.status(429).json({
        error: `You have reached the ${GENERATE_LIMIT} flashcard generation/hour limit. Please wait and try again.`,
      });
    }

    const { cards, tokensUsed } = await flashcardService.generateFlashcardsWithAI(
      topic, subject, count,
    );

    // Log usage — counted whether or not the user saves the set
    await prisma.aiUsageLog.create({
      data: { userId, feature: 'flashcard', tokensUsed },
    });

    return res.status(200).json({ cards, topic, subject });

  } catch (err) {
    if (err.code === 'GEMINI_QUOTA' || err.status === 429) {
      return res.status(429).json({ error: err.message });
    }
    if (err.code === 'SAFETY_BLOCK') {
      return res.status(400).json({ error: 'This topic could not be processed due to content safety policies.' });
    }
    console.error('[flashcard.generate]', err);
    return res.status(500).json({ error: err.message || 'Failed to generate flashcards.' });
  }
}

// ── saveFlashcardSet ───────────────────────────────────────────────────────

async function saveFlashcardSet(req, res) {
  const userId = req.user.userId;
  let { title, subject, flashcards } = req.body;

  title   = typeof title   === 'string' ? title.trim()   : '';
  subject = typeof subject === 'string' ? subject.trim() : '';

  if (!title)                    return res.status(422).json({ error: 'Set title is required.' });
  if (title.length > 100)        return res.status(422).json({ error: 'Title must be 100 characters or fewer.' });
  if (!subject)                  return res.status(422).json({ error: 'Subject is required.' });
  if (!Array.isArray(flashcards) || flashcards.length < 1)
    return res.status(422).json({ error: 'At least one flashcard is required.' });
  if (flashcards.length > 50)    return res.status(422).json({ error: 'Maximum 50 flashcards per set.' });

  // Validate every card has non-empty question and answer
  const invalidCard = flashcards.find(c => !c?.question?.trim() || !c?.answer?.trim());
  if (invalidCard) {
    return res.status(422).json({ error: 'Every flashcard must have a question and an answer.' });
  }

  try {
    const set = await flashcardService.createFlashcardSet(userId, title, subject, flashcards);
    return res.status(201).json({ set });
  } catch (err) {
    console.error('[flashcard.save]', err);
    return res.status(500).json({ error: 'Failed to save flashcard set.' });
  }
}

// ── getMyFlashcardSets ─────────────────────────────────────────────────────

async function getMyFlashcardSets(req, res) {
  try {
    const sets = await flashcardService.getUserFlashcardSets(req.user.userId);
    return res.status(200).json({ sets });
  } catch (err) {
    console.error('[flashcard.getSets]', err);
    return res.status(500).json({ error: 'Failed to fetch flashcard sets.' });
  }
}

// ── getFlashcardSet ────────────────────────────────────────────────────────

async function getFlashcardSet(req, res) {
  try {
    const set = await flashcardService.getFlashcardSet(req.params.setId, req.user.userId);
    if (!set) return res.status(404).json({ error: 'Flashcard set not found.' });
    return res.status(200).json({ set });
  } catch (err) {
    console.error('[flashcard.getSet]', err);
    return res.status(500).json({ error: 'Failed to fetch flashcard set.' });
  }
}

// ── deleteFlashcardSet ─────────────────────────────────────────────────────

async function deleteFlashcardSet(req, res) {
  try {
    await flashcardService.deleteFlashcardSet(req.params.setId, req.user.userId);
    return res.status(200).json({ message: 'Flashcard set deleted.' });
  } catch (err) {
    if (err.message === 'SET_NOT_FOUND') return res.status(404).json({ error: 'Flashcard set not found.' });
    if (err.message === 'SET_NOT_OWNED') return res.status(404).json({ error: 'Flashcard set not found.' });
    console.error('[flashcard.deleteSet]', err);
    return res.status(500).json({ error: 'Failed to delete flashcard set.' });
  }
}

module.exports = {
  generateFlashcards,
  saveFlashcardSet,
  getMyFlashcardSets,
  getFlashcardSet,
  deleteFlashcardSet,
};
