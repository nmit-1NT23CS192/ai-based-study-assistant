import { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import ProtectedRoute  from './components/ProtectedRoute';
import AdminRoute      from './components/AdminRoute';
import DashboardLayout from './components/layout/DashboardLayout';
import LoadingSpinner  from './components/LoadingSpinner';
import ErrorBoundary   from './components/ErrorBoundary';

// ── Lazy-loaded pages ──────────────────────────────────────────────────────
// Code splitting: each page is only downloaded when the user navigates to it.
// The LandingPage is NOT lazy — it's the first paint for unauthenticated users.

import LandingPage from './pages/LandingPage';

const LoginPage         = lazy(() => import('./pages/LoginPage'));
const RegisterPage      = lazy(() => import('./pages/RegisterPage'));
const DashboardPage     = lazy(() => import('./pages/DashboardPage'));
const ChatPage          = lazy(() => import('./pages/ChatPage'));
const FlashcardsPage    = lazy(() => import('./pages/FlashcardsPage'));
const ReviewerPage      = lazy(() => import('./pages/ReviewerPage'));
const PDFSummarizerPage = lazy(() => import('./pages/PDFSummarizerPage'));
const CodeDebuggerPage  = lazy(() => import('./pages/CodeDebuggerPage'));
const NotesPage         = lazy(() => import('./pages/NotesPage'));
const AnalyticsPage     = lazy(() => import('./pages/AnalyticsPage'));
const BookmarksPage     = lazy(() => import('./pages/BookmarksPage'));
const AdminPage         = lazy(() => import('./pages/AdminPage'));
const PlaceholderPage   = lazy(() => import('./pages/PlaceholderPage'));

// ── Themed toast container ─────────────────────────────────────────────────
// Lives inside ThemeProvider so it can read the current theme.
// Toaster renders a portal — position in the tree doesn't matter visually.

function ThemedToaster() {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  return (
    <Toaster
      position="top-center"
      gutter={8}
      toastOptions={{
        duration: 4000,
        style: {
          background:   isDark ? '#1f2937' : '#ffffff',
          color:        isDark ? '#f9fafb' : '#111827',
          border:       `1px solid ${isDark ? '#374151' : '#e5e7eb'}`,
          borderRadius: '12px',
          fontSize:     '13.5px',
          padding:      '10px 14px',
          boxShadow:    isDark
            ? '0 4px 12px rgba(0,0,0,0.5)'
            : '0 4px 12px rgba(0,0,0,0.08)',
        },
        success: { iconTheme: { primary: '#10b981', secondary: 'white' } },
        error:   { iconTheme: { primary: '#ef4444', secondary: 'white' } },
      }}
    />
  );
}

// ── Page suspense wrapper ──────────────────────────────────────────────────
// Single Suspense boundary for all lazy pages — keeps the code DRY and
// ensures a consistent loading experience across all route transitions.

function PageSuspense({ children }) {
  return (
    <Suspense fallback={<LoadingSpinner fullScreen />}>
      <ErrorBoundary>
        {children}
      </ErrorBoundary>
    </Suspense>
  );
}

// ── App ────────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <Router>
      <ThemeProvider>
        <ThemedToaster />
        <AuthProvider>
          <Routes>
            {/* ── Public routes ─────────────────────────────────────── */}
            {/*
              "/" shows the marketing landing page to unauthenticated visitors.
              LandingPage redirects to /dashboard if the user is already logged in.
            */}
            <Route path="/"         element={<LandingPage />} />
            <Route path="/login"    element={<PageSuspense><LoginPage /></PageSuspense>} />
            <Route path="/register" element={<PageSuspense><RegisterPage /></PageSuspense>} />

            {/* ── Protected routes ──────────────────────────────────── */}
            <Route element={<ProtectedRoute />}>
              <Route element={<DashboardLayout />}>
                <Route path="/dashboard"  element={<PageSuspense><DashboardPage /></PageSuspense>} />
                <Route path="/chat"       element={<PageSuspense><ChatPage /></PageSuspense>} />
                <Route path="/flashcards" element={<PageSuspense><FlashcardsPage /></PageSuspense>} />
                <Route path="/reviewer"   element={<PageSuspense><ReviewerPage /></PageSuspense>} />
                <Route path="/summarizer" element={<PageSuspense><PDFSummarizerPage /></PageSuspense>} />
                <Route path="/debugger"   element={<PageSuspense><CodeDebuggerPage /></PageSuspense>} />
                <Route path="/notes"      element={<PageSuspense><NotesPage /></PageSuspense>} />
                <Route path="/analytics" element={<PageSuspense><AnalyticsPage /></PageSuspense>} />
                <Route path="/bookmarks"  element={<PageSuspense><BookmarksPage /></PageSuspense>} />
                <Route path="/settings"   element={<PageSuspense><PlaceholderPage title="Settings" /></PageSuspense>} />
                <Route
                  path="/admin"
                  element={
                    <AdminRoute>
                      <PageSuspense><AdminPage /></PageSuspense>
                    </AdminRoute>
                  }
                />
              </Route>
            </Route>

            {/* Catch-all */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AuthProvider>
      </ThemeProvider>
    </Router>
  );
}
