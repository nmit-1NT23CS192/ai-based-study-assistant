const { RateLimiterMemory } = require('rate-limiter-flexible');

// ── Limiter instances ──────────────────────────────────────────────────────
//
// RateLimiterMemory is used here for simplicity (free tier, single instance).
// If you scale to multiple Render instances, swap to RateLimiterRedis or
// RateLimiterPostgres so all instances share the same counter store.

// Auth: 10 attempts per 15 minutes, keyed by IP
const authLimiter = new RateLimiterMemory({
  points:   10,
  duration: 15 * 60, // seconds
});

// AI features: 30 requests per hour, keyed by userId
// Higher limit than auth — these are legitimate usage, not brute-force defense.
const aiLimiter = new RateLimiterMemory({
  points:   30,
  duration: 60 * 60,
});

// ── Middleware ─────────────────────────────────────────────────────────────

/**
 * Applied to POST /api/auth/register and POST /api/auth/login.
 * Keyed by IP — the user identity is unknown at this point.
 */
async function authRateLimiter(req, res, next) {
  try {
    await authLimiter.consume(req.ip);
    next();
  } catch {
    // RateLimiterMemory throws when points are exhausted — no useful error data needed
    return res.status(429).json({
      error: 'Too many requests. Please wait 15 minutes before trying again.',
    });
  }
}

/**
 * Applied to all /api/ai/* routes.
 * Keyed by userId (from req.user, populated by the protect middleware that runs first).
 * Keying by userId prevents the same user from bypassing the limit by switching IPs.
 */
async function aiRateLimiter(req, res, next) {
  const key = req.user?.userId || req.ip;

  try {
    const rateLimiterRes = await aiLimiter.consume(key);
    // Expose remaining quota so the frontend can show a usage indicator
    res.set('X-RateLimit-Remaining', String(rateLimiterRes.remainingPoints));
    next();
  } catch (rateLimiterRes) {
    const retryAfterSeconds = Math.ceil(rateLimiterRes.msBeforeNext / 1000);
    res.set('Retry-After', String(retryAfterSeconds));
    return res.status(429).json({
      error: 'AI request limit reached. Please try again later.',
      retryAfterSeconds,
    });
  }
}

module.exports = { authRateLimiter, aiRateLimiter };
