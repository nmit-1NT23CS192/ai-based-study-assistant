import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import Topbar from './Topbar';

export default function DashboardLayout({ children }) {
  const location = useLocation();

  // ── Mobile sidebar: shown/hidden via translate-x transform
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  // ── Desktop sidebar: collapsed (icons only) vs expanded (icons + labels)
  // Persisted so the user's preference survives page reloads.
  const [isCollapsed, setIsCollapsed] = useState(
    () => localStorage.getItem('sidebar-collapsed') === 'true',
  );

  function toggleCollapse() {
    setIsCollapsed((prev) => {
      const next = !prev;
      localStorage.setItem('sidebar-collapsed', String(next));
      return next;
    });
  }

  return (
    // h-screen + overflow-hidden on the root keeps the layout locked to the
    // viewport. Only the <main> area scrolls — sidebar and topbar stay fixed.
    <div className="flex h-screen overflow-hidden bg-gray-50 dark:bg-gray-950">
      <Sidebar
        isMobileOpen={isMobileOpen}
        isCollapsed={isCollapsed}
        onClose={() => setIsMobileOpen(false)}
        onToggleCollapse={toggleCollapse}
      />

      {/* Content column — min-w-0 prevents flex children from overflowing */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Topbar onMobileMenuToggle={() => setIsMobileOpen((v) => !v)} />

        {/*
          No padding here — each page controls its own scrolling and padding.
          overflow-hidden keeps the layout locked; pages that need to scroll
          wrap their content in their own overflow-y-auto container.
        */}
        {/*
          key={location.pathname} forces React to remount <main> on every
          route change, re-triggering the animate-page-in CSS animation.
        */}
        <main key={location.pathname} className="flex-1 overflow-hidden animate-page-in">
          {children ?? <Outlet />}
        </main>
      </div>
    </div>
  );
}
