import { useState } from 'react';
import { Bookmark, Loader2 } from 'lucide-react';
import bookmarksService from '../../services/bookmarks.service';
import { cn } from '../../utils/cn';

/**
 * Self-contained bookmark toggle.
 *
 * Props:
 *   referenceType  — 'flashcard_set' | 'reviewer' | 'note' | 'material'
 *   referenceId    — UUID of the item being bookmarked
 *   initialState   — { isBookmarked: bool, bookmarkId: string|null }
 *                    Pass from the parent if the bookmark state is known.
 *                    If omitted, starts as un-bookmarked until user interacts.
 *   size           — 'sm' (14px) | 'md' (18px)
 *   onToggle(isBookmarked, bookmarkId) — optional callback for parent sync
 */
export default function BookmarkButton({
  referenceType,
  referenceId,
  initialState,
  size = 'sm',
  className,
  onToggle,
}) {
  const [isBookmarked, setIsBookmarked] = useState(initialState?.isBookmarked ?? false);
  const [bookmarkId,   setBookmarkId]   = useState(initialState?.bookmarkId   ?? null);
  const [loading,      setLoading]      = useState(false);

  const iconSize = size === 'sm' ? 14 : 18;

  async function handleToggle(e) {
    e.stopPropagation(); // Don't trigger parent card clicks
    if (loading) return;
    setLoading(true);

    try {
      if (isBookmarked && bookmarkId) {
        await bookmarksService.remove(bookmarkId);
        setIsBookmarked(false);
        setBookmarkId(null);
        onToggle?.(false, null);
      } else {
        const bm = await bookmarksService.add(referenceType, referenceId);
        setIsBookmarked(true);
        setBookmarkId(bm.id);
        onToggle?.(true, bm.id);
      }
    } catch {
      // Silent failure — state reverts automatically since we haven't committed
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      onClick={handleToggle}
      disabled={loading}
      title={isBookmarked ? 'Remove bookmark' : 'Add bookmark'}
      aria-label={isBookmarked ? 'Remove bookmark' : 'Add bookmark'}
      aria-pressed={isBookmarked}
      className={cn(
        'p-1.5 rounded-lg transition-all',
        isBookmarked
          ? 'text-indigo-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40'
          : 'text-gray-400 hover:text-indigo-500 hover:bg-gray-100 dark:hover:bg-gray-800',
        'disabled:cursor-not-allowed',
        className,
      )}
    >
      {loading ? (
        <Loader2 size={iconSize} className="animate-spin" />
      ) : (
        <Bookmark
          size={iconSize}
          className={cn(
            'transition-all',
            // CSS fill overrides the SVG attribute — gives a "filled" appearance
            isBookmarked && 'fill-indigo-500',
          )}
        />
      )}
    </button>
  );
}
