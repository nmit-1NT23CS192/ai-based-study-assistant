const prisma = require('../utils/prismaClient');

// ── getDashboardStats ──────────────────────────────────────────────────────

async function getDashboardStats(req, res) {
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  try {
    const [totalUsers, totalAICalls, totalMaterials, activeToday] = await Promise.all([
      prisma.user.count(),
      prisma.aiUsageLog.count(),
      prisma.studyMaterial.count(),
      prisma.aiUsageLog.count({ where: { createdAt: { gte: todayStart } } }),
    ]);

    return res.status(200).json({ totalUsers, totalAICalls, totalMaterials, activeToday });
  } catch (err) {
    console.error('[admin.getDashboardStats]', err);
    return res.status(500).json({ error: 'Failed to fetch dashboard stats.' });
  }
}

// ── getAIUsageStats ────────────────────────────────────────────────────────
/**
 * Returns per-day, per-feature AI call counts for the last 30 days.
 *
 * Prisma's groupBy cannot truncate dates server-side, so we fetch the raw
 * log rows and aggregate in JavaScript. This is acceptable for a portfolio
 * — in production you'd use $queryRaw with DATE_TRUNC.
 */
async function getAIUsageStats(req, res) {
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  try {
    const logs = await prisma.aiUsageLog.findMany({
      where:   { createdAt: { gte: thirtyDaysAgo } },
      select:  { feature: true, tokensUsed: true, createdAt: true },
      orderBy: { createdAt: 'asc' },
    });

    // Aggregate: { 'YYYY-MM-DD__feature': { date, feature, count, tokens } }
    const map = {};
    for (const log of logs) {
      const date = log.createdAt.toISOString().split('T')[0];
      const key  = `${date}__${log.feature}`;
      if (!map[key]) map[key] = { date, feature: log.feature, count: 0, tokens: 0 };
      map[key].count++;
      map[key].tokens += log.tokensUsed;
    }

    const stats = Object.values(map).sort((a, b) => a.date.localeCompare(b.date));
    return res.status(200).json({ stats });
  } catch (err) {
    console.error('[admin.getAIUsageStats]', err);
    return res.status(500).json({ error: 'Failed to fetch AI usage stats.' });
  }
}

// ── getUsers ───────────────────────────────────────────────────────────────

async function getUsers(req, res) {
  const page   = Math.max(1, parseInt(req.query.page)  || 1);
  const limit  = Math.min(50, parseInt(req.query.limit) || 20);
  const search = String(req.query.search || '').trim();
  const skip   = (page - 1) * limit;

  const where = search
    ? {
        OR: [
          { name:  { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
        ],
      }
    : {};

  try {
    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        select: {
          id:        true,
          name:      true,
          email:     true,
          role:      true,
          isActive:  true,
          avatarUrl: true,
          createdAt: true,
          _count: {
            select: {
              aiUsageLogs:   true,
              chatSessions:  true,
              flashcardSets: true,
            },
          },
        },
      }),
      prisma.user.count({ where }),
    ]);

    return res.status(200).json({
      users,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (err) {
    console.error('[admin.getUsers]', err);
    return res.status(500).json({ error: 'Failed to fetch users.' });
  }
}

// ── toggleUserStatus ───────────────────────────────────────────────────────

async function toggleUserStatus(req, res) {
  const { userId } = req.params;
  const adminId    = req.user.userId;

  if (userId === adminId) {
    return res.status(400).json({ error: 'You cannot change your own account status.' });
  }

  try {
    const target = await prisma.user.findUnique({
      where:  { id: userId },
      select: { id: true, role: true, isActive: true, name: true },
    });

    if (!target) return res.status(404).json({ error: 'User not found.' });

    // Protect other admins from being banned
    if (target.role === 'ADMIN') {
      return res.status(403).json({ error: 'Cannot change the status of another admin.' });
    }

    const updated = await prisma.user.update({
      where:  { id: userId },
      data:   { isActive: !target.isActive },
      select: { id: true, isActive: true, name: true },
    });

    return res.status(200).json({ user: updated });
  } catch (err) {
    console.error('[admin.toggleUserStatus]', err);
    return res.status(500).json({ error: 'Failed to update user status.' });
  }
}

module.exports = { getDashboardStats, getAIUsageStats, getUsers, toggleUserStatus };
