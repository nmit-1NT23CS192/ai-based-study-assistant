import { useEffect, useState } from 'react';
import { Sparkles, BookOpen, Search } from 'lucide-react';
import reviewerService from '../services/reviewer.service';
import ReviewerGenerator from '../components/reviewer/ReviewerGenerator';
import ReviewerCard      from '../components/reviewer/ReviewerCard';
import ReviewerViewer    from '../components/reviewer/ReviewerViewer';
import LoadingSpinner    from '../components/LoadingSpinner';
import { cn } from '../utils/cn';

const TABS = [
  { id: 'generate', label: 'Generate',     icon: Sparkles  },
  { id: 'my',       label: 'My Reviewers', icon: BookOpen  },
];

export default function ReviewerPage() {
  const [tab,           setTab]           = useState('generate');
  const [reviewers,     setReviewers]     = useState([]);
  const [loadingList,   setLoadingList]   = useState(false);
  const [activeReviewer, setActiveReviewer] = useState(null); // full reviewer object
  const [loadingDetail,  setLoadingDetail]  = useState(false);
  const [search,        setSearch]        = useState('');

  // Fetch list when tab is opened
  useEffect(() => {
    if (tab === 'my') loadReviewers();
  }, [tab]);

  async function loadReviewers() {
    setLoadingList(true);
    try {
      const data = await reviewerService.getAll();
      setReviewers(data);
    } catch {
      // Silently fail
    } finally {
      setLoadingList(false);
    }
  }

  function handleSaved(newReviewer) {
    setReviewers(prev => [newReviewer, ...prev]);
    setTab('my');
  }

  async function handleView(reviewerId) {
    setLoadingDetail(true);
    setActiveReviewer(null);
    try {
      const reviewer = await reviewerService.getOne(reviewerId);
      setActiveReviewer(reviewer);
    } finally {
      setLoadingDetail(false);
    }
  }

  async function handleDelete(reviewerId) {
    await reviewerService.remove(reviewerId);
    setReviewers(prev => prev.filter(r => r.id !== reviewerId));
  }

  // Inline title rename (no backend PATCH route yet — optimistic update only)
  function handleRenameTitle(reviewerId, newTitle) {
    setReviewers(prev =>
      prev.map(r => r.id === reviewerId ? { ...r, title: newTitle } : r)
    );
  }

  // ── Filtered list ─────────────────────────────────────────────────────
  const q = search.trim().toLowerCase();
  const filtered = q
    ? reviewers.filter(r =>
        r.title.toLowerCase().includes(q) ||
        r.subject.toLowerCase().includes(q)
      )
    : reviewers;

  // ── If viewing a single reviewer ─────────────────────────────────────
  if (loadingDetail) {
    return (
      <div className="h-full overflow-y-auto flex items-center justify-center">
        <LoadingSpinner size={32} />
      </div>
    );
  }

  if (activeReviewer) {
    return (
      <div className="h-full overflow-y-auto p-4 sm:p-6">
        <ReviewerViewer
          reviewer={activeReviewer}
          onBack={() => setActiveReviewer(null)}
        />
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">

        {/* Page header */}
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <BookOpen size={22} className="text-sky-500" />
            Study Reviewers
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            AI-generated study reviewers from any topic or your own notes. Printable as PDF.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-gray-100 dark:bg-gray-800/60 rounded-xl w-fit">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={cn(
                'flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all',
                tab === id
                  ? 'bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200',
              )}
            >
              <Icon size={15} />
              {label}
              {id === 'my' && reviewers.length > 0 && (
                <span className="ml-0.5 text-xs bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400 px-1.5 py-0.5 rounded-full">
                  {reviewers.length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab content */}
        {tab === 'generate' && (
          <ReviewerGenerator onSaved={handleSaved} />
        )}

        {tab === 'my' && (
          <>
            {/* Search bar */}
            {reviewers.length > 2 && (
              <div className="relative">
                <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search by title or subject…"
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-sky-500 text-sm transition-shadow"
                />
              </div>
            )}

            {loadingList ? (
              <div className="flex items-center justify-center py-24">
                <LoadingSpinner size={28} />
              </div>
            ) : filtered.length === 0 ? (
              reviewers.length === 0 ? (
                <div className="text-center py-24">
                  <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mx-auto mb-4">
                    <BookOpen size={28} className="text-gray-400 dark:text-gray-500" />
                  </div>
                  <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-1">
                    No reviewers saved yet
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                    Generate your first reviewer using the Generator tab.
                  </p>
                  <button
                    onClick={() => setTab('generate')}
                    className="text-sm font-medium text-sky-600 dark:text-sky-400 hover:underline"
                  >
                    Go to Generator →
                  </button>
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    No reviewers match "<strong>{search}</strong>"
                  </p>
                </div>
              )
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filtered.map(reviewer => (
                  <ReviewerCard
                    key={reviewer.id}
                    reviewer={reviewer}
                    onView={handleView}
                    onDelete={handleDelete}
                    onRenameTitle={handleRenameTitle}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
