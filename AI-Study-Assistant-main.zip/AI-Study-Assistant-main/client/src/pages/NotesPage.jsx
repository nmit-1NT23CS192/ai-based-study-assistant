import { useCallback, useEffect, useRef, useState } from 'react';
import { Plus, Search, Trash2, StickyNote, FileText } from 'lucide-react';
import notesService from '../services/notes.service';
import NoteEditor   from '../components/notes/NoteEditor';
import LoadingSpinner from '../components/LoadingSpinner';
import { timeAgo }  from '../utils/formatDate';
import { cn }       from '../utils/cn';

const AUTOSAVE_DELAY = 2000; // ms

export default function NotesPage() {
  const [notes,        setNotes]        = useState([]);
  const [loadingList,  setLoadingList]  = useState(true);
  const [activeNote,   setActiveNote]   = useState(null); // { id, title, content }
  const [loadingNote,  setLoadingNote]  = useState(false);
  const [saveStatus,   setSaveStatus]   = useState('idle'); // 'idle'|'saving'|'saved'|'error'
  const [search,       setSearch]       = useState('');
  const [creating,     setCreating]     = useState(false);

  const saveTimer   = useRef(null);
  const savedTimer  = useRef(null);

  // ── Load note list ────────────────────────────────────────────────────
  useEffect(() => {
    notesService.getAll()
      .then(setNotes)
      .catch(() => {})
      .finally(() => setLoadingList(false));
  }, []);

  // ── Debounced auto-save ───────────────────────────────────────────────
  const scheduleAutoSave = useCallback((noteData) => {
    clearTimeout(saveTimer.current);
    clearTimeout(savedTimer.current);
    setSaveStatus('saving');

    saveTimer.current = setTimeout(async () => {
      try {
        const saved = await notesService.update(noteData.id, {
          title:   noteData.title,
          content: noteData.content,
        });
        setSaveStatus('saved');
        // Update the note in the sidebar list
        setNotes(prev => prev.map(n =>
          n.id === saved.id ? { ...n, title: saved.title, updatedAt: saved.updatedAt } : n
        ));
        // Auto-hide "Saved" indicator after 3 s
        savedTimer.current = setTimeout(() => setSaveStatus('idle'), 3000);
      } catch {
        setSaveStatus('error');
      }
    }, AUTOSAVE_DELAY);
  }, []);

  // Flush any pending save when navigating away from the page
  useEffect(() => () => {
    clearTimeout(saveTimer.current);
    clearTimeout(savedTimer.current);
  }, []);

  // ── Open a note ───────────────────────────────────────────────────────
  async function openNote(noteId) {
    if (noteId === activeNote?.id) return;

    // Cancel pending auto-save timer for the previous note
    clearTimeout(saveTimer.current);

    setLoadingNote(true);
    setSaveStatus('idle');
    try {
      const note = await notesService.getOne(noteId);
      setActiveNote(note);
    } catch {
      // silently fail — keep previous note open
    } finally {
      setLoadingNote(false);
    }
  }

  // ── Create new note ───────────────────────────────────────────────────
  // Creates immediately in DB — subsequent edits are updates, no create-vs-update ambiguity.
  async function handleNewNote() {
    setCreating(true);
    try {
      const note = await notesService.create({ title: 'Untitled Note', content: '' });
      setNotes(prev => [note, ...prev]);
      setActiveNote(note);
      setSaveStatus('idle');
    } finally {
      setCreating(false);
    }
  }

  // ── Delete note ───────────────────────────────────────────────────────
  async function handleDelete(noteId) {
    await notesService.remove(noteId);
    setNotes(prev => prev.filter(n => n.id !== noteId));
    if (activeNote?.id === noteId) setActiveNote(null);
  }

  // ── Editor callbacks ──────────────────────────────────────────────────
  function handleTitleChange(val) {
    const updated = { ...activeNote, title: val };
    setActiveNote(updated);
    scheduleAutoSave(updated);
  }

  function handleContentChange(val) {
    const updated = { ...activeNote, content: val };
    setActiveNote(updated);
    scheduleAutoSave(updated);
  }

  // ── Filtered list ─────────────────────────────────────────────────────
  const q = search.trim().toLowerCase();
  const filtered = q
    ? notes.filter(n => n.title.toLowerCase().includes(q))
    : notes;

  return (
    <div className="flex h-full overflow-hidden">

      {/* ── Left panel: Note list ──────────────────────────────────── */}
      <div className="flex flex-col w-64 xl:w-72 shrink-0 border-r border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900">

        {/* Header */}
        <div className="p-3 border-b border-gray-200 dark:border-gray-800 space-y-2 shrink-0">
          <button
            onClick={handleNewNote}
            disabled={creating}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium transition-colors disabled:opacity-60"
          >
            <Plus size={15} />
            {creating ? 'Creating…' : 'New Note'}
          </button>

          {/* Search */}
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search notes…"
              className="w-full pl-7 pr-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-2">
          {loadingList ? (
            <div className="flex items-center justify-center py-10">
              <LoadingSpinner size={20} />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-10 px-4">
              <StickyNote size={24} className="mx-auto text-gray-300 dark:text-gray-600 mb-2" />
              <p className="text-xs text-gray-400 dark:text-gray-500">
                {search ? 'No notes match your search.' : 'No notes yet. Create one above.'}
              </p>
            </div>
          ) : (
            <ul className="space-y-0.5">
              {filtered.map(note => (
                <li key={note.id}>
                  <button
                    onClick={() => openNote(note.id)}
                    className={cn(
                      'w-full text-left px-3 py-2.5 rounded-lg group flex items-start gap-2 transition-colors',
                      activeNote?.id === note.id
                        ? 'bg-indigo-50 dark:bg-indigo-950/50'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-800',
                    )}
                  >
                    <FileText
                      size={13}
                      className={cn(
                        'mt-0.5 shrink-0',
                        activeNote?.id === note.id
                          ? 'text-indigo-500'
                          : 'text-gray-400',
                      )}
                    />
                    <div className="flex-1 min-w-0">
                      <p className={cn(
                        'text-xs font-medium truncate',
                        activeNote?.id === note.id
                          ? 'text-indigo-700 dark:text-indigo-300'
                          : 'text-gray-800 dark:text-gray-200',
                      )}>
                        {note.title || 'Untitled Note'}
                      </p>
                      <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                        {timeAgo(note.updatedAt)}
                      </p>
                    </div>
                    {/* Delete — only on hover, not the active note (to avoid mis-click) */}
                    <button
                      onClick={e => { e.stopPropagation(); handleDelete(note.id); }}
                      className="opacity-0 group-hover:opacity-100 p-1 rounded text-gray-400 hover:text-red-500 transition-all"
                      aria-label="Delete note"
                    >
                      <Trash2 size={12} />
                    </button>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* ── Right panel: Editor ────────────────────────────────────── */}
      <div className="flex-1 min-w-0 overflow-hidden">
        {loadingNote ? (
          <div className="flex items-center justify-center h-full">
            <LoadingSpinner size={28} />
          </div>
        ) : activeNote ? (
          <NoteEditor
            title={activeNote.title}
            content={activeNote.content}
            onTitleChange={handleTitleChange}
            onContentChange={handleContentChange}
            saveStatus={saveStatus}
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mb-4">
              <StickyNote size={28} className="text-gray-300 dark:text-gray-600" />
            </div>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
              No note selected
            </p>
            <p className="text-xs text-gray-400 dark:text-gray-500">
              Select a note from the list or create a new one.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
