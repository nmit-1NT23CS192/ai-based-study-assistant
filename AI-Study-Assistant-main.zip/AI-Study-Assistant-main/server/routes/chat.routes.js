const { Router } = require('express');
const {
  sendMessage,
  getSessions,
  getSessionMessages,
  deleteSession,
} = require('../controllers/chat.controller');
const { protect }        = require('../middleware/auth.middleware');
const { aiRateLimiter }  = require('../middleware/rateLimiter.middleware');

const router = Router();

// All chat routes require a valid JWT
router.use(protect);

// POST /api/chat/send
// Memory-based first-pass limiter (30 req/hr, fast) → controller adds DB-backed
// chat-specific limiter (20 msg/hr, precise and persistent across restarts).
router.post('/send', aiRateLimiter, sendMessage);

// GET /api/chat/sessions
router.get('/sessions', getSessions);

// GET /api/chat/sessions/:sessionId/messages
router.get('/sessions/:sessionId/messages', getSessionMessages);

// DELETE /api/chat/sessions/:sessionId
router.delete('/sessions/:sessionId', deleteSession);

module.exports = router;
