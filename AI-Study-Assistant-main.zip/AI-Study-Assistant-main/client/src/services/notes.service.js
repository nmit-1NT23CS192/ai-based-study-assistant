import api from './api';

const notesService = {
  async getAll() {
    const res = await api.get('/notes');
    return res.data.notes; // [{ id, title, updatedAt, createdAt }] — no content
  },

  async getOne(id) {
    const res = await api.get(`/notes/${id}`);
    return res.data.note; // full note with content
  },

  async create(data = {}) {
    const res = await api.post('/notes', data);
    return res.data.note;
  },

  async update(id, data) {
    const res = await api.patch(`/notes/${id}`, data);
    return res.data.note;
  },

  async remove(id) {
    await api.delete(`/notes/${id}`);
  },
};

export default notesService;
