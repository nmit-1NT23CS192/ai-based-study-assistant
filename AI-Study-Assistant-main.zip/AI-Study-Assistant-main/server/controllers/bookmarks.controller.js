const prisma = require('../utils/prismaClient');

const VALID_TYPES = ['flashcard_set', 'reviewer', 'note', 'material'];

// ── addBookmark ─────────────────────────────────────────────────────────────
// Upserts using the @@unique([userId, referenceType, referenceId]) constraint.
// Bookmarking an already-bookmarked item is idempotent — returns 200 not 409.

async function addBookmark(req, res) {
  const userId = req.user.userId;
  const { referenceType, referenceId } = req.body;

  if (!VALID_TYPES.includes(referenceType)) {
    return res.status(422).json({ error: `referenceType must be one of: ${VALID_TYPES.join(', ')}` });
  }
  if (!referenceId) {
    return res.status(422).json({ error: 'referenceId is required.' });
  }

  try {
    const bookmark = await prisma.bookmark.upsert({
      where: {
        userId_referenceType_referenceId: { userId, referenceType, referenceId },
      },
      create: { userId, referenceType, referenceId },
      update: {},
    });
    return res.status(200).json({ bookmark });
  } catch (err) {
    console.error('[bookmarks.add]', err);
    return res.status(500).json({ error: 'Failed to add bookmark.' });
  }
}

// ── getUserBookmarks ────────────────────────────────────────────────────────
// Fetches all bookmarks with their referenced item data.
//
// Because the reference is polymorphic (4 different tables), this requires:
//   1. Fetch all bookmark rows for the user
//   2. Group by referenceType
//   3. Batch-fetch each group's items
//   4. Merge item data back onto each bookmark
//
// Items that no longer exist (deleted after bookmarking) are filtered out.

async function getUserBookmarks(req, res) {
  const userId = req.user.userId;

  try {
    const bookmarks = await prisma.bookmark.findMany({
      where:   { userId },
      orderBy: { createdAt: 'desc' },
    });

    if (bookmarks.length === 0) return res.status(200).json({ bookmarks: [] });

    // Group reference IDs by type
    const ids = {
      flashcard_set: [],
      reviewer:      [],
      note:          [],
      material:      [],
    };
    for (const bm of bookmarks) {
      ids[bm.referenceType]?.push(bm.referenceId);
    }

    // Batch-fetch each type in parallel — only query types that have bookmarks
    const [flashcardSets, reviewers, notes, materials] = await Promise.all([
      ids.flashcard_set.length
        ? prisma.flashcardSet.findMany({
            where:   { id: { in: ids.flashcard_set } },
            select:  { id: true, title: true, subject: true, updatedAt: true, _count: { select: { flashcards: true } } },
          })
        : [],
      ids.reviewer.length
        ? prisma.reviewer.findMany({
            where:  { id: { in: ids.reviewer } },
            select: { id: true, title: true, subject: true, updatedAt: true },
          })
        : [],
      ids.note.length
        ? prisma.note.findMany({
            where:  { id: { in: ids.note } },
            select: { id: true, title: true, updatedAt: true },
          })
        : [],
      ids.material.length
        ? prisma.studyMaterial.findMany({
            where:  { id: { in: ids.material } },
            select: { id: true, title: true, fileType: true, fileSize: true, createdAt: true },
          })
        : [],
    ]);

    // Build O(1) lookup maps
    const itemMap = {
      flashcard_set: Object.fromEntries(flashcardSets.map(x => [x.id, x])),
      reviewer:      Object.fromEntries(reviewers.map(x => [x.id, x])),
      note:          Object.fromEntries(notes.map(x => [x.id, x])),
      material:      Object.fromEntries(materials.map(x => [x.id, x])),
    };

    // Enrich and filter out orphaned bookmarks (item was deleted)
    const enriched = bookmarks
      .map(bm => ({ ...bm, item: itemMap[bm.referenceType]?.[bm.referenceId] ?? null }))
      .filter(bm => bm.item !== null);

    return res.status(200).json({ bookmarks: enriched });
  } catch (err) {
    console.error('[bookmarks.getAll]', err);
    return res.status(500).json({ error: 'Failed to fetch bookmarks.' });
  }
}

// ── removeBookmark ──────────────────────────────────────────────────────────

async function removeBookmark(req, res) {
  const userId = req.user.userId;
  const { id } = req.params;

  try {
    const bookmark = await prisma.bookmark.findUnique({ where: { id } });
    if (!bookmark || bookmark.userId !== userId) {
      return res.status(404).json({ error: 'Bookmark not found.' });
    }
    await prisma.bookmark.delete({ where: { id } });
    return res.status(200).json({ message: 'Bookmark removed.' });
  } catch (err) {
    console.error('[bookmarks.remove]', err);
    return res.status(500).json({ error: 'Failed to remove bookmark.' });
  }
}

module.exports = { addBookmark, getUserBookmarks, removeBookmark };
