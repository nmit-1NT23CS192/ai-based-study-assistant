import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  withCredentials: true,
});

// Attach the stored JWT to every outgoing request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle 401 responses globally.
// We dispatch a custom event instead of calling window.location.href so that:
//  1. AuthContext can clear React state cleanly (triggers ProtectedRoute redirect)
//  2. We avoid a circular import (api.js ← AuthContext ← api.js)
//  3. Mid-session expiry (user is on /dashboard) is handled without a full page reload
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.dispatchEvent(new CustomEvent('auth:unauthorized'));
    }
    return Promise.reject(error);
  }
);

export default api;
