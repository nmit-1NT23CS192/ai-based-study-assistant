import { useState } from 'react';
import { FileText, Image, Trash2, Sparkles, Calendar, HardDrive, BookOpen, Loader2, AlertCircle } from 'lucide-react';
import { formatDate } from '../../utils/formatDate';
import { cn } from '../../utils/cn';

const SUMMARY_TYPES = [
  { value: 'brief',       label: 'Brief Summary'  },
  { value: 'detailed',    label: 'Detailed'       },
  { value: 'key_points',  label: 'Key Points'     },
  { value: 'study_guide', label: 'Study Guide'    },
];

function formatBytes(bytes) {
  if (!bytes) return '—';
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

function FileIcon({ fileType }) {
  const isPDF = fileType === 'application/pdf';
  return (
    <div className={cn(
      'w-10 h-10 rounded-xl flex items-center justify-center',
      isPDF
        ? 'bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400'
        : 'bg-sky-100  dark:bg-sky-950  text-sky-600  dark:text-sky-400',
    )}>
      {isPDF ? <FileText size={20} /> : <Image size={20} />}
    </div>
  );
}

export default function MaterialCard({ material, onSummarize, onDelete }) {
  const [summaryType,  setSummaryType]  = useState('brief');
  const [summarizing,  setSummarizing]  = useState(false);
  const [confirming,   setConfirming]   = useState(false);
  const [deleting,     setDeleting]     = useState(false);
  const [error,        setError]        = useState('');

  const canSummarize = Boolean(material.extractedText !== false && material.fileType === 'application/pdf');

  async function handleSummarize() {
    setSummarizing(true);
    setError('');
    try {
      await onSummarize(material.id, summaryType);
    } catch (err) {
      setError(
        err.response?.data?.error || 'Failed to generate summary. Please try again.',
      );
    } finally {
      setSummarizing(false);
    }
  }

  async function handleDelete() {
    setDeleting(true);
    try   { await onDelete(material.id); }
    finally { setDeleting(false); setConfirming(false); }
  }

  const fileTypeLabel = material.fileType === 'application/pdf' ? 'PDF' : 'Image';

  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5 flex flex-col gap-4 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-md transition-all">

      {/* Header */}
      <div className="flex items-start gap-3">
        <FileIcon fileType={material.fileType} />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-gray-900 dark:text-white line-clamp-2 leading-snug">
            {material.title}
          </p>
          <span className="inline-block mt-1 text-xs px-2 py-0.5 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400">
            {fileTypeLabel}
          </span>
        </div>
      </div>

      {/* Meta */}
      <div className="grid grid-cols-2 gap-2 text-xs text-gray-400 dark:text-gray-500">
        <span className="flex items-center gap-1.5">
          <Calendar size={11} />
          {formatDate(material.createdAt)}
        </span>
        <span className="flex items-center gap-1.5">
          <HardDrive size={11} />
          {formatBytes(material.fileSize)}
        </span>
        {material.pageCount && (
          <span className="flex items-center gap-1.5">
            <BookOpen size={11} />
            {material.pageCount} {material.pageCount === 1 ? 'page' : 'pages'}
          </span>
        )}
      </div>

      {/* Error */}
      {error && (
        <div className="flex items-start gap-1.5 text-xs text-red-600 dark:text-red-400">
          <AlertCircle size={12} className="shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Actions */}
      {confirming ? (
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500 dark:text-gray-400">Delete this file?</span>
          <div className="flex gap-2">
            <button onClick={() => setConfirming(false)} className="text-xs px-2.5 py-1 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
              Cancel
            </button>
            <button onClick={handleDelete} disabled={deleting} className="text-xs px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white disabled:opacity-50 transition-colors">
              {deleting ? 'Deleting…' : 'Delete'}
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-2">
          {/* Summarize row */}
          <div className="flex gap-2">
            <select
              value={summaryType}
              onChange={e => setSummaryType(e.target.value)}
              disabled={summarizing || !canSummarize}
              className="flex-1 text-xs px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-50"
            >
              {SUMMARY_TYPES.map(t => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>

            <button
              onClick={handleSummarize}
              disabled={summarizing || !canSummarize}
              title={!canSummarize ? 'Text could not be extracted from this file' : undefined}
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors',
                summarizing || !canSummarize
                  ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white cursor-pointer',
              )}
            >
              {summarizing
                ? <><Loader2 size={12} className="animate-spin" /> Generating…</>
                : <><Sparkles size={12} /> Summarize</>
              }
            </button>
          </div>

          {/* Delete */}
          <button
            onClick={() => setConfirming(true)}
            className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-xs text-gray-500 dark:text-gray-400 hover:text-red-500 hover:border-red-300 dark:hover:border-red-800 hover:bg-red-50 dark:hover:bg-red-950/40 transition-all"
          >
            <Trash2 size={12} />
            Delete file
          </button>
        </div>
      )}
    </div>
  );
}
