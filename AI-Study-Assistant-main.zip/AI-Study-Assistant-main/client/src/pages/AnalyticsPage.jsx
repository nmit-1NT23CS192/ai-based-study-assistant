import { useEffect, useState } from 'react';
import {
  BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  TrendingUp, Layers, BookOpen, StickyNote, FileText,
  MessageSquare, Zap, Calendar, Star, Brain,
} from 'lucide-react';
import analyticsService from '../services/analytics.service';
import LoadingSpinner   from '../components/LoadingSpinner';
import { useTheme }     from '../context/ThemeContext';

// ── Feature config ─────────────────────────────────────────────────────────

const FEATURES = [
  { key: 'chat',       label: 'Chat',       color: '#6366f1' },
  { key: 'flashcard',  label: 'Flashcards', color: '#8b5cf6' },
  { key: 'reviewer',   label: 'Reviewer',   color: '#0ea5e9' },
  { key: 'summarizer', label: 'PDF',        color: '#ef4444' },
  { key: 'debugger',   label: 'Debugger',   color: '#f59e0b' },
];

const FEATURE_LABEL = Object.fromEntries(FEATURES.map(f => [f.key, f.label]));

// ── Content stat cards config ──────────────────────────────────────────────

const CONTENT_STATS = [
  { key: 'chatSessions',  label: 'Chat Sessions',   icon: MessageSquare, color: 'text-indigo-500', bg: 'bg-indigo-100 dark:bg-indigo-950' },
  { key: 'flashcardSets', label: 'Flashcard Sets',  icon: Layers,        color: 'text-violet-500', bg: 'bg-violet-100 dark:bg-violet-950' },
  { key: 'reviewers',     label: 'Reviewers',       icon: BookOpen,      color: 'text-sky-500',    bg: 'bg-sky-100    dark:bg-sky-950'    },
  { key: 'notes',         label: 'Notes',           icon: StickyNote,    color: 'text-amber-500',  bg: 'bg-amber-100  dark:bg-amber-950'  },
  { key: 'materials',     label: 'PDF Materials',   icon: FileText,      color: 'text-red-500',    bg: 'bg-red-100    dark:bg-red-950'    },
];

// ── Helpers ────────────────────────────────────────────────────────────────

function formatDate(iso) {
  return new Date(iso + 'T12:00:00').toLocaleDateString('en-US', {
    month: 'short', day: 'numeric',
  });
}

// ── Custom Pie tooltip ─────────────────────────────────────────────────────

function PieTooltip({ active, payload }) {
  if (!active || !payload?.length) return null;
  const { name, value } = payload[0];
  return (
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 py-2 shadow-lg text-xs">
      <p className="font-semibold text-gray-700 dark:text-gray-200">{FEATURE_LABEL[name] ?? name}</p>
      <p className="text-gray-500 dark:text-gray-400">{value} AI calls</p>
    </div>
  );
}

// ── Custom Bar tooltip ─────────────────────────────────────────────────────

function BarTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  const total = payload.reduce((s, p) => s + (p.value ?? 0), 0);
  return (
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-3 shadow-lg text-xs min-w-[130px]">
      <p className="font-semibold text-gray-700 dark:text-gray-200 mb-2">{label}</p>
      {payload.filter(p => p.value > 0).map(p => (
        <div key={p.dataKey} className="flex items-center justify-between gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full" style={{ background: p.fill }} />
            <span className="text-gray-500 dark:text-gray-400">{p.name}</span>
          </span>
          <span className="font-medium text-gray-800 dark:text-gray-100">{p.value}</span>
        </div>
      ))}
      {total > 0 && (
        <div className="mt-1.5 pt-1.5 border-t border-gray-100 dark:border-gray-700 flex justify-between font-semibold text-gray-700 dark:text-gray-200">
          <span>Total</span><span>{total}</span>
        </div>
      )}
    </div>
  );
}

// ── EmptyChart ─────────────────────────────────────────────────────────────

function EmptyChart({ message }) {
  return (
    <div className="flex flex-col items-center justify-center h-48 gap-2">
      <Brain size={28} className="text-gray-300 dark:text-gray-600" />
      <p className="text-sm text-gray-400 dark:text-gray-500">{message}</p>
    </div>
  );
}

// ── StatCard ────────────────────────────────────────────────────────────────

function StatCard({ label, value, icon: Icon, color, bg }) {
  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${bg}`}>
        <Icon size={20} className={color} />
      </div>
      <p className="text-2xl font-bold text-gray-900 dark:text-white tabular-nums">
        {value ?? 0}
      </p>
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{label}</p>
    </div>
  );
}

// ── AnalyticsPage ──────────────────────────────────────────────────────────

export default function AnalyticsPage() {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState('');
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const axisColor = isDark ? '#6b7280' : '#9ca3af';
  const gridColor = isDark ? '#1f2937' : '#f3f4f6';

  useEffect(() => {
    analyticsService.getMyAnalytics()
      .then(setData)
      .catch(() => setError('Failed to load analytics. Please try again.'))
      .finally(() => setLoading(false));
  }, []);

  // ── Build pie data from feature breakdown ──────────────────────────────
  const pieData = data
    ? FEATURES
        .map(f => ({ ...f, value: data.featureBreakdown[f.key] ?? 0 }))
        .filter(f => f.value > 0)
    : [];

  const hasWeeklyData  = data?.weeklyChart?.some(d => FEATURES.some(f => d[f.key] > 0));
  const hasPieData     = pieData.length > 0;
  const hasAnyActivity = data?.monthlyTotal > 0;

  // ── Loading ────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="h-full overflow-y-auto flex items-center justify-center">
        <LoadingSpinner size={32} />
      </div>
    );
  }

  // ── Error ──────────────────────────────────────────────────────────────
  if (error) {
    return (
      <div className="h-full overflow-y-auto flex items-center justify-center p-8 text-center">
        <p className="text-sm text-red-500">{error}</p>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">

        {/* ── Header ────────────────────────────────────────────────── */}
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <TrendingUp size={22} className="text-indigo-500" />
            Study Analytics
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Your personal study activity over the last 30 days.
          </p>
        </div>

        {/* ── Summary highlights ─────────────────────────────────────── */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {/* AI calls this week */}
          <div className="col-span-1 bg-indigo-600 rounded-2xl p-5 text-white">
            <div className="flex items-center gap-2 mb-2">
              <Zap size={16} className="text-indigo-200" />
              <span className="text-xs font-medium text-indigo-200">This Week</span>
            </div>
            <p className="text-3xl font-bold tabular-nums">{data?.weeklyTotal ?? 0}</p>
            <p className="text-xs text-indigo-200 mt-0.5">AI calls</p>
          </div>

          {/* Most active day */}
          {data?.mostActiveDay ? (
            <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <Star size={15} className="text-amber-500" />
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Best Day</span>
              </div>
              <p className="text-base font-bold text-gray-900 dark:text-white">
                {data.mostActiveDay.dayName}
              </p>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                {formatDate(data.mostActiveDay.date)} · {data.mostActiveDay.count} calls
              </p>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <Star size={15} className="text-amber-500" />
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Best Day</span>
              </div>
              <p className="text-sm text-gray-400 dark:text-gray-500">No activity yet</p>
            </div>
          )}

          {/* Top feature */}
          {data?.topFeature ? (
            <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <Brain size={15} className="text-violet-500" />
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Most Used</span>
              </div>
              <p className="text-base font-bold text-gray-900 dark:text-white capitalize">
                {FEATURE_LABEL[data.topFeature.key] ?? data.topFeature.key}
              </p>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                {data.topFeature.count} calls this month
              </p>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <Brain size={15} className="text-violet-500" />
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Most Used</span>
              </div>
              <p className="text-sm text-gray-400 dark:text-gray-500">No activity yet</p>
            </div>
          )}

          {/* Monthly total */}
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <Calendar size={15} className="text-sky-500" />
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400">This Month</span>
            </div>
            <p className="text-3xl font-bold text-gray-900 dark:text-white tabular-nums">
              {data?.monthlyTotal ?? 0}
            </p>
            <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">AI calls</p>
          </div>
        </div>

        {/* ── Charts row ────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* Bar chart — 7-day activity (2/3 width) */}
          <div className="lg:col-span-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
            <h2 className="text-sm font-semibold text-gray-800 dark:text-gray-100 mb-4">
              AI Activity — Last 7 Days
            </h2>
            {hasWeeklyData ? (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart
                  data={data.weeklyChart}
                  margin={{ top: 0, right: 8, left: -20, bottom: 0 }}
                  barSize={8}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={gridColor} />
                  <XAxis
                    dataKey="day"
                    tick={{ fontSize: 11, fill: axisColor }}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: axisColor }}
                    tickLine={false}
                    axisLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip
                    content={<BarTooltip />}
                    cursor={{ fill: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)' }}
                  />
                  <Legend
                    iconType="circle"
                    iconSize={8}
                    wrapperStyle={{ fontSize: '11px', paddingTop: '12px' }}
                  />
                  {FEATURES.map(({ key, label, color }, i) => (
                    <Bar
                      key={key}
                      dataKey={key}
                      name={label}
                      stackId="a"
                      fill={color}
                      radius={i === FEATURES.length - 1 ? [3, 3, 0, 0] : [0, 0, 0, 0]}
                    />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart message="No AI activity in the last 7 days. Start using the app to see your stats!" />
            )}
          </div>

          {/* Pie chart — feature breakdown (1/3 width) */}
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5">
            <h2 className="text-sm font-semibold text-gray-800 dark:text-gray-100 mb-4">
              Feature Breakdown
              <span className="ml-1.5 text-xs font-normal text-gray-400">(30 days)</span>
            </h2>
            {hasPieData ? (
              <>
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={75}
                      paddingAngle={3}
                      dataKey="value"
                      nameKey="key"
                    >
                      {pieData.map(({ key, color }) => (
                        <Cell key={key} fill={color} />
                      ))}
                    </Pie>
                    <Tooltip content={<PieTooltip />} />
                  </PieChart>
                </ResponsiveContainer>

                {/* Legend below */}
                <div className="mt-3 space-y-1.5">
                  {pieData.map(({ key, label, color, value }) => {
                    const total = pieData.reduce((s, d) => s + d.value, 0);
                    const pct   = total > 0 ? Math.round((value / total) * 100) : 0;
                    return (
                      <div key={key} className="flex items-center justify-between text-xs">
                        <span className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full" style={{ background: color }} />
                          <span className="text-gray-600 dark:text-gray-400">{label}</span>
                        </span>
                        <span className="font-medium text-gray-700 dark:text-gray-300">
                          {value} <span className="text-gray-400">({pct}%)</span>
                        </span>
                      </div>
                    );
                  })}
                </div>
              </>
            ) : (
              <EmptyChart message="Use AI features to see your usage breakdown." />
            )}
          </div>
        </div>

        {/* ── Content created stats ──────────────────────────────────── */}
        <div>
          <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
            Items Created
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {CONTENT_STATS.map(({ key, label, icon, color, bg }) => (
              <StatCard
                key={key}
                label={label}
                value={data?.contentCounts?.[key] ?? 0}
                icon={icon}
                color={color}
                bg={bg}
              />
            ))}
          </div>
        </div>

        {/* ── No activity hint ───────────────────────────────────────── */}
        {!hasAnyActivity && (
          <div className="bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/50 rounded-2xl px-6 py-5">
            <p className="text-sm font-medium text-indigo-700 dark:text-indigo-300 mb-1">
              Your analytics will appear here once you start studying.
            </p>
            <p className="text-xs text-indigo-600/70 dark:text-indigo-400/70">
              Try the AI Chat, generate some Flashcards, or upload a PDF to get started.
            </p>
          </div>
        )}

      </div>
    </div>
  );
}
