import { useState, useEffect } from 'react';
import chatService from '../services/chat.service';

/**
 * Manages all chat state: sessions list, active session, messages, and loading flags.
 *
 * Optimistic updates keep the UI instant:
 *   1. User message is appended to the list immediately (before the API call)
 *   2. A typing indicator replaces nothing — it appears alongside the user message
 *   3. On success, the typing indicator is swapped for the real AI message
 *   4. On failure, both the optimistic user message and typing indicator are removed
 */
export default function useChat() {
  const [sessions, setSessions] = useState([]);
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);

  // Load session list on mount
  useEffect(() => {
    loadSessions();
  }, []);

  // ── Sessions ────────────────────────────────────────────────────────────

  async function loadSessions() {
    try {
      const data = await chatService.getSessions();
      setSessions(data);
    } catch {
      // Non-fatal — user can still chat even if session list fails
    }
  }

  async function openSession(sessionId) {
    if (activeSessionId === sessionId) return;
    setActiveSessionId(sessionId);
    setMessages([]);
    setError(null);
    setLoadingMessages(true);
    try {
      const data = await chatService.getSessionMessages(sessionId);
      setMessages(data);
    } catch {
      setError('Failed to load messages. Please try again.');
    } finally {
      setLoadingMessages(false);
    }
  }

  function startNewChat() {
    setActiveSessionId(null);
    setMessages([]);
    setError(null);
  }

  // ── Send message ────────────────────────────────────────────────────────

  async function sendMessage(text) {
    const trimmed = text.trim();
    if (!trimmed || sending) return;

    // ── Optimistic UI ─────────────────────────────────────────────────────
    // Append user message immediately so there is zero perceived latency.
    const tempId   = `temp-${Date.now()}`;
    const TYPING   = 'typing-indicator';

    setMessages(prev => [
      ...prev,
      { id: tempId, role: 'USER',      content: trimmed, createdAt: new Date().toISOString(), isOptimistic: true },
      { id: TYPING, role: 'ASSISTANT', content: '',       createdAt: new Date().toISOString(), isTyping: true     },
    ]);

    setSending(true);
    setError(null);

    try {
      const data = await chatService.sendMessage(trimmed, activeSessionId);
      const { sessionId: returnedId, message: aiMessage } = data;

      // Replace typing indicator with the real AI response
      setMessages(prev => [
        ...prev
          .filter(m => m.id !== TYPING)
          .map(m => m.id === tempId ? { ...m, isOptimistic: false } : m),
        aiMessage,
      ]);

      if (!activeSessionId) {
        // New session — set it active and refresh the session list
        setActiveSessionId(returnedId);
        await loadSessions();
      } else {
        // Existing session — bump it to the top of the sidebar list
        setSessions(prev => {
          const found = prev.find(s => s.id === returnedId);
          if (!found) return prev;
          return [
            { ...found, updatedAt: new Date().toISOString() },
            ...prev.filter(s => s.id !== returnedId),
          ];
        });
      }
    } catch (err) {
      // Roll back optimistic messages on failure
      setMessages(prev => prev.filter(m => m.id !== TYPING && m.id !== tempId));
      setError(
        err.response?.data?.error ||
        err.response?.data?.errors?.[0]?.msg ||
        'Failed to send message. Please try again.',
      );
    } finally {
      setSending(false);
    }
  }

  // ── Delete session ──────────────────────────────────────────────────────

  async function deleteSession(sessionId) {
    await chatService.deleteSession(sessionId);
    setSessions(prev => prev.filter(s => s.id !== sessionId));
    if (activeSessionId === sessionId) startNewChat();
  }

  return {
    sessions,
    activeSessionId,
    messages,
    loadingMessages,
    sending,
    error,
    openSession,
    startNewChat,
    sendMessage,
    deleteSession,
    setError,
  };
}
