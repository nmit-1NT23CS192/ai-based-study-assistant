const { Router } = require('express');
const {
  generateReviewer,
  saveReviewer,
  getMyReviewers,
  getReviewer,
  deleteReviewer,
} = require('../controllers/reviewer.controller');
const { protect }       = require('../middleware/auth.middleware');
const { aiRateLimiter } = require('../middleware/rateLimiter.middleware');

const router = Router();
router.use(protect);

router.post('/generate',           aiRateLimiter, generateReviewer);
router.post('/save',               saveReviewer);
router.get('/',                    getMyReviewers);
router.get('/:reviewerId',         getReviewer);
router.delete('/:reviewerId',      deleteReviewer);

module.exports = router;
