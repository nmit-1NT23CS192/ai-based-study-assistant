import api from './api';

const materialService = {
  /**
   * Uploads a file as multipart/form-data.
   * onProgress(percent) is called with 0–100 as the request progresses.
   * Note: progress reflects browser → server transfer only.
   * The Cloudinary upload + DB write happen server-side after 100%.
   */
  async upload(file, title, onProgress) {
    const formData = new FormData();
    formData.append('file', file);
    if (title) formData.append('title', title);

    const res = await api.post('/materials/upload', formData, {
      onUploadProgress(event) {
        if (event.total && onProgress) {
          onProgress(Math.round((event.loaded / event.total) * 100));
        }
      },
    });
    return res.data; // { material, message }
  },

  async getAll() {
    const res = await api.get('/materials');
    return res.data.materials;
  },

  async getOne(materialId) {
    const res = await api.get(`/materials/${materialId}`);
    return res.data.material;
  },

  async summarize(materialId, summaryType) {
    const res = await api.post(`/materials/${materialId}/summarize`, { summaryType });
    return res.data; // { summary, summaryType, materialTitle }
  },

  async remove(materialId) {
    await api.delete(`/materials/${materialId}`);
  },
};

export default materialService;
