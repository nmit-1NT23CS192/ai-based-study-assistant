/**
 * Lightweight class merge utility — joins truthy class strings.
 * Avoids installing clsx for this project's simple use cases.
 * For dynamic Tailwind classes, always write full strings (not interpolations)
 * so the compiler can detect and include them.
 */
export function cn(...classes) {
  return classes.filter(Boolean).join(' ');
}
