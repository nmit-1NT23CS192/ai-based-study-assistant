import { useEffect, useRef, useState } from 'react';
import { Menu, MessageSquare, AlertCircle, X, Brain } from 'lucide-react';
import MessageBubble from './MessageBubble';
import ChatInput from './ChatInput';
import LoadingSpinner from '../LoadingSpinner';
import { cn } from '../../utils/cn';

// ── Empty state ────────────────────────────────────────────────────────────

const SUGGESTIONS = [
  'Explain recursion with a Python example',
  'What is Big O notation?',
  'Debug my JavaScript code',
  'Summarize the OSI model',
];

function EmptyState({ onSend }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
      <div className="w-14 h-14 rounded-2xl bg-indigo-100 dark:bg-indigo-950 flex items-center justify-center mb-4">
        <Brain size={28} className="text-indigo-600 dark:text-indigo-400" />
      </div>
      <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">
        AI Study Assistant
      </h2>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-6 max-w-xs">
        Ask me anything about your studies — programming, math, science, and more.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-md">
        {SUGGESTIONS.map(s => (
          <button
            key={s}
            onClick={() => onSend(s)}
            className="text-left text-sm px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-indigo-400 dark:hover:border-indigo-600 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition-colors"
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}

// ── ChatWindow ─────────────────────────────────────────────────────────────

export default function ChatWindow({
  messages,
  loadingMessages,
  sending,
  error,
  activeSessionId,
  onSendMessage,
  onToggleSidebar,
  onClearError,
}) {
  const scrollRef    = useRef(null);
  const endRef       = useRef(null);
  const [userScrolled, setUserScrolled] = useState(false);

  // ── Smart scroll ─────────────────────────────────────────────────────────
  // Auto-scroll to the bottom only when the user hasn't manually scrolled up.
  // Once the user scrolls back to the bottom, auto-scroll resumes.

  function isAtBottom() {
    const el = scrollRef.current;
    if (!el) return true;
    return el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  }

  function handleScroll() {
    setUserScrolled(!isAtBottom());
  }

  useEffect(() => {
    if (!userScrolled) {
      endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, userScrolled]);

  // Always scroll to bottom when a new session is opened
  useEffect(() => {
    setUserScrolled(false);
    endRef.current?.scrollIntoView({ behavior: 'instant' });
  }, [activeSessionId]);

  const showEmptyState = messages.length === 0 && !loadingMessages;

  return (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-950">

      {/* ── Top bar ────────────────────────────────────────────────────── */}
      <div className="flex items-center gap-3 px-4 h-12 shrink-0 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900">
        {/* Mobile: toggle session list */}
        <button
          onClick={onToggleSidebar}
          className="md:hidden p-1.5 rounded-lg text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          aria-label="Toggle session list"
        >
          <Menu size={18} />
        </button>

        <div className="flex items-center gap-2 min-w-0">
          <MessageSquare size={16} className="text-indigo-500 shrink-0" />
          <span className="text-sm font-medium text-gray-700 dark:text-gray-200 truncate">
            {activeSessionId ? 'Chat' : 'New Chat'}
          </span>
        </div>
      </div>

      {/* ── Error banner ────────────────────────────────────────────────── */}
      {error && (
        <div className="flex items-start gap-2.5 mx-4 mt-3 px-4 py-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 text-red-700 dark:text-red-400 rounded-xl text-sm">
          <AlertCircle size={16} className="shrink-0 mt-0.5" />
          <span className="flex-1">{error}</span>
          <button onClick={onClearError} className="shrink-0 hover:opacity-70 transition-opacity">
            <X size={14} />
          </button>
        </div>
      )}

      {/* ── Message area ────────────────────────────────────────────────── */}
      {loadingMessages ? (
        <div className="flex-1 flex items-center justify-center">
          <LoadingSpinner size={28} />
        </div>
      ) : showEmptyState ? (
        <EmptyState onSend={onSendMessage} />
      ) : (
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-4 py-4 space-y-4"
        >
          {messages.map(msg => (
            <MessageBubble key={msg.id} message={msg} />
          ))}
          {/* Invisible anchor for scrollIntoView */}
          <div ref={endRef} />
        </div>
      )}

      {/* ── Scroll-to-bottom pill ────────────────────────────────────────── */}
      {userScrolled && !showEmptyState && (
        <button
          onClick={() => {
            setUserScrolled(false);
            endRef.current?.scrollIntoView({ behavior: 'smooth' });
          }}
          className={cn(
            'absolute bottom-24 left-1/2 -translate-x-1/2',
            'px-3 py-1.5 rounded-full text-xs font-medium',
            'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700',
            'text-gray-600 dark:text-gray-300 shadow-md hover:shadow-lg',
            'transition-all',
          )}
        >
          ↓ Scroll to bottom
        </button>
      )}

      {/* ── Input ───────────────────────────────────────────────────────── */}
      <div className="shrink-0 p-4 bg-gray-50 dark:bg-gray-950">
        <ChatInput onSend={onSendMessage} disabled={sending} />
      </div>
    </div>
  );
}
