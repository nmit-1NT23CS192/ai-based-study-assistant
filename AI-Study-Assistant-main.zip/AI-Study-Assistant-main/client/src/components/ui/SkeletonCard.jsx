/**
 * Skeleton loaders — pulsing placeholders that match the shape of real content.
 *
 * Using skeleton loaders instead of a spinner shows the user WHERE content will
 * appear, reducing perceived load time and layout shift.
 *
 * All skeletons share the same animate-pulse + bg-gray-200 pattern.
 */

function Bone({ className }) {
  return (
    <div className={`animate-pulse rounded bg-gray-200 dark:bg-gray-700/60 ${className}`} />
  );
}

// ── SkeletonCard ───────────────────────────────────────────────────────────
// Matches the shape of FlashcardSetCard, ReviewerCard, MaterialCard

export function SkeletonCard() {
  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-5 space-y-4">
      <div className="flex items-start justify-between">
        <Bone className="w-10 h-10 rounded-xl" />
        <Bone className="w-20 h-6 rounded-full" />
      </div>
      <div className="space-y-2">
        <Bone className="h-5 w-3/4" />
        <Bone className="h-4 w-1/2" />
      </div>
      <Bone className="h-9 w-full rounded-xl" />
    </div>
  );
}

// ── SkeletonGrid ───────────────────────────────────────────────────────────
// A responsive grid of SkeletonCard — drop-in replacement while data loads

export function SkeletonGrid({ count = 6, cols = 3 }) {
  const colClass = {
    2: 'grid-cols-1 sm:grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-2 lg:grid-cols-4',
  }[cols] ?? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3';

  return (
    <div className={`grid ${colClass} gap-4`}>
      {Array.from({ length: count }, (_, i) => (
        <SkeletonCard key={i} />
      ))}
    </div>
  );
}

// ── SkeletonList ───────────────────────────────────────────────────────────
// Matches a sidebar list (session list, note list, etc.)

export function SkeletonList({ count = 5 }) {
  return (
    <div className="space-y-1 p-2">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="px-3 py-2.5 rounded-lg space-y-1.5">
          <Bone className="h-3.5 w-3/4" />
          <Bone className="h-3 w-1/3" />
        </div>
      ))}
    </div>
  );
}

// ── SkeletonText ───────────────────────────────────────────────────────────
// For long-form content areas (reviewer viewer, note content)

export function SkeletonText({ lines = 6 }) {
  const widths = ['w-full', 'w-5/6', 'w-full', 'w-4/5', 'w-full', 'w-3/4'];
  return (
    <div className="space-y-3">
      {Array.from({ length: lines }, (_, i) => (
        <Bone key={i} className={`h-4 ${widths[i % widths.length]}`} />
      ))}
    </div>
  );
}
